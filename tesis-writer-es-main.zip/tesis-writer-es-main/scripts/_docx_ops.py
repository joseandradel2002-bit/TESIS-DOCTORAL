"""Operaciones de bajo nivel sobre párrafos de Word que conservan el formato.

El texto de un párrafo se reparte en varios <w:r>/<w:t>. Estas funciones
trabajan con un mapa carácter → origen para reemplazar o insertar en cualquier
posición sin destruir negritas, cursivas ni notas.

El mapa usa los mismos caracteres que _common.para_text_with_notes:
texto de w:t, «\t» por w:tab, «\n» por w:br/w:cr y NOTE_MARK por cada
referencia a nota. Así, lo que muestra dump_docx.py coincide con lo que se
puede buscar y sustituir.
"""
from __future__ import annotations

import copy

from docx.oxml.ns import qn

from _common import NOTE_MARK

XML_SPACE = "{http://www.w3.org/XML/1998/namespace}space"
SPECIAL = {qn("w:tab"): "\t", qn("w:br"): "\n", qn("w:cr"): "\n",
           qn("w:footnoteReference"): NOTE_MARK, qn("w:endnoteReference"): NOTE_MARK}
PAYLOAD = ("w:footnoteReference", "w:endnoteReference", "w:drawing", "w:fldChar", "w:instrText",
           "w:object", "w:pict", "w:tab", "w:br", "w:cr", "w:sym")


class SpliceError(ValueError):
    pass


def text_nodes(p_el):
    return [t for t in p_el.iter(qn("w:t"))]


def char_map(p_el):
    """Devuelve (texto, mapa). mapa[i] = (w:t, desplazamiento) o (None, elemento especial)."""
    m, buf = [], []
    for node in p_el.iter():
        if node.tag == qn("w:t"):
            s = node.text or ""
            for i in range(len(s)):
                m.append((node, i))
            buf.append(s)
        elif node.tag in SPECIAL:
            m.append((None, node))
            buf.append(SPECIAL[node.tag])
    return "".join(buf), m


def _set(t, s):
    t.text = s
    t.set(XML_SPACE, "preserve")


def run_of(el):
    r = el.getparent() if el is not None else None
    while r is not None and r.tag != qn("w:r"):
        r = r.getparent()
    return r


def splice(p_el, start, end, new_text=""):
    """Sustituye texto[start:end] por new_text con el formato del primer carácter afectado.

    Se niega (SpliceError) si el rango incluye una nota, tabulación o salto: borrarlos
    o moverlos en silencio cambiaría el documento más de lo pedido.
    """
    text, m = char_map(p_el)
    if not m:
        raise SpliceError("párrafo sin texto")
    if any(m[i][0] is None for i in range(start, end)):
        raise SpliceError("el texto a sustituir cruza una nota, tabulación o salto de línea; acota el fragmento")
    if start == end:  # inserción pura
        if start > 0 and m[start - 1][0] is not None:
            t, off = m[start - 1]
            s = t.text or ""
            _set(t, s[:off + 1] + new_text + s[off + 1:])
            return
        if start < len(m) and m[start][0] is not None:
            t, off = m[start]
            s = t.text or ""
            _set(t, s[:off] + new_text + s[off:])
            return
        raise SpliceError("no hay texto junto a la posición de inserción")
    t0, o0 = m[start]
    t1, o1 = m[end - 1]
    o1 += 1
    if t0 is t1:
        s = t0.text or ""
        _set(t0, s[:o0] + new_text + s[o1:])
        return
    _set(t0, (t0.text or "")[:o0] + new_text)
    inside = False
    for t in text_nodes(p_el):
        if t is t0:
            inside = True
            continue
        if t is t1:
            _set(t, (t.text or "")[o1:])
            break
        if inside:
            _set(t, "")


def _content_kids(r):
    return [k for k in r if k.tag != qn("w:rPr")]


def split_run_at(t, off):
    """Parte el run que contiene t en el carácter off. Devuelve (run_izq | None, run_der | None)."""
    r = run_of(t)
    s = t.text or ""
    kids = list(r)
    idx = kids.index(t)
    before = [k for k in kids[:idx] if k.tag != qn("w:rPr")]
    after = kids[idx + 1:]
    if off <= 0 and not before:
        return None, r
    if off >= len(s) and not after:
        return r, None
    right = copy.deepcopy(r)
    _set(t, s[:off])
    for child in after:
        r.remove(child)
    rkids = list(right)
    for child in rkids[:idx]:
        if child.tag != qn("w:rPr"):
            right.remove(child)
    _set(rkids[idx], s[off:])
    r.addnext(right)
    return r, right


def split_run_before(el):
    """Parte el run de el justo antes de el (tabulación, salto, nota). Devuelve (izq | None, der)."""
    r = run_of(el)
    kids = list(r)
    idx = kids.index(el)
    if not [k for k in kids[:idx] if k.tag != qn("w:rPr")]:
        return None, r
    right = copy.deepcopy(r)
    for child in kids[idx:]:
        r.remove(child)
    for child in list(right)[:idx]:
        if child.tag != qn("w:rPr"):
            right.remove(child)
    r.addnext(right)
    return r, right


def insert_element_at(p_el, pos, new_el):
    """Inserta new_el (normalmente un <w:r>) en la posición de carácter pos del párrafo."""
    text, m = char_map(p_el)
    runs = list(p_el.iter(qn("w:r")))
    if not m or not runs:
        p_el.append(new_el)
        return
    if pos >= len(text):
        last = run_of(m[-1][0] if m[-1][0] is not None else m[-1][1])
        last.addnext(new_el)
        return
    t, off = m[pos]
    if t is None:  # justo antes de una nota, tabulación o salto
        left, right = split_run_before(off)
        if left is not None:
            left.addnext(new_el)
        else:
            right.addprevious(new_el)
        return
    left, right = split_run_at(t, off)
    if left is not None:
        left.addnext(new_el)
    else:
        right.addprevious(new_el)


def replace_text_keep_format(p_el, new_text):
    """Sustituye el texto del párrafo (solo nodos w:t); conserva pPr, el formato del primer
    run con texto y los elementos especiales (notas, tabulaciones, campos, imágenes)."""
    nodes = [t for t in text_nodes(p_el)]
    if not any((t.text or "") for t in nodes):
        raise SpliceError("párrafo sin texto: usar insert_after/insert_before")
    first = next(t for t in nodes if (t.text or ""))
    for t in nodes:
        _set(t, new_text if t is first else "")
    for r in list(p_el.iter(qn("w:r"))):
        has_payload = any(r.find(qn(x)) is not None for x in PAYLOAD)
        ts = r.findall(qn("w:t"))
        if ts and not any((t.text or "") for t in ts) and not has_payload:
            r.getparent().remove(r)


def new_paragraph_like(model_p_el, text):
    """Crea un <w:p> con el pPr del modelo y el rPr de su primer run con texto."""
    from lxml import etree
    p = copy.deepcopy(model_p_el)
    rpr = None
    for r in p.iter(qn("w:r")):
        if r.find(qn("w:t")) is not None and r.find(qn("w:rPr")) is not None:
            rpr = copy.deepcopy(r.find(qn("w:rPr")))
            break
    for child in list(p):
        if child.tag != qn("w:pPr"):
            p.remove(child)
    pPr = p.find(qn("w:pPr"))
    if pPr is not None:
        sect = pPr.find(qn("w:sectPr"))  # no heredar saltos de sección del modelo
        if sect is not None:
            pPr.remove(sect)
    r = etree.SubElement(p, qn("w:r"))
    if rpr is not None:
        r.append(rpr)
    t = etree.SubElement(r, qn("w:t"))
    _set(t, text)
    return p
