# Investigación exhaustiva y doble verificación de fuentes

Objetivo: que cada referencia de la tesis sea **relevante**, **de renombre** y **real** (DOI probado
en dos fuentes independientes), y que diga lo que el texto le atribuye.

## 1. Antes de buscar: fijar los parámetros

Registrar en la matriz de evidencia (`templates/matriz-evidencia.md`):
```
PREGUNTA / AFIRMACIÓN A SOSTENER: …
CONCEPTOS NÚCLEO (2–4) + sinónimos ES/EN: …
CADENA: ("concepto A" OR "sinónimo A") AND ("concepto B" OR …) NOT (…)
BASES: …            RANGO DE AÑOS: … (justificar)       IDIOMAS: es, en
TIPOS: artículo de revista, actas con revisión por pares, libro académico
INCLUSIÓN / EXCLUSIÓN: definidos ahora, no después de ver resultados
FECHA DE EJECUCIÓN: AAAA-MM-DD
```

## 2. Dónde buscar

- Generales: Scopus, Web of Science, Google Scholar, Semantic Scholar, OpenAlex.
- Computación e ingeniería: IEEE Xplore, ACM Digital Library, arXiv (cs, q-bio.NC), DBLP.
- Biomedicina y neurociencia: PubMed, bioRxiv (preprints), eLife, Nature, Cell Press.
- Iberoamérica: SciELO, Redalyc, Dialnet, Latindex, repositorios de tesis.
- Herramientas web disponibles al agente: WebSearch / WebFetch y las APIs de §6.

## 3. Estrategia en cuatro capas

1. **Booleana** en 2–3 bases. < 20 resultados: relajar (quitar NOT, ampliar años). > 500: restringir.
2. **Encadenamiento hacia atrás:** referencias de 5–10 artículos núcleo; lo que citan varios es fundacional.
3. **Hacia adelante:** quién cita a los fundacionales (OpenAlex `cites:`, Semantic Scholar `/citations`).
4. **Semántica:** Semantic Scholar o OpenAlex `search=`. Si > 80 % de lo nuevo ya estaba, hay saturación.

Parar cuando: cada afirmación planificada tiene soporte o brecha declarada, la última ronda no
aportó nada nuevo y están cubiertos los trabajos fundacionales y los recientes.

## 4. Relevancia: criterios de inclusión

Árbol rápido por fuente:
1. ¿Responde directamente a la afirmación o pregunta? No → excluir (lo tangencial no entra).
2. ¿Revisión por pares? No → solo literatura gris oficial (OMS, informes técnicos de Intel/IBM)
   etiquetada como tal, o documentación técnica para software.
3. ¿Dentro del rango? No → solo si es seminal (y se cita como tal).
4. ¿Método fiable? Dudoso → leer texto completo antes de decidir.

Leer al menos resumen + resultados de cada fuente usada para una afirmación central, y texto
completo cuando sostiene una cifra o una afirmación central.

## 5. Renombre: cómo juzgarlo

Escala de preferencia:
1. Revista con revisión por pares Q1 (SJR/JCR) o congreso de primer nivel del área (NeurIPS, ICML,
   ICLR, CVPR, ACL; en neuromórfica, ISCAS, IJCNN, Frontiers in Neuroscience…).
2. Otra revista indexada en Scopus/WoS con revisión por pares.
3. Preprint (arXiv, bioRxiv): solo si no existe versión publicada; etiquetar y matizar
   («resultados no revisados por pares»). Preprints de 2024 en adelante: verificación reforzada.
4. Literatura gris (informes, documentación oficial, páginas institucionales): para datos de
   contexto o software, nunca para sostener un resultado científico.

Señales de calidad: indexación Scopus/WoS/PubMed, cuartil, editorial miembro de COPE, autores con
afiliación y ORCID, número de citas **normalizado por antigüedad y campo** (OpenAlex
`cited_by_count`, Semantic Scholar `influentialCitationCount`).

Señales de revista depredadora (excluir): aceptación en días, comité editorial falso, sin
indexación, alcance desmesurado, métricas inventadas, APC muy bajo, solicitud por correo.

El número de citas o el prestigio de la revista **no sustituyen** el juicio de si la fuente
sostiene esa afirmación concreta («salió en Nature» no valida un argumento).

Vigencia orientativa: computación e IA ≤ 3–5 años para el estado del arte; neurociencia ≤ 5–10;
obras fundacionales sin límite (Maass, 1997; Bi y Poo, 1998).

## 6. Doble verificación (obligatoria para cada referencia)

### Automática
```bash
python3 scripts/verify_refs.py --txt referencias.txt --mailto CORREO --out verificacion.md
python3 scripts/verify_refs.py --docx tesis.docx --mailto CORREO --out verificacion.md
python3 scripts/verify_refs.py --doi 10.1038/s41586-024-07558-y
```
Protocolo que ejecuta:
1. **doi.org** (`/api/handles/{doi}`): ¿el DOI existe? Si no → **NO-RESUELVE** (posible
   referencia inventada o DOI mal copiado).
2. **Fuente A:** Crossref `/works/{doi}` (o DataCite `/dois/{doi}` para datasets/software).
3. **Fuente B:** OpenAlex `/works/https://doi.org/{doi}` (también trae `is_retracted` y citas).
4. Comparación con lo escrito: título (similitud ≥ 0,85), año (±1), primer apellido.
5. Retractación: Crossref `update-to`/`updated-by` (incluye Retraction Watch) y OpenAlex.
6. Sin DOI: búsqueda en Crossref (`query.bibliographic`) para proponer uno; nunca se acepta un
   DOI propuesto sin volver a verificarlo.

| Estado | Qué hacer |
|---|---|
| VERIFICADO | puede entrar |
| VERIFICADO-1 | una sola fuente confirmó: aceptable en datasets/software; en artículos, revisar a mano |
| DISCREPANCIA | corregir con los metadatos reales o buscar el DOI correcto; si la obra no existe, eliminar |
| NO-RESUELVE | eliminar o pedir la fuente al usuario; nunca conservar «por si acaso» |
| RETRACTADO | no citar como evidencia (solo si se discute la retractación) |
| SIN-DOI / SIN-DOI-SUGERIDO | libro, norma o web: verificar en la editorial, ISBN (WorldCat, Google Books) o URL viva; artículo: buscar su DOI |
| SIN-METADATOS | el DOI existe pero ningún índice tiene datos: verificar en la editorial |
| SIN-CONEXION | repetir con red; no concluir nada (código de salida 2) |

Modo `--doi`: no hay referencia escrita que comparar; el informe muestra autor, año y título de
la obra para confirmar que es la que se quería citar.

### Manual (segunda verificación, la de contexto)
- La fuente **dice** lo que se afirma: cifras exactas o dentro del redondeo, misma población,
  mismo método, misma dirección del efecto. Verificar el 100 % de las cifras y afirmaciones
  centrales y una muestra del resto.
- Todos los campos (autores, año, título, revista, volumen, páginas) salen de **la misma**
  publicación: el error típico de un modelo es mezclar dos artículos reales en uno falso.
- Banderas rojas: revista que no existe o no está indexada, autor real con un artículo que nunca
  escribió, fecha futura, volumen imposible, fuente «demasiado perfecta» para la afirmación,
  artículo poco citado y muy de nicho que nadie más menciona.

Si la verificación no es posible (sin DOI, sin acceso), se informa al usuario y la referencia
queda marcada `[VERIFICAR]` hasta que él aporte el PDF o la URL.

## 7. Comandos de respaldo (curl)

```bash
DOI="10.7554/eLife.47314"; UA="User-Agent: tesis-writer-es/1.0 (mailto:CORREO)"
curl -s "https://doi.org/api/handles/$DOI"                          # responseCode 1 = existe
curl -s -H "$UA" "https://api.crossref.org/works/$DOI"              # metadatos de registro
curl -s "https://api.openalex.org/works/https://doi.org/$DOI"       # 2.º índice, is_retracted, citas
curl -s "https://api.semanticscholar.org/graph/v1/paper/DOI:$DOI?fields=title,authors,year,venue,citationCount"
curl -sG -H "$UA" "https://api.crossref.org/works" --data-urlencode "query.bibliographic=TÍTULO" --data-urlencode "rows=5"
curl -sG -H "$UA" "https://api.crossref.org/works" --data-urlencode "filter=updates:$DOI"   # avisos de retractación
curl -s "https://api.datacite.org/dois/10.5281/zenodo.XXXXXXX"      # datasets y software
curl -sL -H "Accept: text/x-bibliography; style=apa; locale=es-ES" "https://doi.org/$DOI"  # borrador APA (revisar)
```
Límites: Crossref ~10 req/s con `mailto`; OpenAlex y Semantic Scholar ~1 req/s sin clave. Un fallo
de red no es «no encontrado».

## 8. Registro

Cada fuente usada queda en la matriz de evidencia con: referencia APA, DOI, estado de
verificación, fecha, tipo y nivel, hallazgo clave y sección donde se usa. Es la defensa ante el
tribunal si preguntan de dónde sale un dato.
