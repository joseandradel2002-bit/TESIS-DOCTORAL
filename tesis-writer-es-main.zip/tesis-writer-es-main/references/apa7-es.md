# APA 7 en español: citas, referencias, tablas y figuras

Convenciones para tesis en español. Si la guía institucional (perfil) dice otra cosa, manda la
institución; si el documento ya fijó una convención, mantenerla en todo el texto.

## Citas en el texto

| Caso | Parentética | Narrativa |
|---|---|---|
| Un autor | (Maass, 1997) | Maass (1997) |
| Dos autores | (Bi y Poo, 1998) | Bi y Poo (1998) |
| Tres o más | (Shiu et al., 2024) | Shiu et al. (2024) |
| Varias obras | (Davies et al., 2018; Roy et al., 2019) — orden alfabético | — |
| Mismo autor y año | (Deutsch et al., 2019a, 2019b) | — |
| Autor corporativo | 1.ª vez (Organización Mundial de la Salud [OMS], 2021); luego (OMS, 2021) | — |
| Sin fecha | (FlyWire, s. f.) | FlyWire (s. f.) |
| Cita textual | (Eon Systems PBC, 2026, párr. 4) / (Pérez, 2023, p. 45) | — |
| Secundaria | (Hebb, 1949, como se citó en Gerstner et al., 2014) | — |
| Repositorio propio | (flywire-jo-snn, 2026) | el repositorio del proyecto (flywire-jo-snn, 2026) |

- **«y» entre dos autores** también en la parentética (convención UTPL y de la mayoría de guías
  en español). Si el perfil indica «&», usar «&» en todo el documento. No mezclar.
- «et al.» desde la primera cita con tres o más autores; sin cursiva; no se traduce.
- Homónimos con el mismo apellido y año: añadir iniciales (D. Patterson et al., 2021; R. D. Patterson et al., 1992).
- Cita textual < 40 palabras entre comillas angulares «…» (o las que use el documento); ≥ 40 en
  bloque con sangría, sin comillas, cita tras el punto final.
- Comunicación personal: solo en el texto, no en Referencias.

## Lista de referencias

- Título «Referencias», orden alfabético por primer apellido, sangría francesa 1,27 cm,
  interlineado doble, sin viñetas.
- Hasta 20 autores; con 21 o más: los 19 primeros, «…» y el último.
- Títulos de artículos, libros y capítulos en tipo oración; nombre de la revista con su
  capitalización oficial y en cursiva; volumen en cursiva, número entre paréntesis sin cursiva.
- DOI siempre como `https://doi.org/10.xxxx/yyyy`, sin «doi:», sin «dx.», sin punto final.
- Si el perfil pide enlaces en negro y acortados: los DOI no se acortan; las URL largas de webs sí,
  si la institución lo exige.
- Antes del último autor: «y» o «&» según la convención elegida (la misma que en el texto).

### Patrones

```
Artículo
Dorkenwald, S., Matsliah, A., Sterling, A. R., … Murthy, M. (2024). Neuronal wiring diagram of an
    adult brain. Nature, 634(8032), 124–138. https://doi.org/10.1038/s41586-024-07558-y
    (en Word: Nature y 634 en cursiva)

Artículo con número de artículo
Stimberg, M., Brette, R., y Goodman, D. F. M. (2019). Brian 2, an intuitive and efficient neural
    simulator. eLife, 8, Artículo e47314. https://doi.org/10.7554/eLife.47314

Libro
Gerstner, W., Kistler, W. M., Naud, R., y Paninski, L. (2014). Neuronal dynamics: From single
    neurons to networks and models of cognition. Cambridge University Press.
    https://doi.org/10.1017/CBO9781107447615

Capítulo de libro
Apellido, A. A. (2020). Título del capítulo. En B. Editor y C. Editor (Eds.), Título del libro
    (pp. 15–40). Editorial. https://doi.org/…

Actas de congreso
Apellido, A. A. (2023). Título de la ponencia. En Proceedings of the … (pp. 1–9). Editorial.
    https://doi.org/…

Preprint
Apellido, A. A. (2025). Título del trabajo [Preprint]. arXiv. https://doi.org/10.48550/arXiv.2501.xxxxx

Repositorio propio / software (R06)
flywire-jo-snn. (2026). Bio-inspired SNN on the FlyWire Johnston's organ connectome
    (Versión 1.0.0) [Repositorio de GitHub]. GitHub. https://github.com/usuario/flywire-jo-snn

Software de terceros (si se cita además de la nota al final)
Brian2 Development Team. (2024). Brian2 (Versión 2.7.1) [Software]. Zenodo. https://doi.org/…

Dataset
Organización o Autor, A. A. (2024). Título del conjunto de datos (Versión o snapshot)
    [Conjunto de datos]. Editor o portal. https://doi.org/… (o URL estable)
    (si el dataset tiene artículo de referencia, citar también el artículo)

Página web
Eon Systems PBC. (2026, 12 de marzo). Título de la entrada. https://…
    (sin fecha: (s. f.) y «Recuperado el 3 de mayo de 2026, de https://…»)

Informe
Organización Mundial de la Salud. (2021). World report on hearing. https://…

Tesis
Apellido, A. A. (2021). Título de la tesis [Tesis de grado, Universidad]. Repositorio. https://…
```

Las librerías clave llevan **nota al final con su documentación oficial** (R02). Si además el
texto atribuye resultados a la herramienta, se cita su artículo de referencia (p. ej. Stimberg
et al., 2019 para Brian2) en el texto y en Referencias.

## Tablas y figuras (UTPL + APA 7)

```
Tabla 3                          ← negrita, sin cursiva, sin punto final (Arial 10)
Métricas topológicas del subgrafo JO      ← cursiva, sin negrita, tipo oración, sin punto final
[tabla: Arial 10, interlineado 1,5, solo líneas horizontales]
Nota. Texto de la nota.          ← «Nota.» en cursiva con punto; el resto normal
```

- Numeración consecutiva por tipo (Tabla 1, 2…; Figura 1, 2…) en el orden de la primera mención.
- Toda tabla y figura va precedida por un párrafo propio de **2–3 líneas** que la nombra por su
  número y dice qué muestra: «La tabla 3 resume…» (R15). No «la tabla siguiente».
- Autoría (R05):
  - Propia → sin «Elaboración propia»; «Nota.» solo si explica algo (abreviaturas, datos, unidades).
  - Con datos de terceros → «Nota. Datos tomados de FlyWire (Dorkenwald et al., 2024).»
  - Adaptada → «Nota. Adaptado de *Título* (p. 5), por A. Autor y B. Autor, 2023, *Revista*,
    *12*(3) (https://doi.org/…).»
  - Reproducida → «Nota. Tomado de *Título*, por A. Autor, 2020, Editorial. CC BY 4.0.»
    (comprobar que la licencia permite reproducir).
  - Con datos del repositorio propio → «Nota. Datos de results.md (flywire-jo-snn, 2026).» + nota
    al final con la URL del archivo en su primera mención.
- Figuras: ejes con nombre y unidades, leyenda si hay varios grupos, barras de error o IC cuando
  hay medias; sin 3D, sin tortas para más de 3 categorías, paletas legibles en gris (viridis).
- Estadística: símbolos en cursiva (*M*, *DE*, *p*, *t*, *n*); *p* exacta salvo *p* < .001;
  tamaño del efecto e IC 95 %. El separador decimal lo fija el documento (coma o punto): uno solo.

## Números

- Del cero al nueve en palabras, salvo con unidades, cifras exactas, porcentajes y en tablas.
- Miles con espacio fino (1 239; 54 492 922) según la norma ISO/RAE; no mezclar con puntos.
- Porcentaje con espacio: 20 %.
- Separador decimal: el del documento (en el borrador de referencia, punto: 0.880). Ser coherente.

## Siglas

Primera aparición en el cuerpo: nombre completo y sigla entre paréntesis. Si la sigla es del
inglés: «redes neuronales de pulsos (SNN, por sus siglas en inglés)». Resumen, abstract y cuerpo
son ámbitos separados. Plural sin «s» (las SNN) según la RAE; mantener la convención del documento.
