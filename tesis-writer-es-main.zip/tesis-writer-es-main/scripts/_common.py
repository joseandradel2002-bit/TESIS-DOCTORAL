"""Utilidades compartidas por los scripts de tesis-writer-es.

Modelo del documento: lista de párrafos del cuerpo (doc.paragraphs) con índice
estable, nivel de título, numeración calculada (1.2.3), tipo de párrafo y
texto con marcadores de nota. Todos los scripts usan el mismo índice, así que
un hallazgo de la auditoría se puede corregir con edit_docx.py sin traducir
posiciones.
"""
from __future__ import annotations

import json
import re
import sys
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

try:
    import docx  # python-docx
    from docx.oxml.ns import qn
except ImportError:  # pragma: no cover
    sys.exit("Falta python-docx. Instala con: python3 -m pip install python-docx")

NOTE_MARK = "\uE000"  # marcador interno: posición de una referencia a nota (al pie o al final)
MARKER_RE = re.compile(r"\[\s*Insertar nota al final\s*:\s*(.+?)\s*\]", re.I | re.S)

HEADING_NAME_RE = re.compile(r"^(heading|t[ií]tulo|encabezado)\s*(\d)$", re.I)
CHAPTER_RE = re.compile(r"^cap[ií]tulo\b", re.I)
CHAPTER_INLINE_RE = re.compile(
    r"^cap[ií]tulo\s+(?:\d+|[ivxlc]+|uno|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|once|doce)\b"
    r"\s*[.:\-–—]?\s*(\S.*)?$", re.I)
CAPTION_RE = re.compile(r"^(tabla|figura)\s+([A-Z]?\d+)\b", re.I)
NOTE_PARA_RE = re.compile(r"^nota\s*\.", re.I)
REFS_HEAD_RE = re.compile(r"^(referencias|referencias bibliogr[aá]ficas|bibliograf[ií]a|references)$", re.I)
BACK_MATTER_RE = re.compile(r"^(ap[eé]ndice|anexo|referencias|bibliograf)", re.I)
BODY_FRONT_RE = re.compile(r"^(introducci[oó]n|conclusiones|recomendaciones|discusi[oó]n|conclusiones y recomendaciones)$", re.I)
ABSTRACT_RE = re.compile(r"^(resumen|abstract)$", re.I)

ABBREV = ["et al.", "p. ej.", "s. f.", "e. g.", "i. e.", "aprox.", "fig.", "núm.", "vol.",
          "pp.", "p.", "ed.", "eds.", "cap.", "Dr.", "Dra.", "Sr.", "Sra.", "etc.", "vs.", "cf."]


def strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def norm(s: str) -> str:
    return strip_accents(s).lower().strip()


def word_count(s: str) -> int:
    return len(re.findall(r"\w+", s))


def split_sentences(text: str) -> list[str]:
    t = text.replace(NOTE_MARK, "")
    protected = t
    dot = chr(0xE100)
    for ab in ABBREV:
        protected = re.sub(r"(?<!\w)" + re.escape(ab), lambda m: m.group(0).replace(".", dot),
                           protected, flags=re.I)
    protected = re.sub(r"(\d)\.(\d)", "\\1\uE1FF\\2", protected)
    parts = re.split(r"(?<=[.!?…])\s+(?=[¿¡«\"“(]?[A-ZÁÉÍÓÚÑ0-9])", protected)
    out = []
    for p in parts:
        p = re.sub("\uE1FF", ".", p)
        p = re.sub("[\uE100-\uE109]", ".", p)
        if p.strip():
            out.append(p.strip())
    return out


# --------------------------------------------------------------------------- config

def load_config(docx_path: str | None, explicit: str | None) -> dict:
    cands = []
    if explicit:
        cands.append(Path(explicit))
    if docx_path:
        cands.append(Path(docx_path).resolve().parent / "tesis.config.json")
    cands.append(Path.cwd() / "tesis.config.json")
    for c in cands:
        if c.is_file():
            with open(c, encoding="utf-8") as f:
                cfg = json.load(f)
            cfg["_path"] = str(c)
            return cfg
    return {}


def load_profile(cfg: dict) -> dict:
    name = cfg.get("perfil", "utpl-tic")
    here = Path(__file__).resolve().parent.parent / "profiles"
    p = Path(name) if name.endswith(".json") else here / f"{name}.json"
    if not p.is_file():
        p = here / "utpl-tic.json"
    with open(p, encoding="utf-8") as f:
        prof = json.load(f)
    prof["_path"] = str(p)
    return prof


# --------------------------------------------------------------------------- estilos

def style_chain(style):
    seen = 0
    while style is not None and seen < 20:
        yield style
        style = style.base_style
        seen += 1


def _numpr(p):
    pPr = p._p.pPr
    if pPr is not None and pPr.numPr is not None:
        ilvl = pPr.numPr.ilvl.val if pPr.numPr.ilvl is not None else 0
        num = pPr.numPr.numId.val if pPr.numPr.numId is not None else None
        return ilvl, num
    for s in style_chain(p.style):
        sp = s.element.pPr
        if sp is not None and sp.numPr is not None:
            ilvl = sp.numPr.ilvl.val if sp.numPr.ilvl is not None else 0
            num = sp.numPr.numId.val if sp.numPr.numId is not None else None
            return ilvl, num
    return None, None


def _outline_lvl(p):
    els = [p._p.pPr] + [s.element.pPr for s in style_chain(p.style)]
    for el in els:
        if el is None:
            continue
        o = el.find(qn("w:outlineLvl"))
        if o is not None:
            try:
                v = int(o.get(qn("w:val")))
                return None if v >= 9 else v + 1
            except (TypeError, ValueError):
                pass
    return None


def heading_level(p) -> int | None:
    base = None
    for s in style_chain(p.style):
        m = HEADING_NAME_RE.match(s.name or "")
        if m:
            base = int(m.group(2))
            break
    if base is None:
        sname = (p.style.name or "").lower()
        if sname.startswith(("toc", "table of", "tdc", "índice", "indice")):
            return None
        base = _outline_lvl(p)
        if base is None:
            return None
    if base == 1:
        return 1
    ilvl, num = _numpr(p)
    if ilvl is not None and num not in (None, 0):
        return max(base, ilvl + 1)
    return base


# --------------------------------------------------------------------------- modelo

@dataclass
class Para:
    idx: int
    text: str            # texto con NOTE_MARK donde hay referencias a notas
    style: str
    level: int | None
    kind: str            # heading|body|caption|note|toc|ref|front|empty|list|template
    number: str = ""     # numeración calculada del título (p. ej. 4.2.1)
    chapter: int | None = None
    section: str = ""    # título de la sección contenedora (con número)
    region: str = ""     # front|resumen|intro|chapter|refs|back
    where: str = ""      # ubicación alternativa (celdas de tabla)
    has_note_ref: bool = False
    el: object = field(default=None, repr=False)

    @property
    def plain(self) -> str:
        return self.text.replace(NOTE_MARK, "")

    def loc(self) -> str:
        if self.where:
            return self.where
        where = f"§{self.section}" if self.section else (f"cap. {self.chapter}" if self.chapter else self.region)
        return f"párr. {self.idx} ({where})"


def para_text_with_notes(p_el) -> tuple[str, bool]:
    out = []
    has = False
    for node in p_el.iter():
        tag = node.tag
        if tag == qn("w:t"):
            out.append(node.text or "")
        elif tag == qn("w:tab"):
            out.append("\t")
        elif tag in (qn("w:br"), qn("w:cr")):
            out.append("\n")
        elif tag in (qn("w:footnoteReference"), qn("w:endnoteReference")):
            out.append(NOTE_MARK)
            has = True
    return "".join(out), has


def build_model(doc) -> list[Para]:
    """Modelo de párrafos con capítulo, región y numeración calculada.

    Capítulos: si algún título de nivel 1 empieza por «Capítulo», se usan esos (con el
    nombre en la línea siguiente, estilo UTPL, o en la misma: «Capítulo 2. Marco teórico»).
    Si no, cada título de nivel 1 posterior a la Introducción (o al Resumen) que no sea
    Conclusiones, Referencias, Apéndice… cuenta como capítulo.
    """
    pre = []
    for p in doc.paragraphs:
        text, has = para_text_with_notes(p._p)
        t = text.strip()
        pre.append((text, has, t, heading_level(p) if t else None))
    h1 = [t.replace(NOTE_MARK, "") for _, _, t, lv in pre if lv == 1]
    mode = "capitulo" if any(CHAPTER_RE.match(x) for x in h1) else "h1"
    has_intro = any(BODY_FRONT_RE.match(x) or ABSTRACT_RE.match(x) for x in h1)

    paras: list[Para] = []
    chapter = 0
    in_chapter = False
    expect_title = False
    started = not has_intro  # modo h1: los capítulos empiezan tras Introducción/Resumen
    region = "front"
    counters = [0] * 10
    current_section = ""
    for i, p in enumerate(doc.paragraphs):
        text, has, t, lvl = pre[i]
        sname = p.style.name or ""
        kind = "body"
        number = ""
        if not t:
            kind = "empty"
        elif sname.lower().startswith(("toc", "table of", "tdc")):
            kind = "toc"
        elif lvl is not None:
            kind = "heading"
            plain = t.replace(NOTE_MARK, "")
            if lvl == 1:
                special = True
                if REFS_HEAD_RE.match(plain):
                    region = "refs"
                elif BACK_MATTER_RE.match(plain):
                    region = "back"
                elif ABSTRACT_RE.match(plain):
                    region, started = "resumen", True
                elif BODY_FRONT_RE.match(plain):
                    region, started = "intro", True
                else:
                    special = False
                if special:
                    in_chapter = expect_title = False
                    current_section = plain
                elif mode == "capitulo" and CHAPTER_RE.match(plain):
                    chapter += 1
                    in_chapter, region = True, "chapter"
                    counters = [0] * 10
                    m = CHAPTER_INLINE_RE.match(plain)
                    expect_title = not (m and m.group(1))
                    current_section = plain
                elif mode == "capitulo" and expect_title:
                    expect_title = False
                    current_section = plain
                elif mode == "h1" and started:
                    chapter += 1
                    in_chapter, region = True, "chapter"
                    counters = [0] * 10
                    current_section = plain
                else:
                    in_chapter = False
                    current_section = plain
            elif in_chapter:
                counters[lvl] += 1
                for k in range(lvl + 1, 10):
                    counters[k] = 0
                number = ".".join([str(chapter)] + [str(counters[k]) for k in range(2, lvl + 1)])
                current_section = f"{number} {plain}"
            else:
                current_section = plain
        elif CAPTION_RE.match(t):
            kind = "caption"
        elif NOTE_PARA_RE.match(t):
            kind = "note"
        elif region == "refs":
            kind = "ref"
        elif region == "front":
            kind = "front"
        elif "list" in sname.lower() or "lista" in sname.lower():
            kind = "list"
        paras.append(Para(idx=i, text=text, style=sname, level=lvl, kind=kind, number=number,
                          chapter=chapter if in_chapter else None, section=current_section,
                          region=region, has_note_ref=has, el=p._p))
    return paras


def table_cells(doc, paras: list[Para]) -> list[Para]:
    """Párrafos dentro de tablas (kind «cell»), ubicados por el párrafo de cuerpo anterior."""
    out: list[Para] = []
    last = None
    n_tbl = 0
    pi = -1
    for child in doc.element.body.iterchildren():
        if child.tag == qn("w:p"):
            pi += 1
            last = paras[pi] if pi < len(paras) else last
        elif child.tag == qn("w:tbl"):
            n_tbl += 1
            for tc_p in child.iter(qn("w:p")):
                text, has = para_text_with_notes(tc_p)
                if not text.strip():
                    continue
                ref = last
                where = f"tabla {n_tbl}, tras párr. {ref.idx if ref else 0}"
                if ref is not None and ref.section:
                    where += f" (§{ref.section})"
                out.append(Para(idx=ref.idx if ref else 0, text=text, style="cell", level=None, kind="cell",
                                chapter=ref.chapter if ref else None, section=ref.section if ref else "",
                                region=ref.region if ref else "front", has_note_ref=has, el=tc_p, where=where))
    return out


def mark_template_paras(paras: list[Para], profile: dict) -> None:
    pats = [re.compile(x, re.I) for x in profile.get("marcadores_plantilla", [])]
    for p in paras:
        if p.kind in ("body", "front", "list", "ref") and any(r.search(p.plain) for r in pats):
            p.kind = "template"


def open_docx(path: str):
    return docx.Document(path)


def notes_parts(doc):
    """Devuelve dict {'endnotes': part|None, 'footnotes': part|None}."""
    out = {"endnotes": None, "footnotes": None}
    for rel in doc.part.rels.values():
        if rel.reltype.endswith("/endnotes"):
            out["endnotes"] = rel.target_part
        elif rel.reltype.endswith("/footnotes"):
            out["footnotes"] = rel.target_part
    return out


def read_notes(part, kind: str) -> list[tuple[int, str]]:
    """Lista (id, texto) de notas reales (sin separadores)."""
    if part is None:
        return []
    from lxml import etree
    root = etree.fromstring(part.blob)
    res = []
    for n in root.findall(qn(f"w:{kind}")):
        if n.get(qn("w:type")) in ("separator", "continuationSeparator", "continuationNotice"):
            continue
        nid = int(n.get(qn("w:id")))
        txt = "".join(t.text or "" for t in n.iter(qn("w:t")))
        res.append((nid, txt.strip()))
    return res
