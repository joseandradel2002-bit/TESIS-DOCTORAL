---
name: tesis-writer-es
description: >-
  Redacta, revisa y corrige capítulos de tesis y trabajos de titulación en español (TIC, TFG,
  tesis de grado o maestría) con reglas de estilo estrictas, formato institucional (UTPL por
  defecto, perfiles para otras universidades), APA 7, escritura humanizada e investigación con
  doble verificación de DOI. Úsala cuando el usuario pida "redactar un capítulo", "escribir el
  marco teórico/metodología/resultados", "revisar mi tesis", "auditar el formato", "corregir el
  borrador", "verificar referencias", "buscar artículos para la tesis", "poner notas al final",
  "citar mi repositorio", o entregue un .docx de tesis. También en inglés: "write my thesis
  chapter", "review my thesis draft", "check thesis formatting", "verify thesis references".
---

# tesis-writer-es

Guía para que el agente redacte y revise capítulos de tesis en español con calidad de entrega.
Combina reglas de estilo del autor (no negociables), formato institucional, APA 7, escritura
humanizada y la metodología de redacción, revisión y búsqueda de academic-research-skills (ARS),
con scripts que auditan y corrigen el `.docx` sin romper su formato.

`<skill>` = directorio de esta skill (el que contiene este SKILL.md). Requisito: `python3 -m pip install python-docx`.

---

## 1. Jerarquía de reglas

Cuando dos guías choquen, gana la de arriba:

1. **Reglas de oro** (sección 2) — del usuario, siempre.
2. **Formato del documento del usuario / perfil institucional** (`profiles/`, por defecto UTPL).
3. **APA 7 en español** (`references/apa7-es.md`).
4. **Escritura humanizada** (`references/humanizacion.md`), sin violar 1–3.
5. **Metodología ARS** de redacción, revisión y búsqueda, sin violar 1–4.

Conflictos ya resueltos: ARS sugiere «plantear una pregunta» en la introducción → se redacta
como afirmación. ARS usa Title Case en títulos → tipo oración. El humanizador recomienda
preguntas y coloquialismos → prohibidos aquí. ARS rechaza el metacomentario → los párrafos
introductorios se mantienen pero con sustancia.

## 2. Reglas de oro

Detalle, ejemplos antes/después y casos límite en `references/reglas-de-oro.md`. Código entre
corchetes = regla que comprueba `audit_tesis.py`.

- **[R01] Nunca preguntas en el texto.** Todo se afirma. Única excepción: la pregunta de
  investigación formal en su apartado. Nada de «¿Por qué…? Porque…», ni preguntas en títulos, ni
  «cabe preguntarse si…».
- **[R02] Notas al final** con la marca `[Insertar nota al final: …]` pegada a la palabra:
  - librerías o herramientas **realmente clave** del proyecto (p. ej. Brian2): en su primera
    aparición, enlace a la documentación oficial;
  - conceptos complejos que se repiten poco y aparecen lejos del marco teórico (p. ej.
    «colinérgicas» en el capítulo 5): nota en su primera aparición **lejana** (no donde se define),
    con una definición de **una sola línea**, nunca más.
  - Las notas al pie que el autor dejó como recordatorio («Enlace a la librería X») no se copian:
    se reescriben con su contenido final (`insert_endnotes.py --from-footnotes --rewrite`).
- **[R03] Párrafo introductorio de capítulo:** tras el título del capítulo y antes de x.1, un
  párrafo breve sobre qué trata el capítulo.
- **[R04] Introducción de sección:** al entrar en cada sección de primer nivel x.x, 3–4 líneas
  (≈ 40–80 palabras) que expliquen de qué trata, antes de sus subsecciones o su contenido.
- **[R05] Sin «Elaboración propia».** Lo propio se sobreentiende. Lo ajeno lleva su cita APA
  («Tomado de…», «Adaptado de…», «Datos tomados de…»).
- **[R06] El repositorio propio se cita como repositorio**, nunca como autocita de los autores:
  `(nombre-repo, año)` + nota al final con la URL directa cuando se nombra un archivo concreto;
  en Referencias, entrada APA de software/repositorio.
- **[R07] Títulos en tipo oración:** mayúscula solo en la primera palabra y en nombres propios
  (librerías, especies, personas, instituciones, siglas). Especies: *Drosophila melanogaster*
  (epíteto siempre en minúscula). Aplica también a títulos de tablas y figuras.
- **[R15] Introducción de tablas y figuras:** justo antes de cada tabla o figura, un párrafo de
  2–3 líneas (≈ 15–60 palabras), nunca más, que la nombre por su número y diga qué muestra: «La
  figura 10 resume el recorrido de los datos…», «La tabla 8 compara…». No vale «la tabla
  siguiente» sin número ni una mención perdida al final de un párrafo largo.
- **[R08] Revisión de documentos con contenido** según `references/metodologia-revision.md`.
- **[R09] Ante cualquier duda, preguntar al usuario con opciones** (sección 3). Nunca suponer ni
  inventar datos.
- **[R10] Escritura humanizada** desde el primer borrador (`references/humanizacion.md`).
- **[R11] Metodología ARS** de redacción, revisión y búsqueda (`references/metodologia-*.md`,
  `references/investigacion-fuentes.md`).
- **[R12] Formato académico** del documento/perfil (`references/formato-utpl.md`).
- **[R13] APA 7 y citas** (`references/apa7-es.md`).
- **[R14] Investigación exhaustiva con doble verificación:** solo artículos relevantes y de
  renombre, con DOI comprobado en dos fuentes (`scripts/verify_refs.py`).

## 3. Protocolo de preguntas (R09)

- Usar la herramienta de preguntas con opciones (AskUserQuestion o equivalente): 2–4 opciones
  mutuamente excluyentes, la recomendada primero con «(Recomendado)», descripción breve de cada
  una. Agrupar hasta 4 dudas en una sola llamada para no interrumpir de más.
- Si la herramienta no existe en el entorno, preguntar en texto con opciones numeradas y esperar.
- Preguntar **siempre** sobre: datos del proyecto que no constan (cifras, fechas, URL, versiones),
  autoría de figuras/tablas dudosas, si una librería es clave, si una palabra de un título es
  nombre propio, si una fuente dudosa (preprint, gris) es aceptable, aplicar correcciones
  masivas, cambiar títulos o estructura, convertir notas al pie en notas al final.
- No preguntar lo que se resuelve leyendo el documento, el repositorio o la config.
- Guardar las respuestas reutilizables en `tesis.config.json` (nombres propios, términos con
  nota, autores, repositorio) para no repetir la pregunta.
- Las preguntas al usuario nunca aparecen dentro del texto de la tesis.

## 4. Configuración del proyecto

La primera vez en un proyecto, crear `tesis.config.json` junto al `.docx` (o en el directorio de
trabajo) a partir de `<skill>/templates/tesis.config.example.json`:
1. Extraer del documento lo que se pueda (autores, título, repositorio mencionado, librerías).
2. Preguntar al usuario lo que falte con una sola ronda de opciones (perfil institucional,
   librerías clave, URL y nombre del repositorio, persona gramatical si no es evidente).
3. Los scripts lo leen automáticamente.

## 5. Modos de trabajo

Detectar el modo por la petición; si es ambiguo, preguntar con opciones.

### A. Redactar un capítulo nuevo
Seguir `references/metodologia-redaccion.md` (F0–F7) y `references/estructura-capitulos.md`:
1. Contexto: `dump_docx.py tesis.docx --outline`, capítulos vecinos, repositorio, config.
2. Ficha + esquema (`templates/ficha-capitulo.md`) → **aprobación del usuario**.
3. Plano argumental; fuentes nuevas por la ruta del modo D.
4. Redactar sección a sección aplicando las reglas de oro desde la primera línea.
5. Autorrevisión: auditoría del capítulo y lista «Reglas de oro (juicio)» de la metodología de revisión.
6. Entregar en el formato pedido (sección 6).

### B. Revisar un documento existente (R08)
`references/metodologia-revision.md`: dump → `audit_tesis.py` → `verify_refs.py` → revisión
experta con la lista → informe (`templates/informe-revision.md`). **No modificar el documento**
en este modo; terminar preguntando qué correcciones aplicar.

### C. Corregir (aplicar la revisión)
Con aprobación: operaciones JSON → `edit_docx.py` (archivo nuevo `_v2`) → `insert_endnotes.py`
(`_v3`) → re-auditar y mostrar el antes/después de los recuentos. Para una segunda pasada,
volver a ejecutar `dump_docx.py`/`audit_tesis.py` sobre la última versión: los índices cambian. Cambios de títulos, de número
de secciones o reescrituras > 60 % de un capítulo requieren confirmación explícita.

### D. Investigar fuentes
`references/investigacion-fuentes.md`: parámetros fijados antes de buscar, cuatro capas
(booleana, hacia atrás, hacia adelante, semántica), criterios de relevancia y renombre, lectura
de la fuente, doble verificación del DOI, matriz de evidencia (`templates/matriz-evidencia.md`).
Nunca proponer una referencia que no haya pasado la verificación (tabla de la sección 5E).

### E. Verificar referencias
`verify_refs.py --docx tesis.docx` (o `--txt`, `--doi`) + verificación manual de contexto (la
fuente dice lo que se le atribuye). Qué significa «pasar» la verificación:

| Estado | ¿Puede entrar? |
|---|---|
| VERIFICADO | sí |
| VERIFICADO-1 | datasets, software y documentación: sí. Artículos: solo tras confirmar el registro en la web de la editorial |
| SIN-DOI (libro, capítulo, norma, web) | sí, si se verificó a mano (editorial/ISBN en WorldCat o Google Books, URL viva) y se anotó en la matriz de evidencia |
| SIN-DOI-SUGERIDO | solo después de volver a verificar el DOI propuesto y añadirlo |
| DISCREPANCIA | no, hasta corregir los metadatos con la obra real |
| NO-RESUELVE, RETRACTADO, SIN-METADATOS | no |
| SIN-CONEXION | inconcluso: repetir con red |

### F. Humanizar un pasaje
`references/humanizacion.md` sin tocar citas, cifras ni nombres; sin introducir preguntas.

## 6. Formatos de entrega

- **Texto (Markdown):** títulos con su numeración y en tipo oración, notas como
  `palabra[Insertar nota al final: contenido]`, leyendas de tabla/figura en dos líneas
  («**Tabla 3**» / «*Título*») y «*Nota.*» solo si aplica. Al final, lista de notas, de figuras
  pendientes y de `[FALTA DATO: …]`.
- **Word (.docx):** nunca regenerar el documento. Editar en sitio con `edit_docx.py` (conserva
  estilos, numeración automática y notas) y convertir marcas con `insert_endnotes.py`. Siempre a
  un archivo nuevo versionado; el original no se toca.

## 7. Scripts

Todos aceptan `--help`. Índices de párrafo compartidos entre scripts.

| Script | Uso |
|---|---|
| `dump_docx.py tesis.docx [--outline] [--chapter N] [--from A --to B] [--json]` | mapa del documento: índice, tipo, numeración calculada (4.2.1) |
| `audit_tesis.py tesis.docx [--chapter N] [--only R01,R07] [--out informe.md] [--json h.json] [--strict]` | auditoría de reglas de oro, formato, APA, humanización, remisiones |
| `edit_docx.py tesis.docx ediciones.json -o tesis_v2.docx [--dry-run]` | `replace`, `replace_in`, `insert_after`, `insert_before`, `delete`, `heading` |
| `insert_endnotes.py tesis_v2.docx -o tesis_v3.docx [--from-footnotes] [--numfmt decimal]` | marcas → notas al final reales (arábigas, URL como hipervínculo en negro) |
| `verify_refs.py --docx tesis.docx \| --txt refs.txt \| --doi … [--mailto CORREO] [--out v.md]` | DOI en doi.org + Crossref/DataCite + OpenAlex; retractaciones; DOI sugeridos |

Ejemplo de `ediciones.json` para corregir hallazgos típicos (índices `p` tomados de `dump_docx.py`
o del informe de auditoría del **mismo** archivo; tras cada pasada los índices cambian, así que
para la siguiente se vuelve a ejecutar `dump_docx.py` sobre la versión nueva):
```json
[
 {"op": "replace_in", "p": 120, "find": "¿Por qué ocupa esto un capítulo entero? Porque los datos",
  "repl": "Esto ocupa un capítulo entero porque los datos"},
 {"op": "heading", "p": 45, "text": "El agotamiento del paradigma actual de la inteligencia artificial"},
 {"op": "insert_after", "p": 43, "text": "Este capítulo plantea el problema que motiva el trabajo…"},
 {"op": "replace_in", "p": 60, "find": "simulador Brian2", "repl": "simulador Brian2[Insertar nota al final: https://brian2.readthedocs.io/]"},
 {"op": "replace_in", "p": 88, "find": "(Apellido1 y Apellido2, 2026)", "repl": "(nombre-repo, 2026)"},
 {"op": "insert_before", "p": 102, "text": "La tabla 4 compara la exactitud de los seis brazos experimentales; la última columna indica cuántas presentaciones necesitó cada uno."},
 {"op": "delete", "p": 97}
]
```
`replace_in` no puede cruzar una nota, una tabulación o un salto de línea (se niega para no
moverlos); en ese caso acotar `find` a un fragmento sin ellos.

## 8. Archivos de referencia (cargar cuando haga falta)

| Archivo | Cuándo |
|---|---|
| `references/reglas-de-oro.md` | siempre que se redacte o revise; ejemplos y casos límite de R01–R09 |
| `references/metodologia-redaccion.md` | modo A |
| `references/estructura-capitulos.md` | modo A; plantillas de párrafo introductorio |
| `references/metodologia-revision.md` | modos B y C |
| `references/investigacion-fuentes.md` | modos D y E, y cada vez que entre una cita nueva |
| `references/apa7-es.md` | citas, referencias, tablas, figuras, números, siglas |
| `references/humanizacion.md` | redacción y modo F |
| `references/formato-utpl.md` | formato; cómo añadir otra institución |
| `profiles/*.json` | perfiles que lee la auditoría |
| `templates/*` | config, ficha de capítulo, informe de revisión, matriz de evidencia |

## 9. Nunca

- Inventar datos, cifras, fechas, URL, DOI o referencias. Lo que falta se marca `[FALTA DATO: …]`
  y se pregunta.
- Citar algo que no pasó la doble verificación, ni una obra retractada como evidencia.
- Escribir preguntas en el texto (fuera de la pregunta de investigación).
- Escribir «Elaboración propia» o autocitar a los autores por su repositorio.
- Títulos en Title Case.
- Sobrescribir el `.docx` original o regenerarlo desde cero.
- Cambiar citas, cifras o nombres propios al reescribir o humanizar.
- Prometer un porcentaje de detector de IA.

## 10. Lista final antes de entregar

- [ ] `audit_tesis.py` sin ERROR en el alcance trabajado (o cada ERROR restante explicado al usuario).
- [ ] Todas las referencias nuevas «pasan» según la tabla de la sección 5E.
- [ ] Notas al final en la primera aparición de cada término configurado; ninguna de más de una línea.
- [ ] Cada tabla/figura precedida por su párrafo de presentación de 2–3 líneas (R15), con leyenda en formato del perfil y sin «Elaboración propia».
- [ ] Párrafo introductorio en el capítulo y en cada sección x.x.
- [ ] Títulos en tipo oración; especies bien escritas.
- [ ] Sin preguntas; métricas de humanización dentro de rango.
- [ ] Datos faltantes y decisiones del usuario listados en el mensaje de entrega.

## 11. Otras skills (opcionales)

Esta skill es autosuficiente. Si están instaladas, se pueden combinar:
- `my-humanizer-es-en`: cuando el usuario trae un informe PDF de Compilatio/Turnitin (modo
  report-driven); respetando R01 (no introducir preguntas).
- `academic-research-skills`: `deep-research` para revisiones sistemáticas grandes y
  `academic-paper-reviewer` para una revisión por pares simulada; sus salidas se ajustan a las
  reglas de oro antes de entrar a la tesis.
