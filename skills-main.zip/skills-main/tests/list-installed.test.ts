import { describe, it, expect, beforeAll, beforeEach, afterEach, afterAll, vi } from 'vitest';
import { mkdir, mkdtemp, writeFile, rm, symlink } from 'fs/promises';
import { join } from 'path';
import { tmpdir } from 'os';
import { createTestHomeEnvironment } from '../src/test-utils.ts';

let listInstalledSkills: typeof import('../src/installer.ts').listInstalledSkills;
let agentsModule: typeof import('../src/agents.ts');

describe('listInstalledSkills', () => {
  let testDir: string;
  let testHome: string;

  beforeAll(async () => {
    testHome = await mkdtemp(join(tmpdir(), 'skills-list-installed-home-'));

    for (const [name, value] of Object.entries(createTestHomeEnvironment(testHome))) {
      vi.stubEnv(name, value);
    }

    vi.resetModules();
    agentsModule = await import('../src/agents.ts');
    ({ listInstalledSkills } = await import('../src/installer.ts'));
  });

  beforeEach(async () => {
    testDir = join(tmpdir(), `add-skill-test-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    await mkdir(testDir, { recursive: true });
  });

  afterEach(async () => {
    vi.restoreAllMocks();
    await rm(testDir, { recursive: true, force: true });
  });

  afterAll(async () => {
    vi.unstubAllEnvs();
    await rm(testHome, { recursive: true, force: true });
  });

  // Helper to create a skill directory with SKILL.md
  async function createSkillDir(
    basePath: string,
    skillName: string,
    skillData: { name: string; description: string }
  ): Promise<string> {
    const skillDir = join(basePath, '.agents', 'skills', skillName);
    await mkdir(skillDir, { recursive: true });
    const skillMdContent = `---
name: ${skillData.name}
description: ${skillData.description}
---

# ${skillData.name}

${skillData.description}
`;
    await writeFile(join(skillDir, 'SKILL.md'), skillMdContent);
    return skillDir;
  }

  it('should return empty array for empty directory', async () => {
    const skills = await listInstalledSkills({ global: false, cwd: testDir });
    expect(skills).toEqual([]);
  });

  it('should find single skill in project directory', async () => {
    await createSkillDir(testDir, 'test-skill', {
      name: 'test-skill',
      description: 'A test skill',
    });

    const skills = await listInstalledSkills({ global: false, cwd: testDir });
    expect(skills).toHaveLength(1);
    expect(skills[0]!.name).toBe('test-skill');
    expect(skills[0]!.description).toBe('A test skill');
    expect(skills[0]!.scope).toBe('project');
  });

  it('should find multiple skills', async () => {
    await createSkillDir(testDir, 'skill-1', {
      name: 'skill-1',
      description: 'First skill',
    });
    await createSkillDir(testDir, 'skill-2', {
      name: 'skill-2',
      description: 'Second skill',
    });

    const skills = await listInstalledSkills({ global: false, cwd: testDir });
    expect(skills).toHaveLength(2);
    const skillNames = skills.map((s) => s.name).sort();
    expect(skillNames).toEqual(['skill-1', 'skill-2']);
  });

  it('should ignore directories without SKILL.md', async () => {
    await createSkillDir(testDir, 'valid-skill', {
      name: 'valid-skill',
      description: 'Valid skill',
    });

    // Create a directory without SKILL.md
    const invalidDir = join(testDir, '.agents', 'skills', 'invalid-skill');
    await mkdir(invalidDir, { recursive: true });
    await writeFile(join(invalidDir, 'other-file.txt'), 'content');

    const skills = await listInstalledSkills({ global: false, cwd: testDir });
    expect(skills).toHaveLength(1);
    expect(skills[0]!.name).toBe('valid-skill');
  });

  it('should handle invalid SKILL.md gracefully', async () => {
    await createSkillDir(testDir, 'valid-skill', {
      name: 'valid-skill',
      description: 'Valid skill',
    });

    // Create a directory with invalid SKILL.md (missing name/description)
    const invalidDir = join(testDir, '.agents', 'skills', 'invalid-skill');
    await mkdir(invalidDir, { recursive: true });
    await writeFile(join(invalidDir, 'SKILL.md'), '# Invalid\nNo frontmatter');

    const skills = await listInstalledSkills({ global: false, cwd: testDir });
    expect(skills).toHaveLength(1);
    expect(skills[0]!.name).toBe('valid-skill');
  });

  it('should filter by scope - project only', async () => {
    await createSkillDir(testDir, 'project-skill', {
      name: 'project-skill',
      description: 'Project skill',
    });

    const skills = await listInstalledSkills({ global: false, cwd: testDir });
    expect(skills).toHaveLength(1);
    expect(skills[0]!.scope).toBe('project');
  });

  it('should handle global scope option', async () => {
    vi.spyOn(agentsModule, 'detectInstalledAgents').mockResolvedValue([]);

    const skills = await listInstalledSkills({
      global: true,
      cwd: testDir,
    });

    expect(skills).toEqual([]);
  });

  it('attributes global canonical skills to universal agents with native global dirs', async () => {
    vi.spyOn(agentsModule, 'detectInstalledAgents').mockResolvedValue(['opencode']);

    const skillDir = join(testHome, '.agents', 'skills', 'opencode-global-attribution-test');
    await mkdir(skillDir, { recursive: true });
    await writeFile(
      join(skillDir, 'SKILL.md'),
      `---
name: opencode-global-attribution-test
description: Test OpenCode global attribution
---

# opencode-global-attribution-test
`
    );

    try {
      const skills = await listInstalledSkills({
        global: true,
        agentFilter: ['opencode'],
      });

      const skill = skills.find((s) => s.name === 'opencode-global-attribution-test');
      expect(skill).toBeDefined();
      expect(skill!.agents).toContain('opencode');
    } finally {
      await rm(skillDir, { recursive: true, force: true });
    }
  });

  it('should apply agent filter', async () => {
    await createSkillDir(testDir, 'test-skill', {
      name: 'test-skill',
      description: 'Test skill',
    });

    // Filter by a specific agent (skill should still be returned)
    const skills = await listInstalledSkills({
      global: false,
      cwd: testDir,
      agentFilter: ['cursor'] as any,
    });
    expect(skills).toHaveLength(1);
    expect(skills[0]!.name).toBe('test-skill');
  });

  // Issue #225 part 1: Only installed agents should be attributed
  it('should only attribute skills to installed agents (issue #225)', async () => {
    // Mock: only Amp is installed (not Kimi, even though they share .agents/skills)
    vi.spyOn(agentsModule, 'detectInstalledAgents').mockResolvedValue(['amp']);

    await createSkillDir(testDir, 'test-skill', {
      name: 'test-skill',
      description: 'Test skill',
    });

    const skills = await listInstalledSkills({ global: false, cwd: testDir });

    expect(skills).toHaveLength(1);
    // Should only show amp, not kimi-code-cli
    expect(skills[0]!.agents).toContain('amp');
    expect(skills[0]!.agents).not.toContain('kimi-code-cli');
  });

  // Directory symlinks pointing at a real skill dir should be discovered.
  it('should find skill when the skill directory is a symlink', async () => {
    const realSkillDir = join(testDir, 'shared', 'linked-skill');
    await mkdir(realSkillDir, { recursive: true });
    await writeFile(
      join(realSkillDir, 'SKILL.md'),
      `---
name: linked-skill
description: Skill reached through a directory symlink
---

# linked-skill
`
    );

    const agentSkillsDir = join(testDir, '.agents', 'skills');
    await mkdir(agentSkillsDir, { recursive: true });
    await symlink(realSkillDir, join(agentSkillsDir, 'linked-skill'), 'dir');

    const skills = await listInstalledSkills({ global: false, cwd: testDir });
    expect(skills).toHaveLength(1);
    expect(skills[0]!.name).toBe('linked-skill');
  });

  it('should ignore dangling symlinks without a reachable SKILL.md', async () => {
    const agentSkillsDir = join(testDir, '.agents', 'skills');
    await mkdir(agentSkillsDir, { recursive: true });
    await symlink(join(testDir, 'does-not-exist'), join(agentSkillsDir, 'broken'), 'dir');

    const skills = await listInstalledSkills({ global: false, cwd: testDir });
    expect(skills).toEqual([]);
  });

  it('should ignore symlinks that point to a regular file', async () => {
    const filePath = join(testDir, 'not-a-skill.md');
    await writeFile(filePath, '# not a skill');

    const agentSkillsDir = join(testDir, '.agents', 'skills');
    await mkdir(agentSkillsDir, { recursive: true });
    await symlink(filePath, join(agentSkillsDir, 'file-link'));

    const skills = await listInstalledSkills({ global: false, cwd: testDir });
    expect(skills).toEqual([]);
  });

  // Issue #225 part 2: Skills in agent-specific directories should be found
  it('should find skills in agent-specific directories (issue #225)', async () => {
    vi.spyOn(agentsModule, 'detectInstalledAgents').mockResolvedValue(['cursor']);

    // Cursor now uses .agents/skills (universal directory)
    const cursorSkillDir = join(testDir, '.agents', 'skills', 'cursor-skill');
    await mkdir(cursorSkillDir, { recursive: true });
    await writeFile(
      join(cursorSkillDir, 'SKILL.md'),
      `---
name: cursor-skill
description: A skill in cursor directory
---

# cursor-skill
`
    );

    const skills = await listInstalledSkills({ global: false, cwd: testDir });

    expect(skills).toHaveLength(1);
    expect(skills[0]!.name).toBe('cursor-skill');
    expect(skills[0]!.agents).toContain('cursor');
  });
});
