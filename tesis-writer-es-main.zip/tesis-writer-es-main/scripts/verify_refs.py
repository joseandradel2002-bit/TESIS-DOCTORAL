#!/usr/bin/env python3
"""Doble verificación de referencias: el DOI existe y sus metadatos coinciden en dos fuentes independientes.

Uso:
  python3 verify_refs.py --docx tesis.docx                 # lee la sección «Referencias»
  python3 verify_refs.py --txt referencias.txt             # una referencia APA por línea
  python3 verify_refs.py --doi 10.1038/s41586-024-07558-y 10.1038/s41586-024-07763-9
  python3 verify_refs.py --txt refs.txt --out verificacion.md --json verificacion.json --mailto tu@correo

Protocolo por referencia:
  1. doi.org (Handle API): ¿el DOI existe?
  2. Fuente A: Crossref (o DataCite para datasets/software/Zenodo): título, autores, año, revista, tipo.
  3. Fuente B: OpenAlex: título, año, citas, retractación, tipo de fuente.
  4. Se compara con la referencia escrita (título ≥ 0,85 de similitud, año ±1, primer apellido).
  5. Sin DOI: búsqueda bibliográfica en Crossref para proponer uno (nunca se acepta sin confirmar).

Estados: VERIFICADO (2 fuentes) · VERIFICADO-1 (una fuente) · DISCREPANCIA · NO-RESUELVE · RETRACTADO ·
         SIN-DOI (libro, web, norma: verificar a mano) · SIN-DOI-SUGERIDO.
Se necesita conexión a internet. Respuestas en caché en .refcache.json para no repetir consultas.
"""
from __future__ import annotations

import argparse
import difflib
import json
import re
import shutil
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

DOI_RE = re.compile(r"10\.\d{4,9}/[^\s\"<>]+", re.I)
YEAR_RE = re.compile(r"\((\d{4})[a-z]?(?:,[^)]*)?\)|\((s\. ?f\.)\)")
UA = "tesis-writer-es/1.0 (https://github.com/ljmor/tesis-writer-es)"
CACHE: dict = {}
CACHE_PATH = Path(".refcache.json")


def sim(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    import unicodedata

    def clean(x):
        x = "".join(c for c in unicodedata.normalize("NFD", x) if unicodedata.category(c) != "Mn")
        x = re.sub(r"<[^>]+>", " ", x)
        return " ".join(re.sub(r"[^a-z0-9 ]+", " ", x.lower()).split())
    a, b = clean(a), clean(b)
    if not a or not b:
        return 0.0
    if (a in b or b in a) and min(len(a), len(b)) / max(len(a), len(b)) >= 0.6:
        return 1.0
    return difflib.SequenceMatcher(None, a, b).ratio()


def _ssl_context():
    try:
        import certifi  # opcional: corrige el Python de python.org en macOS sin certificados
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        return ssl.create_default_context()


SSL_CTX = _ssl_context()


def _curl_json(url):
    """Respaldo con curl del sistema (verifica certificados con el almacén del SO)."""
    if not shutil.which("curl"):
        return {"_error": "SSL sin certificados y sin curl (instala certifi)"}
    r = subprocess.run(["curl", "-sS", "-L", "-m", "25", "-A", UA, "-H", "Accept: application/json",
                        "-w", "\n%{http_code}", url], capture_output=True, text=True)
    body, _, code = r.stdout.rpartition("\n")
    if code == "404":
        return None
    if r.returncode != 0 or not code.startswith("2"):
        return {"_error": f"curl {r.returncode} HTTP {code}"}
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        return {"_error": "respuesta no JSON"}


def get_json(url: str, mailto: str | None = None, retries: int = 2):
    if mailto and ("api.crossref.org" in url or "api.openalex.org" in url):
        url += ("&" if "?" in url else "?") + "mailto=" + urllib.parse.quote(mailto)
    if url in CACHE:
        return CACHE[url]
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=25, context=SSL_CTX) as r:
                data = json.loads(r.read().decode("utf-8"))
                CACHE[url] = data
                time.sleep(0.15)
                return data
        except urllib.error.HTTPError as e:  # antes que URLError: es su subclase
            if e.code == 404:
                CACHE[url] = None
                return None
            if e.code == 429 and attempt < retries:
                time.sleep(2 * (attempt + 1))
                continue
            if attempt == retries:
                return {"_error": f"HTTP {e.code}"}
        except urllib.error.URLError as e:
            if isinstance(getattr(e, "reason", None), ssl.SSLCertVerificationError):
                data = _curl_json(url)
                if data is None or "_error" not in data:
                    CACHE[url] = data
                time.sleep(0.15)
                return data
            if attempt == retries:
                return {"_error": str(e)[:80]}
            time.sleep(1.5)
        except (TimeoutError, json.JSONDecodeError) as e:
            if attempt == retries:
                return {"_error": str(e)[:80]}
            time.sleep(1.5)
    return None


def parse_ref(raw: str) -> dict:
    ref = {"raw": raw.strip()}
    m = DOI_RE.search(raw)
    if m:
        ref["doi"] = m.group(0).rstrip(".,;)").rstrip("]")
    y = YEAR_RE.search(raw)
    if y:
        ref["year"] = y.group(1) or y.group(2)
        after = raw[y.end():].lstrip(". ")
        # título: hasta el primer punto/interrogación que cierra la frase (APA: Título. Revista, vol(n), pp.)
        t = re.split(r"(?<=[^A-Z])[.?!]\s+(?=[A-ZÁÉÍÓÚÑ\[]|https?://)", after, maxsplit=1)[0]
        ref["title"] = re.sub(r"\s*\[[^\]]+\]\s*$", "", t).strip()
        ref["authors"] = raw[:y.start()].strip()
    if y:
        first = re.split(r",|\.|\s\(", raw.strip(), maxsplit=1)[0]
        ref["first_author"] = first.strip()
    return ref


def surname_ok(ref_first: str, names: list[str]) -> bool:
    """El primer apellido escrito aparece en alguno de los tres primeros autores (nombre completo o apellido)."""
    if not names:
        return True
    import unicodedata

    def toks(x):
        x = "".join(c for c in unicodedata.normalize("NFD", x or "") if unicodedata.category(c) != "Mn")
        return re.findall(r"[a-z]+", x.lower())
    want = toks(ref_first)
    if not want:
        return True
    for n in names[:3]:
        have = toks(n)
        if all(w in have for w in want) or sim(ref_first, n) > 0.85:
            return True
    return False


def crossref(doi, mailto):
    d = get_json(f"https://api.crossref.org/works/{urllib.parse.quote(doi)}", mailto)
    if not d or "_error" in d:
        return d
    w = d.get("message", {})
    yr = None
    for k in ("published-print", "published-online", "issued", "created"):
        dp = (w.get(k) or {}).get("date-parts") or [[None]]
        if dp[0][0]:
            yr = dp[0][0]
            break
    return {
        "source": "Crossref",
        "title": ": ".join(x for x in [(w.get("title") or [""])[0], (w.get("subtitle") or [""])[0]] if x),
        "authors": [" ".join(x for x in (a.get("given"), a.get("family")) if x) or a.get("name", "")
                    for a in w.get("author", [])],
        "year": yr, "venue": (w.get("container-title") or [""])[0] or w.get("publisher", ""),
        "type": w.get("type"), "cites": w.get("is-referenced-by-count"),
        "retracted": any(u.get("type") in ("retraction", "removal") for u in w.get("update-to", []) or [])
        or any("retract" in (u.get("label", "") + u.get("type", "")).lower() for u in (w.get("updated-by") or [])),
    }


def datacite(doi):
    d = get_json(f"https://api.datacite.org/dois/{urllib.parse.quote(doi)}")
    if not d or "_error" in d:
        return d
    at = d.get("data", {}).get("attributes", {})
    return {
        "source": "DataCite", "title": ((at.get("titles") or [{}])[0]).get("title", ""),
        "authors": [" ".join(x for x in (c.get("givenName"), c.get("familyName")) if x) or c.get("name", "")
                    for c in at.get("creators", [])],
        "year": at.get("publicationYear"), "venue": at.get("publisher", ""),
        "type": (at.get("types") or {}).get("resourceTypeGeneral"), "cites": at.get("citationCount"), "retracted": False,
    }


def openalex(doi, mailto):
    d = get_json(f"https://api.openalex.org/works/https://doi.org/{urllib.parse.quote(doi)}", mailto)
    if not d or "_error" in d:
        return d
    src = ((d.get("primary_location") or {}).get("source") or {})
    return {
        "source": "OpenAlex", "title": d.get("display_name") or d.get("title") or "",
        "authors": [(a.get("author") or {}).get("display_name") or "" for a in d.get("authorships", [])],
        "year": d.get("publication_year"), "venue": src.get("display_name", ""), "venue_type": src.get("type"),
        "type": d.get("type"), "cites": d.get("cited_by_count"), "retracted": bool(d.get("is_retracted")),
    }


def doi_exists(doi):
    d = get_json(f"https://doi.org/api/handles/{urllib.parse.quote(doi)}")
    if d is None:
        return False
    if "_error" in d:
        return None
    return d.get("responseCode") == 1


def compare(ref, meta):
    issues = []
    if not meta or "_error" in meta:
        return None, ["sin respuesta"]
    if ref.get("title"):
        s = sim(ref["title"], meta["title"])
        if s < 0.85 and ":" in ref["title"] and ":" not in meta["title"]:
            s = max(s, sim(ref["title"].split(":")[0], meta["title"]))  # la fuente guarda el subtítulo aparte
        if s < 0.85:
            issues.append(f"título distinto ({s:.2f}): «{meta['title'][:90]}»")
    if ref.get("year") and str(ref["year"]).isdigit() and meta.get("year"):
        if abs(int(ref["year"]) - int(meta["year"])) > 1:
            issues.append(f"año {ref['year']} ≠ {meta['year']}")
    if ref.get("first_author") and not surname_ok(ref["first_author"], meta.get("authors", [])):
        issues.append(f"primer autor «{ref['first_author']}» ≠ «{(meta.get('authors') or ['?'])[0]}»")
    return not issues, issues


def search_crossref(ref, mailto):
    q = ref.get("title") or ref["raw"][:200]
    url = "https://api.crossref.org/works?rows=3&select=DOI,title,subtitle,author,issued,container-title&query.bibliographic=" + \
        urllib.parse.quote(q)
    if ref.get("first_author"):
        url += "&query.author=" + urllib.parse.quote(ref["first_author"])
    d = get_json(url, mailto)
    if not d or "_error" in d:
        return None
    best = None
    for it in d.get("message", {}).get("items", []):
        t = ": ".join(x for x in [(it.get("title") or [""])[0], (it.get("subtitle") or [""])[0]] if x)
        rt = ref.get("title", "")
        s = sim(rt, t)
        if s < 0.9 and ":" in rt and ":" not in t:
            s = max(s, sim(rt.split(":")[0], t))
        if s >= 0.9 and (best is None or s > best[0]):
            best = (s, it.get("DOI"), t)
    return best


def verify(ref, mailto):
    out = {"ref": ref["raw"][:160], "doi": ref.get("doi", ""), "estado": "", "detalle": [], "citas": None,
           "fuente": "", "tipo": ""}
    if not ref.get("doi"):
        looks_article = bool(re.search(r"\d+\s*\(\d+\)|,\s*\d+\s*[,–-]\s*\d+", ref["raw"]))
        sug = search_crossref(ref, mailto) if ref.get("title") else None
        if sug:
            out["estado"] = "SIN-DOI-SUGERIDO"
            out["detalle"].append(f"posible DOI {sug[1]} («{sug[2][:70]}», similitud {sug[0]:.2f}); confirmar y volver a verificar")
        else:
            out["estado"] = "SIN-DOI"
            out["detalle"].append("artículo sin DOI: buscarlo" if looks_article else "libro/web/norma: verificar a mano (editorial, ISBN, URL viva)")
        return out
    doi = ref["doi"]
    ex = doi_exists(doi)
    if ex is False:
        out["estado"] = "NO-RESUELVE"
        out["detalle"].append("el DOI no existe en doi.org: posible referencia inventada o DOI mal copiado")
        return out
    a = crossref(doi, mailto)
    if a is None:
        a = datacite(doi)
    b = openalex(doi, mailto)
    oks = []
    for meta in (a, b):
        ok, issues = compare(ref, meta)
        if ok is None:
            continue
        oks.append(ok)
        if issues:
            out["detalle"].append(f"{meta['source']}: " + "; ".join(issues))
    metas = [m for m in (a, b) if m and "_error" not in m]
    if any(m.get("retracted") for m in metas):
        out["estado"] = "RETRACTADO"
        out["detalle"].insert(0, "el trabajo figura como retractado: no citar como evidencia")
    elif not oks:
        if ex is None and all(m is None or "_error" in m for m in (a, b) if m is not None):
            out["estado"] = "SIN-CONEXION"
            out["detalle"].append("no se pudo consultar ninguna API (red/SSL); repetir con conexión antes de concluir nada")
        else:
            out["estado"] = "SIN-METADATOS" if ex else "NO-RESUELVE"
            out["detalle"].append("el DOI existe pero no hay metadatos en Crossref/DataCite ni OpenAlex" if ex
                                  else "sin metadatos y doi.org no confirmó el DOI")
    elif all(oks):
        out["estado"] = "VERIFICADO" if len(oks) == 2 else "VERIFICADO-1"
    else:
        out["estado"] = "DISCREPANCIA"
    if metas and not ref.get("title"):  # modo --doi: mostrar qué obra es para que el usuario la reconozca
        m = metas[0]
        out["detalle"].insert(0, f"obra: {(m.get('authors') or ['?'])[0]} ({m.get('year')}). {m.get('title', '')[:90]}")
    if metas:
        m0 = b if b and "_error" not in b else metas[0]
        out["citas"] = max([m.get("cites") or 0 for m in metas])
        out["fuente"] = m0.get("venue", "")
        out["tipo"] = m0.get("type", "")
        if (m0.get("type") in ("preprint", "posted-content") or m0.get("venue_type") == "repository"):
            out["detalle"].append("preprint/repositorio: buscar versión revisada por pares")
    return out


def refs_from_docx(path):
    from _common import build_model, open_docx
    paras = build_model(open_docx(path))
    return [p.plain.strip() for p in paras if p.kind == "ref" and re.search(r"\(\d{4}|s\. ?f\.", p.plain)]


def main():
    global CACHE_PATH
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--docx")
    g.add_argument("--txt")
    g.add_argument("--doi", nargs="+")
    ap.add_argument("--mailto", help="correo para el «polite pool» de Crossref/OpenAlex (recomendado)")
    ap.add_argument("--out")
    ap.add_argument("--json")
    ap.add_argument("--cache", default=".refcache.json")
    a = ap.parse_args()

    if not a.mailto:
        from _common import load_config
        a.mailto = load_config(a.docx, None).get("mailto")
    CACHE_PATH = Path(a.cache)
    if CACHE_PATH.is_file():
        try:
            CACHE.update(json.loads(CACHE_PATH.read_text(encoding="utf-8")))
        except json.JSONDecodeError:
            pass
    if a.docx:
        raws = refs_from_docx(a.docx)
    elif a.txt:
        raws = [x for x in Path(a.txt).read_text(encoding="utf-8").splitlines() if x.strip()]
    else:
        raws = [d.strip() for d in a.doi]
    results = []
    for i, raw in enumerate(raws, 1):
        ref = parse_ref(raw)
        r = verify(ref, a.mailto)
        results.append(r)
        print(f"[{i}/{len(raws)}] {r['estado']:<17} {r['doi'] or r['ref'][:60]}", file=sys.stderr)
    CACHE_PATH.write_text(json.dumps(CACHE, ensure_ascii=False), encoding="utf-8")

    from collections import Counter
    c = Counter(r["estado"] for r in results)
    lines = ["# Verificación de referencias", "", " · ".join(f"{k}: {v}" for k, v in sorted(c.items())), "",
             "| # | Estado | DOI | Citas | Fuente | Detalle |", "|---|---|---|---|---|---|"]
    for i, r in enumerate(results, 1):
        det = "; ".join(r["detalle"]).replace("|", "/") or "—"
        lines.append(f"| {i} | {r['estado']} | {r['doi'] or '—'} | {r['citas'] if r['citas'] is not None else '—'} | "
                     f"{(r['fuente'] or '—')[:40]} | {det[:220]} |")
    lines += ["", "Referencias sin estado VERIFICADO no deben entrar en la tesis sin revisión manual.",
              "VERIFICADO-1: solo una fuente confirmó; aceptable para datasets/software, revisar en artículos."]
    md = "\n".join(lines) + "\n"
    if a.out:
        Path(a.out).write_text(md, encoding="utf-8")
        print(f"Informe: {a.out}", file=sys.stderr)
    else:
        print(md)
    if a.json:
        Path(a.json).write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
    bad = sum(c[k] for k in ("NO-RESUELVE", "RETRACTADO", "DISCREPANCIA", "SIN-METADATOS"))
    if bad:
        sys.exit(1)
    if c["SIN-CONEXION"]:
        sys.exit(2)  # inconcluso: repetir con red


if __name__ == "__main__":
    main()
