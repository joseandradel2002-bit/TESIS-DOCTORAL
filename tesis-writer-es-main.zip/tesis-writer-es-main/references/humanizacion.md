# Escritura humanizada para tesis

Fundamentos de `my-humanizer-es-en` (pipeline que bajó un artículo real del 50 % al 13 % en
Compilatio Magister+) y de la guía «Signs of AI writing», adaptados al registro de una tesis.

Los detectores (Compilatio, Turnitin, GPTZero) son **estilométricos**: marcan ritmo y estructura
más que vocabulario. La cadencia uniforme, los dos puntos de «afirmación: explicación» y las
enumeraciones simétricas son las señales más fuertes.

## Ajustes respecto del humanizador original (por las reglas de oro)

| Humanizador original | En esta skill |
|---|---|
| «Insertar preguntas genuinas donde sea natural»; abrir párrafos con una pregunta | **Prohibido** (R01). La variedad de aperturas se logra con un dato, una oración corta o una concesión. |
| Primera persona («aplicamos», «encontramos») | Solo si el documento ya la usa o la institución la admite. Si no, impersonal con «se» o «este trabajo», con ritmo variado. |
| Coloquialismos regionales («la plata», «a los tumbos») | No en una tesis. Se busca naturalidad, no oralidad. |
| Detalle concreto «un poco desordenado» | Sí: datos concretos, ejemplos del propio proyecto, cifras exactas en lugar de generalidades. |

## Reglas, por impacto

1. **Matar el hábito «afirmación: explicación».** Meta: ≤ 1 dos puntos por cada 1000 palabras de
   cuerpo (fuera de listas formales, horas y títulos).
   - Antes: «El hallazgo apunta al canal: hay herramientas que superan el 97 %…»
   - Después: «El hallazgo apunta al canal. Ya hay herramientas que superan el 97 %…»
2. **Romper enumeraciones simétricas.** «Dos cosas:», «tres frentes:», listas de tres elementos
   paralelos. Disolver en prosa o en oraciones de longitud desigual. Agrupar en dos o cuatro, no
   siempre en tres.
3. **Burstiness (variación de longitud).** Una oración de 5 palabras junto a una de 35. Meta para
   tesis: media 14–20 palabras, desviación ≥ 45 % de la media, pocas oraciones > 45 palabras.
   - «Esa limitación terminó en octubre de 2024.» (7 palabras) seguida de una oración larga con el dato.
4. **Detalle concreto.** Sustituir resúmenes abstractos por el dato o el caso del proyecto.
   - Antes: «Los resultados muestran un desempeño notable.»
   - Después: «La red del conectoma llegó a 0,88 de exactitud con cinco clases; el azar es 0,20.»
5. **Variar aperturas de párrafo.** No todas con oración temática genérica. Abrir con un dato,
   una fecha, una concesión («La demostración tiene limitaciones.»), un contraste.
6. **Cópula directa.** «sirve como», «actúa como», «se erige como» → «es».

## Catálogo de señales de IA a eliminar (ES)

- Significado inflado: «marca un hito», «desempeña un papel crucial», «un antes y un después».
- Lenguaje promocional: «vibrante», «fascinante», «de vanguardia», «revolucionario», «robusto»
  (salvo sentido técnico: «estimador robusto»), «innovador».
- Muletillas: «cabe destacar», «es importante señalar», «vale la pena mencionar», «en el
  panorama actual», «sin lugar a dudas», «en la era actual», «en lo que respecta a».
- Vocabulario de IA en racimo: crucial, fundamental, clave (como relleno), profundizar en,
  adentrarse, abordar (genérico), potenciar, fomentar, subrayar, sinergia, holístico,
  multifacético, integral, panorama, ámbito (no literal), piedra angular, un amplio abanico.
- Paralelismo negativo: «no solo… sino también», «no es X, es Y».
- Regla de tres compulsiva.
- Carrusel de sinónimos (llamar a lo mismo de tres maneras para «no repetir»).
- Falsos rangos «desde X hasta Y» que no son un rango.
- Atribución vaga: «los expertos señalan», «diversos estudios muestran» sin cita.
- Colas en gerundio que fingen profundidad: «…, evidenciando la importancia de…», «…, lo que
  subraya…».
- Rayas (—) en exceso: comas o paréntesis. En español la raya de inciso es legítima; con
  moderación (la auditoría avisa a partir de 0,5 rayas por cada 1000 palabras).
- Negritas decorativas en el cuerpo, listas con encabezado en negrita, emojis, comillas tipográficas
  inconsistentes.
- Artefactos de chatbot: «¡Claro!», «Espero que esto ayude», «En resumen,» al inicio de párrafo,
  conclusiones optimistas genéricas, exceso de matices («podría posiblemente sugerir»).
- Metacomentario vacío: «En esta sección se abordará…» sin contenido (ver R03/R04: la intro debe
  decir algo).
- Conectores en cadena: «Además», «Asimismo», «Por otro lado» abriendo oraciones seguidas.

## Lo que nunca se cambia al humanizar

Citas (Autor, año), cifras, porcentajes, fechas, nombres propios, términos técnicos, la lista de
referencias, títulos (salvo para corregir R07) y la estructura de secciones. Comprobar antes y
después que las cifras y citas del párrafo son idénticas.

## Medir

`audit_tesis.py` reporta en el bloque H: palabras, oraciones, longitud media y desviación,
oraciones > 45 palabras, dos puntos por 1000 palabras, rayas, conectores por 1000 palabras y
patrones de IA con ubicación. Si el usuario tiene un informe de detector (PDF de Compilatio o
Turnitin) y la skill `my-humanizer-es-en` instalada, usar su modo «report-driven» para reescribir
solo los pasajes marcados; esta skill no lo reemplaza.

Honestidad: un detector es estadístico. Nunca prometer un porcentaje concreto.
