# Perfil de formato: UTPL — Trabajo de Integración Curricular (TIC)

Versión legible de `profiles/utpl-tic.json` (la que usa `audit_tesis.py`). Fuente: «Consideraciones
generales para el Trabajo de Integración Curricular», plantilla oficial UTPL, con APA 7.

## Página y texto

| Elemento | Valor |
|---|---|
| Papel | A4 (21 × 29,7 cm) |
| Márgenes | 2,54 cm en los cuatro lados |
| Fuente del cuerpo | Arial 11 |
| Fuente de tablas y figuras | Arial 10 (fichas, matrices, casos = tablas; gráficos, diagramas, mapas, fotos = figuras) |
| Interlineado | doble en todo el desarrollo; 1,5 en el contenido de tablas y figuras |
| Espacio entre párrafos | ninguno (ni antes ni después de párrafos o títulos) |
| Alineación | justificada |
| Sangría | 1,27 cm en la primera línea de cada párrafo desde la Introducción; sin sangría en preliminares, Resumen y Abstract |

## Títulos

| Nivel | Formato |
|---|---|
| 1 (capítulos y secciones principales) | centrado, negrita, sin numeración, sin punto final |
| 2 (1.1) | izquierda, negrita, sin cursiva, sin punto final |
| 3 (1.1.1) | izquierda, negrita, cursiva, sin punto final |
| 4 (1.1.1.1) | izquierda, negrita, cursiva, sin punto final |
| 5 (1.1.1.1.1) | izquierda, negrita, cursiva, sin punto final |

Capítulos: dos títulos de nivel 1 seguidos, «Capítulo uno» y el nombre del capítulo. Todos en
tipo oración (regla R07).

## Tablas y figuras

- «Tabla 1» / «Figura 1»: Arial 10, negrita, sin cursiva, sin punto final.
- Título: Arial 10, sin negrita, cursiva, sin punto final, en la línea siguiente.
- «Nota.»: Arial 10, cursiva, con punto.
- Insertar con Referencias → Insertar título de Word (para que funcione el índice de tablas/figuras).

## Numeración de páginas

- Preliminares (carátula a índices): romanos en mayúscula (I, II, III). La carátula cuenta pero no
  muestra número.
- Desde el Resumen hasta el Apéndice: arábigos.
- Arriba a la derecha, Arial 11, sin negrita ni cursiva.

## Secciones y límites

Carátula · Aprobación del director · Declaración de autoría y cesión de derechos · Dedicatoria ·
Agradecimiento · Índice de contenido (e índices de tablas y figuras) · Resumen (≤ 180 palabras,
un párrafo, ≤ 3 palabras clave) · Abstract (mismo contenido en inglés, ≤ 3 keywords) ·
Introducción (≤ 2 páginas) · Capítulos · Conclusiones · Recomendaciones · Referencias · Apéndice.

## Referencias

Orden alfabético, APA 7, sangría francesa 1,27 cm, interlineado doble, sin viñetas ni números,
tipo oración, enlaces en negro, acortar enlaces largos (los DOI no se acortan).

## Antes de entregar

- Borrar todos los textos de instrucción de la plantilla («Letra Arial N° 11…», «Xxxxxx…»):
  la regla T de la auditoría los detecta.
- Actualizar índices (contenido, tablas, figuras) en Word.

---

## Añadir otra institución

1. Copiar `profiles/_plantilla.json` a `profiles/<siglas>-<tipo>.json` y rellenar los valores de
   su guía de formato.
2. Escribir su versión legible como `references/formato-<siglas>.md` (opcional).
3. En `tesis.config.json`: `"perfil": "<siglas>-<tipo>"`.
4. Si la guía institucional contradice APA 7 o estas reglas, manda la institución en formato;
   las reglas de oro del usuario siguen mandando en contenido.
