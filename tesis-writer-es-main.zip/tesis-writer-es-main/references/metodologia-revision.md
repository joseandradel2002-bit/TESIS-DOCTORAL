# Metodología de revisión de un documento con contenido

Para un capítulo o una tesis ya escrita. Combina auditoría automática (reglas comprobables por
máquina) con revisión experta (lo que requiere juicio), según la metodología de revisión de ARS.

## Principios

- **Primero diagnosticar, después corregir.** La revisión produce un informe. El documento solo
  se toca cuando el usuario aprueba las correcciones (todas, por regla o una a una).
- **Cada hallazgo con ancla:** ubicación exacta (`párr. 908 (§4.1 …)`) y extracto ≤ 25 palabras, o
  ausencia declarada («falta párrafo introductorio entre 4.2 y 4.2.1»).
- **Cada hallazgo con corrección propuesta** concreta, no «mejorar redacción».
- **Severidad por impacto propio**, nunca heredada: Crítico (invalida una afirmación central o
  incumple una regla de oro), Mayor (debilita una afirmación o la presentación de forma material),
  Menor (claridad, estilo, formato), Sugerencia (opcional).
- **Sin puntajes numéricos ni cuotas.** Si una dimensión sale limpia, decir qué se revisó.
- **El revisor no inventa:** si una cifra parece mal, se marca para verificar contra el
  repositorio o la fuente; no se «corrige» de memoria.
- **Máximo dos rondas** de corrección por capítulo; lo pendiente se declara como limitación o se
  consulta al usuario.

## Procedimiento

### Paso 1. Preparar
```bash
python3 scripts/dump_docx.py tesis.docx --outline          # mapa del documento con numeración
python3 scripts/audit_tesis.py tesis.docx --out informe_auditoria.md --json hallazgos.json
python3 scripts/verify_refs.py --docx tesis.docx --out verificacion_refs.md --mailto CORREO
```
Si no existe `tesis.config.json`, crearlo antes (ver SKILL.md, configuración) preguntando al
usuario lo necesario. Sin `autores` y `repositorio` la regla R06 queda limitada.

### Paso 2. Auditoría automática (reglas de oro y formato)
Leer `informe_auditoria.md`. Lo que el script marca:

| Regla | Qué detecta | Fiabilidad |
|---|---|---|
| R01 | «¿…?» fuera de la pregunta de investigación | alta |
| R02 | término configurado sin nota; librerías candidatas; notas > 1 línea; notas al pie; marcas pendientes; conceptos lejanos | media (candidatos = INFO) |
| R03 | capítulo sin párrafo antes de x.1 | alta |
| R04 | sección x.x que salta a x.x.1 sin intro; intro > 130 palabras | alta |
| R05 | «Elaboración propia» | alta |
| R06 | autocita de los autores; archivos del repo sin nota con URL | alta con config |
| R07 | títulos fuera de tipo oración; especies mal escritas | alta (dudas = AVISO) |
| R12 | fuente, tamaño, interlineado, sangría, alineación, leyendas, títulos, página | media (verificar en Word) |
| R13 | citas sin referencia y viceversa, «y»/«&», formato DOI, orden alfabético | media |
| R15 | tabla/figura sin párrafo previo que la nombre; presentación > 60 palabras o < 15; «la tabla siguiente» sin número | alta |
| H | longitud y variación de oraciones, dos puntos, rayas, vocabulario de IA, conectores | indicativa |
| X | remisiones a secciones/capítulos/tablas inexistentes; tablas sin mención; siglas sin desarrollar | alta / INFO |
| T | texto de plantilla sin borrar | alta |

Los INFO son candidatos: decidir con criterio o preguntar al usuario (protocolo de preguntas).

### Paso 3. Revisión experta (lo que el script no ve)
Leer el capítulo completo, sección por sección, con esta lista:

**Reglas de oro (juicio)**
- [ ] Los párrafos introductorios (R03/R04) dicen algo sustantivo, no solo «en esta sección…».
- [ ] Las notas al final de conceptos son de una línea y el concepto es de verdad complejo y lejano.
- [ ] Ninguna pregunta indirecta encubierta («cabe preguntarse si…», «surge la duda de…»).
- [ ] Toda figura/tabla ajena tiene su «Tomado de / Adaptado de» con cita APA completa.
- [ ] El párrafo que presenta cada tabla/figura (R15) dice qué muestra, no solo «La tabla N muestra los datos».

**Argumento y evidencia**
- [ ] La cadena problema → brecha → objetivo → método → resultado → conclusión es trazable.
- [ ] Cada afirmación factual tiene cita o dato propio localizable.
- [ ] Ninguna afirmación de novedad absoluta sin búsqueda documentada.
- [ ] La fuerza de las afirmaciones corresponde a la evidencia (sin overclaiming).
- [ ] Correlación no presentada como causalidad.
- [ ] Contraargumentos y explicaciones alternativas tratados donde importan (discusión).
- [ ] Las limitaciones están declaradas y no contradicen las conclusiones.

**Coherencia interna**
- [ ] El mismo dato tiene el mismo valor en todo el documento (comparar cifras clave entre
      capítulos: tamaños, exactitudes, fechas).
- [ ] Términos y siglas usados igual en todo el documento.
- [ ] Objetivos del capítulo 1 ↔ resultados ↔ conclusiones: cada objetivo tiene respuesta.

**Escritura** (`humanizacion.md`)
- [ ] Sin patrones de IA: dos puntos «afirmación: explicación», enumeraciones simétricas,
      tríadas, paralelismos «no solo… sino», vocabulario inflado, cierres de chatbot.
- [ ] Ritmo variado: oraciones cortas junto a largas.
- [ ] Registro académico constante.

**Fuentes** (`investigacion-fuentes.md`)
- [ ] Todas VERIFICADO; ninguna retractada; preprints con versión publicada sustituidos.
- [ ] Renombre suficiente para lo que sostienen (fuentes primarias de calidad para afirmaciones centrales).
- [ ] Contexto: la fuente dice lo que se le atribuye (revisar 100 % de cifras y afirmaciones
      centrales, muestreo del resto).

**Abogado del diablo** (para capítulos de resultados y discusión): redactar en el informe el
contraargumento más fuerte (150–250 palabras) y comprobar si el texto lo responde.

### Paso 4. Informe
Usar `templates/informe-revision.md`. Incluir: resumen ejecutivo (3–4 líneas), tabla de
cumplimiento por regla, hallazgos por severidad con ancla y corrección, verificación de
referencias y preguntas pendientes para el usuario (con opciones).

### Paso 5. Corregir (con aprobación)
1. Preguntar al usuario qué aplicar (todas / solo reglas de oro / revisar una por una).
2. Traducir cada corrección aprobada a operaciones de `scripts/edit_docx.py`. Los índices son los
   del archivo sobre el que se ejecutó la auditoría y no se desplazan dentro de una misma pasada;
   para una pasada posterior, volver a ejecutar `dump_docx.py` sobre la versión nueva:
   - pregunta retórica → `replace_in` con la afirmación;
   - título → `heading` con el texto en tipo oración;
   - falta intro de capítulo/sección → `insert_after` sobre el título;
   - «Elaboración propia» → `replace_in` (borrar la frase) o `delete` si la nota solo decía eso;
   - autocita → `replace_in` «(Autor y Autor, 2026)» → «(nombre-repo, 2026)»;
   - tabla/figura sin presentación → `insert_before` sobre la leyenda con 2–3 líneas (si el párrafo
     previo es largo y la nombra al final, se deja y se añade el breve igualmente);
   - nota al final → `replace_in` añadiendo `[Insertar nota al final: …]` tras la palabra;
   - notas al pie existentes → contenido final en `notas.json` y `--from-footnotes --rewrite notas.json`.
3. Aplicar en un archivo nuevo versionado: `tesis_v2.docx` (nunca sobrescribir el original).
4. `scripts/insert_endnotes.py tesis_v2.docx -o tesis_v3.docx` para convertir las marcas.
5. Volver a auditar el resultado y comparar recuentos (ERROR debe bajar a 0 en las reglas tratadas).
6. Las referencias nuevas o cambiadas se re-verifican.

**Límites de la corrección automática:** cambiar o borrar títulos, cambiar el número de secciones
o reescribir más del 60 % de un capítulo requiere confirmación explícita. Cifras, citas y nombres
propios se conservan exactos en cada reescritura (comprobar antes/después).

### Paso 6. Cierre
Entregar el `.docx` corregido, el informe y un registro breve de cambios:
`| # | Ubicación | Regla | Antes | Después |`. Lo que no se pudo resolver queda listado con su motivo.

## Revisión rápida (autorrevisión tras redactar)

Para el agente al terminar un capítulo nuevo: `audit_tesis.py --chapter N` + bloque «Reglas de
oro (juicio)» + «Escritura» + verificación de citas nuevas. Sin informe formal; corregir y entregar.
