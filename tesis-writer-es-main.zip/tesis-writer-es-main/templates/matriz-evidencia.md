# Matriz de evidencia

## Parámetros de búsqueda

| Campo | Valor |
|---|---|
| Afirmación / pregunta | |
| Conceptos núcleo + sinónimos (ES/EN) | |
| Cadena booleana | |
| Bases consultadas | |
| Rango de años (justificación) | |
| Criterios de inclusión | |
| Criterios de exclusión | |
| Fecha de ejecución | AAAA-MM-DD |

## Conteo (tipo PRISMA)

Identificados: n (por base) → duplicados eliminados: n → cribados por título/resumen: n →
excluidos: n → evaluados a texto completo: n → excluidos con motivo: n → incluidos: n

## Fuentes incluidas

| # | Referencia APA | DOI | Verificación (estado, fecha) | Tipo / nivel | Revista (cuartil) / citas | Hallazgo clave | Sección donde se usa | Lectura (resumen / completo) |
|---|---|---|---|---|---|---|---|---|
| 1 | | | VERIFICADO, 2026-10-21 | artículo Q1 | | | 2.2.3 | completo |

## Afirmación → fuente

| Afirmación del texto (ubicación) | Fuente(s) | ¿La fuente lo dice? (página/figura) | Fuerza de la afirmación |
|---|---|---|---|
| | | sí, p. 128, Fig. 2 | se asocia con |
