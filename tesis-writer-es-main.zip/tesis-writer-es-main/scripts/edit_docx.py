#!/usr/bin/env python3
"""Aplica ediciones quirúrgicas a un .docx de tesis conservando estilos y formato.

Uso:
  python3 edit_docx.py tesis.docx ediciones.json -o tesis_v2.docx
  python3 edit_docx.py tesis.docx ediciones.json -o tesis_v2.docx --dry-run

ediciones.json es una lista de operaciones. Los índices `p` son los de
dump_docx.py / audit_tesis.py sobre el documento ORIGINAL (no se desplazan
aunque se inserten o borren párrafos en la misma pasada):

  {"op": "replace",      "p": 412, "text": "Texto completo nuevo del párrafo."}
  {"op": "replace_in",   "p": 687, "find": "¿Por qué ocupa…? Porque", "repl": "Ocupa un capítulo entero porque"}
  {"op": "insert_after", "p": 565, "text": "Párrafo introductorio…", "like": 568}
  {"op": "insert_before","p": 567, "text": "…", "like": 568}
  {"op": "delete",       "p": 827}
  {"op": "heading",      "p": 567, "text": "El agotamiento del paradigma actual de la inteligencia artificial"}

- replace: reescribe el párrafo con el formato de su primer run. Se niega si el
  párrafo contiene referencias a notas (usar replace_in para no perderlas).
- replace_in: sustitución de una subcadena exacta (puede cruzar runs).
  Añade "all": true para todas las apariciones.
- insert_after / insert_before: crea un párrafo nuevo copiando el estilo del
  párrafo `like` (por defecto, el siguiente/anterior párrafo de cuerpo).
- heading: cambia el texto de un título sin tocar su numeración automática.

Las marcas [Insertar nota al final: …] se pueden escribir dentro de "text";
después se convierten en notas reales con insert_endnotes.py.
"""
import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import NOTE_MARK, build_model, open_docx  # noqa: E402
from _docx_ops import char_map, new_paragraph_like, replace_text_keep_format, splice  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402


def find_model_body(paras, idx, direction):
    rng = range(idx + 1, len(paras)) if direction > 0 else range(idx - 1, -1, -1)
    for j in rng:
        if paras[j].kind == "body" and paras[j].plain.strip():
            return paras[j]
    return None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("docx")
    ap.add_argument("edits")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    if Path(a.out).resolve() == Path(a.docx).resolve():
        sys.exit("Por seguridad, el archivo de salida debe ser distinto del original (versiona: _v2, _v3…).")

    doc = open_docx(a.docx)
    paras = build_model(doc)
    els = [p.el for p in paras]
    ops = json.loads(Path(a.edits).read_text(encoding="utf-8"))
    n0 = len(doc.paragraphs)
    log, errors = [], []

    deleted: set[int] = set()
    applied_ins = applied_del = 0
    for k, op in enumerate(ops):
        kind, i = op.get("op"), op.get("p")
        try:
            if not isinstance(i, int) or not (0 <= i < len(els)):
                raise ValueError(f"índice fuera de rango: {i}")
            if i in deleted:
                raise ValueError("ese párrafo ya se borró en esta misma pasada")
            el = els[i]
            if kind == "replace":
                txt, _ = char_map(el)
                if NOTE_MARK in paras[i].text and not op.get("force"):
                    raise ValueError("el párrafo tiene notas; usa replace_in o \"force\": true")
                replace_text_keep_format(el, op["text"])
                log.append(f"[{k}] replace p{i}: {len(txt)} → {len(op['text'])} caracteres")
            elif kind == "heading":
                if paras[i].kind != "heading":
                    raise ValueError("el párrafo no es un título")
                replace_text_keep_format(el, op["text"])
                log.append(f"[{k}] heading p{i}: «{paras[i].plain.strip()}» → «{op['text']}»")
            elif kind == "replace_in":
                count, start = 0, 0
                while True:
                    txt, _ = char_map(el)
                    pos = txt.find(op["find"], start)
                    if pos < 0:
                        break
                    splice(el, pos, pos + len(op["find"]), op["repl"])
                    count += 1
                    start = pos + len(op["repl"])  # seguir detrás del reemplazo: evita bucles si repl contiene find
                    if not op.get("all"):
                        break
                if not count:
                    txt, _ = char_map(el)
                    if op["find"] in re.sub("[\t\n" + NOTE_MARK + "]", "", txt):
                        raise ValueError("el texto cruza una nota, tabulación o salto de línea; acota «find» "
                                         "a un fragmento sin ellos para no moverlos")
                    raise ValueError(f"no se encontró el texto: {op['find'][:60]!r}")
                log.append(f"[{k}] replace_in p{i}: {count} sustitución(es)")
            elif kind in ("insert_after", "insert_before"):
                like = op.get("like")
                if like is not None:
                    if not isinstance(like, int) or not (0 <= like < len(els)):
                        raise ValueError(f"«like» fuera de rango: {like}")
                    model = els[like]
                else:
                    mp = find_model_body(paras, i, +1 if kind == "insert_after" else -1) or find_model_body(paras, i, -1)
                    if mp is None:
                        raise ValueError("no hay párrafo de cuerpo que sirva de modelo; indica \"like\"")
                    model = mp.el
                new_p = new_paragraph_like(model, op["text"])
                (el.addnext if kind == "insert_after" else el.addprevious)(new_p)
                applied_ins += 1
                log.append(f"[{k}] {kind} p{i}: +1 párrafo ({len(op['text'].split())} palabras)")
            elif kind == "delete":
                if el.find(".//" + qn("w:sectPr")) is not None:
                    raise ValueError("el párrafo contiene un salto de sección; borrarlo rompería el formato")
                el.getparent().remove(el)
                deleted.add(i)
                applied_del += 1
                log.append(f"[{k}] delete p{i}: «{paras[i].plain[:50]}»")
            else:
                raise ValueError(f"operación desconocida: {kind}")
        except Exception as e:  # una operación fallida no debe tumbar las demás
            errors.append(f"[{k}] {kind} p{i}: {e}")

    print("\n".join(log))
    n1 = len(doc.paragraphs)
    expected = n0 + applied_ins - applied_del
    if n1 != expected:
        errors.append(f"recuento de párrafos inesperado: {n1} (esperado {expected}); revisar antes de usar el archivo")
    if errors:
        print("\nERRORES (operaciones no aplicadas):")
        print("\n".join(errors))
    print(f"\nPárrafos: {n0} → {n1} ({applied_ins} insertados, {applied_del} borrados)")
    print("Los índices de este archivo ya no coinciden con el original: vuelve a ejecutar dump_docx.py sobre la salida antes de preparar otra pasada.")
    if a.dry_run:
        print("--dry-run: no se guardó nada.")
        return
    doc.save(a.out)
    print(f"Guardado: {a.out}")
    if errors:
        sys.exit(2)


if __name__ == "__main__":
    main()
