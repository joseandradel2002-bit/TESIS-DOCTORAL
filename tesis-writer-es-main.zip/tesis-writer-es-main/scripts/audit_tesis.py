#!/usr/bin/env python3
"""Auditoría automática de un capítulo o tesis completa (.docx) contra las reglas de tesis-writer-es.

Uso:
  python3 audit_tesis.py tesis.docx                       # informe Markdown por stdout
  python3 audit_tesis.py tesis.docx --out informe.md --json hallazgos.json
  python3 audit_tesis.py tesis.docx --chapter 4           # solo un capítulo
  python3 audit_tesis.py tesis.docx --only R01,R05,R07     # solo algunas reglas
  python3 audit_tesis.py tesis.docx --strict              # exit 1 si hay ERROR

Lee tesis.config.json (junto al .docx o en el directorio actual) para autores,
repositorio, términos con nota al final y nombres propios. Sin config, las
comprobaciones que dependen de ella bajan a INFO o se omiten.

Severidades: ERROR (viola una regla de la skill), AVISO (probable problema,
revisar), INFO (candidatos para criterio humano o del agente).
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import (CAPTION_RE, CHAPTER_RE, MARKER_RE, NOTE_MARK, NOTE_PARA_RE, build_model, table_cells,  # noqa: E402
                     load_config, load_profile, mark_template_paras, norm, notes_parts, open_docx,
                     qn, read_notes, split_sentences, strip_accents, style_chain, word_count)

SEV_ORDER = {"ERROR": 0, "AVISO": 1, "INFO": 2}

RULES = {
    "R01": "Sin preguntas en el texto (salvo la pregunta de investigación)",
    "R02": "Notas al final para librerías clave y conceptos lejanos (máx. una línea)",
    "R03": "Párrafo introductorio tras el título de cada capítulo",
    "R04": "Introducción breve (3–4 líneas) al entrar en cada sección x.x",
    "R05": "Sin «Elaboración propia» en notas de figuras y tablas",
    "R06": "El repositorio propio se cita como repositorio, no como autocita",
    "R07": "Títulos en tipo oración (solo primera palabra y nombres propios)",
    "R12": "Formato académico del perfil institucional",
    "R13": "APA 7: citas, referencias y DOI",
    "R15": "Introducción de 2–3 líneas antes de cada tabla y figura",
    "H": "Escritura humanizada (métricas y patrones de IA)",
    "X": "Referencias cruzadas, tablas, figuras y siglas",
    "T": "Texto de plantilla sin reemplazar",
}

AI_PATTERNS = [
    (r"\bdesempe[ñn]a(?:n)? un papel (?:clave|crucial|fundamental|esencial|importante)", "desempeña un papel …"),
    (r"\bjuega(?:n)? un papel\b", "juega un papel (calco del inglés)"),
    (r"\bcabe (?:destacar|se[ñn]alar|mencionar|resaltar)\b", "cabe destacar/señalar"),
    (r"\bes (?:importante|crucial|fundamental|esencial) (?:destacar|se[ñn]alar|mencionar|resaltar|subrayar)\b", "es importante destacar"),
    (r"\bsin lugar a dudas\b", "sin lugar a dudas"),
    (r"\ben el panorama\b|\bpanorama actual\b", "panorama"),
    (r"\bno solo\b[^.;]{0,120}?\bsino\b", "no solo… sino (paralelismo negativo)"),
    (r"\bcrucial(?:es|mente)?\b", "crucial"),
    (r"\b(?:sinergia|hol[ií]stic[oa]s?|multifac[eé]tic[oa]s?)\b", "sinergia/holístico/multifacético"),
    (r"\b(?:de vanguardia|vanguardista)\b", "de vanguardia"),
    (r"\b(?:un hito|marca(?:n)? un antes y un despu[eé]s)\b", "hito / antes y después"),
    (r"\b(?:fascinante|intrincad[oa]s?|apasionante)\b", "adjetivo promocional"),
    (r"\b(?:adentrarse|adentrarnos|profundizar en)\b", "adentrarse/profundizar en"),
    (r"\ben (?:[uú]ltima instancia|definitiva)\b", "en última instancia/en definitiva"),
    (r"^(?:En resumen|En conclusi[oó]n|En s[ií]ntesis),", "cierre de chatbot al inicio de párrafo"),
    (r"\bsirve(?:n)? como\b", "sirve como (evitar cópula)"),
    (r"\b(?:robust[oa]s?|innovador(?:a|es|as)?|transformador(?:a|es|as)?)\b", "adjetivo inflado"),
    (r"\bresulta(?:n)? (?:fundamental|crucial|esencial|clave)\b", "resulta fundamental/clave"),
    (r"\ben el [aá]mbito de\b", "en el ámbito de"),
]
CONNECTORS = ["además", "asimismo", "por otro lado", "en este sentido", "a su vez", "por lo tanto", "de este modo"]

KNOWN_LIBS = ["Brian2", "NEST", "NEURON", "Nengo", "snnTorch", "Norse", "BindsNET", "SpikingJelly", "PyTorch",
              "TensorFlow", "Keras", "JAX", "NumPy", "SciPy", "Pandas", "NetworkX", "Matplotlib", "Seaborn",
              "scikit-learn", "statsmodels", "Jupyter", "Plotly", "igraph", "graph-tool", "OpenCV", "librosa",
              "navis", "fafbseg", "MuJoCo", "Lava", "Hugging Face", "Transformers", "LangChain", "FastAPI",
              "Django", "Flask", "React", "Docker", "Kubernetes", "Spark", "ggplot2", "dplyr", "PyMC", "Stan",
              "XGBoost", "LightGBM", "spaCy", "NLTK", "Gensim", "Polars", "Dask", "Ray", "MLflow", "Optuna",
              "Streamlit", "Gradio", "CUDA", "ROS", "Unity", "Unreal", "Gymnasium", "Stable-Baselines3"]

SPECIES_DEFAULT = ["Drosophila melanogaster", "Caenorhabditis elegans", "Mus musculus", "Homo sapiens",
                   "Danio rerio", "Rattus norvegicus", "Escherichia coli", "Saccharomyces cerevisiae",
                   "Arabidopsis thaliana", "Apis mellifera", "Macaca mulatta", "Xenopus laevis"]

ACRONYM_WHITELIST = {"APA", "DOI", "URL", "PDF", "ISBN", "ISSN", "II", "III", "IV", "VI", "VII", "VIII", "IX",
                     "XI", "XII", "XX", "XXI", "UU", "EE", "OK", "CSV", "JSON", "HTML", "XML", "ID"}

STOP_LONG = set("""entonces mientras durante después antes también todavía siempre aunque porque además
través contra sobre entre desde hasta según cuando donde quienes cuales tienen tienen pueden puede deben
cualquier ninguna ninguno ambos ambas muchas muchos algunos algunas otras otros mismas mismos cuántas
capítulo sección figura tabla trabajo resultados modelo modelos neuronas conexiones""".split())


class Finding:
    __slots__ = ("rule", "code", "sev", "loc", "excerpt", "msg", "fix", "idx")

    def __init__(self, rule, code, sev, loc, excerpt, msg, fix="", idx=None):
        self.rule, self.code, self.sev, self.loc = rule, code, sev, loc
        self.excerpt, self.msg, self.fix, self.idx = excerpt, msg, fix, idx

    def as_dict(self):
        return {k: getattr(self, k) for k in self.__slots__}


def excerpt(text, start=0, end=None, width=140):
    text = text.replace(NOTE_MARK, "⁽ⁿ⁾").replace("\n", " / ")
    if end is None:
        end = start + width
    a = max(0, start - 30)
    b = min(len(text), max(end, start + 40) + 30)
    s = text[a:b].strip()
    return ("…" if a > 0 else "") + s + ("…" if b < len(text) else "")


def caption_title(paras, p):
    """Título de una leyenda: la línea tras «Tabla N»/«Figura N» o el párrafo siguiente."""
    m = CAPTION_RE.match(p.plain)
    rest = p.plain[m.end():] if m else p.plain
    lines = [x.strip() for x in rest.split("\n") if x.strip()]
    if lines:
        return lines[0].lstrip(".:–- ").strip()
    if p.idx + 1 < len(paras):
        q = paras[p.idx + 1]
        if q.kind in ("body", "front") and 0 < len(q.plain.strip()) < 200 and not NOTE_PARA_RE.match(q.plain.strip()):
            return q.plain.strip()
    return ""


class Auditor:
    def __init__(self, doc, cfg, prof, chapter=None, only=None):
        self.doc, self.cfg, self.prof = doc, cfg, prof
        self.paras = build_model(doc)
        mark_template_paras(self.paras, prof)
        self.chapter = chapter
        self.only = set(only) if only else None
        self.f: list[Finding] = []
        self.metrics: dict = {}
        self.body = [p for p in self.paras if p.kind in ("body", "list") and p.region in ("chapter", "intro")]
        self.cells = [c for c in table_cells(doc, self.paras) if c.region in ("chapter", "intro", "resumen", "back")]
        # prosa = todo lo que lee el tribunal: cuerpo, resumen, leyendas, notas y celdas de tablas
        self.prose_all = (self.body
                          + [p for p in self.paras if p.kind in ("body", "list") and p.region == "resumen"]
                          + [p for p in self.paras if p.kind in ("caption", "note") and p.region in ("chapter", "intro")]
                          + self.cells)
        self.prose = self.prose_all
        if chapter is not None:
            self.body = [p for p in self.body if p.chapter == chapter]
            self.prose = [p for p in self.prose_all if p.chapter == chapter]
        if not any(p.chapter for p in self.paras):
            self.add("X", "SIN-CAPITULOS", "AVISO", "documento", "",
                     "No se detectó ningún capítulo: R03/R04, la numeración y --chapter no funcionarán.",
                     "Usar el estilo «Título 1» para los capítulos (con «Capítulo N» o tras la Introducción).")
        self.headings = [p for p in self.paras if p.kind == "heading"]
        lower_body = " ".join(p.plain for p in self.paras if p.kind in ("body", "list", "note", "caption"))
        self.body_text_all = lower_body
        self.protected = list(cfg.get("nombres_propios", [])) + list(prof.get("nombres_protegidos", [])) \
            + list(cfg.get("terminos_nota", {}).keys()) + SPECIES_DEFAULT + KNOWN_LIBS
        repo = cfg.get("repositorio", {})
        if repo.get("nombre"):
            self.protected.append(repo["nombre"])

    def on(self, rule):
        return self.only is None or rule in self.only

    def add(self, *a, **k):
        self.f.append(Finding(*a, **k))

    def in_scope(self, p):
        return self.chapter is None or p.chapter == self.chapter

    # ------------------------------------------------------------------ R01
    def r01_preguntas(self):
        rq = re.compile(r"pregunta(?:s)? (?:de|central de la) investigaci[oó]n|research question", re.I)
        for h in self.headings:
            if self.in_scope(h) and h.region not in ("front", "refs") and ("¿" in h.plain or "?" in h.plain):
                self.add("R01", "TITULO-PREGUNTA", "ERROR", h.loc(), h.plain.strip(),
                         "Título en forma de pregunta.",
                         "Convertirlo en un título nominal («¿Qué es una SNN?» → «Definición de red neuronal de pulsos»).", h.idx)
        for p in self.prose:
            t = p.plain
            if "?" not in t and "¿" not in t:
                continue
            t_nourl = re.sub(r"https?://\S+", "", t)
            for m in re.finditer(r"¿[^?]*\?|[^.¿!?]*\?", t_nourl):
                q = m.group(0)
                if not q.strip() or q.strip() == "?":
                    continue
                before = t_nourl[max(0, m.start() - 160): m.start()]
                quoted = bool(re.search(r"[«“\"][^»”\"]*$", t_nourl[: m.start()]))
                if rq.search(before) or rq.search(p.section) or rq.search(q):
                    continue
                if quoted:
                    self.add("R01", "PREGUNTA-EN-CITA", "AVISO", p.loc(), excerpt(t, m.start(), m.end()),
                             "Pregunta dentro de una cita textual. Mantener solo si la cita es imprescindible.",
                             "Parafrasear la cita como afirmación o confirmar con el usuario.", p.idx)
                else:
                    self.add("R01", "PREGUNTA", "ERROR", p.loc(), excerpt(t, m.start(), m.end()),
                             "Pregunta retórica insertada en el texto.",
                             "Reescribir como afirmación directa (la respuesta implícita pasa a ser la tesis de la oración).",
                             p.idx)

    # ------------------------------------------------------------------ R02
    def r02_notas(self):
        libs: dict = self.cfg.get("terminos_nota", {})
        concepts: dict = self.cfg.get("conceptos_nota", {})
        terms = {**libs, **concepts}
        maxc = self.prof.get("limites", {}).get("nota_al_final_caracteres_max", 100)
        mt = int(self.cfg.get("capitulo_marco_teorico", 2))
        scope = [p for p in self.paras if p.kind in ("body", "list", "caption", "note") and p.region in ("chapter", "intro")]
        # a) librerías: nota en la primera aparición del documento.
        #    conceptos: nota en la primera aparición LEJANA (capítulos posteriores al siguiente del marco teórico)
        jobs = [(t, c, scope, 0, "Primera aparición") for t, c in libs.items()]
        far = [p for p in scope if p.chapter and p.chapter >= mt + 2]
        jobs += [(t, c, far, re.I, f"Primera aparición desde el capítulo {mt + 2}") for t, c in concepts.items()]
        for term, content, where, flags, label in jobs:
            rx = re.compile(r"(?<![\w-])" + re.escape(term) + r"(?![\w-])", flags)
            first = next(((p, m) for p in where for m in [rx.search(p.text)] if m), None)
            if not first:
                continue
            p, m = first
            if not self.in_scope(p):
                continue
            tail = p.text[m.end(): m.end() + 60]
            ok = tail[:4].lstrip("»”\"')*").startswith(NOTE_MARK) or MARKER_RE.match(tail.lstrip()) is not None
            if not ok:
                self.add("R02", "NOTA-TERMINO", "ERROR", p.loc(), excerpt(p.text, m.start(), m.end()),
                         f"{label} de «{term}» sin nota al final.",
                         f"Añadir tras «{m.group(0)}»: [Insertar nota al final: {content}] y ejecutar insert_endnotes.py.",
                         p.idx)
        # b) candidatos de librerías sin configurar
        configured = {norm(t) for t in terms}
        seen = set()
        cand_rx = re.compile(r"(?<![\w/.-])(" + "|".join(re.escape(x) for x in KNOWN_LIBS) + r")(?![\w-])")
        for p in scope:
            if not self.in_scope(p):
                continue
            for m in cand_rx.finditer(p.text):
                k = norm(m.group(1))
                if k in configured or k in seen:
                    continue
                seen.add(k)
                tail = p.text[m.end(): m.end() + 4]
                if NOTE_MARK in tail:
                    continue
                self.add("R02", "NOTA-CANDIDATO", "INFO", p.loc(), excerpt(p.text, m.start(), m.end()),
                         f"«{m.group(1)}» parece una librería/herramienta. ¿Es clave para el proyecto?",
                         "Si es clave: añadirla a terminos_nota en tesis.config.json con la URL de su documentación oficial.",
                         p.idx)
        # c) notas existentes: longitud y tipo
        parts = notes_parts(self.doc)
        for nid, txt in read_notes(parts["endnotes"], "endnote"):
            is_url = re.fullmatch(r"\s*(https?://\S+)\s*\.?", txt) is not None
            if len(txt) > maxc and not is_url:
                self.add("R02", "NOTA-LARGA", "AVISO", f"nota al final {nid}", txt[:160],
                         f"La nota tiene {len(txt)} caracteres (> {maxc}, más de una línea).",
                         "Recortar a una sola línea: definición mínima o solo el enlace.")
        fn = read_notes(parts["footnotes"], "footnote")
        if fn:
            self.add("R02", "NOTA-AL-PIE", "INFO", "documento", "; ".join(f"[{i}] {t[:60]}" for i, t in fn[:8]),
                     f"Hay {len(fn)} nota(s) al pie. La convención de la skill es nota al final.",
                     "Con permiso del usuario: redactar el contenido final de cada una (definición de una línea o URL) "
                     "en un JSON {id: texto} y ejecutar insert_endnotes.py --from-footnotes --rewrite notas.json.")
        # d) marcas pendientes
        pend = [(p, m) for p in self.paras for m in MARKER_RE.finditer(p.text) if self.in_scope(p)]
        if pend:
            self.add("R02", "NOTA-PENDIENTE", "INFO", f"{len(pend)} marca(s)",
                     "; ".join(m.group(0)[:70] for _, m in pend[:4]),
                     "Marcas [Insertar nota al final: …] sin convertir.",
                     "Ejecutar insert_endnotes.py sobre el .docx o insertarlas a mano en Word.")
        # e) conceptos lejanos del marco teórico
        mt = int(self.cfg.get("capitulo_marco_teorico", 2))
        by_ch = defaultdict(Counter)
        for p in self.paras:
            if p.chapter and p.kind in ("body", "list"):
                for w in re.findall(r"\b[a-záéíóúñü]{8,}\b", p.plain):
                    by_ch[p.chapter][w] += 1
        if mt in by_ch:
            later = [c for c in by_ch if c >= mt + 2]
            mt_heads = " ".join(norm(p.plain) for p in self.headings if p.chapter == mt)
            mt_text = " ".join(p.plain.lower() for p in self.paras if p.chapter == mt and p.kind in ("body", "list"))
            cands = []
            for w, n in by_ch[mt].items():
                if n < 3 or w in STOP_LONG or by_ch.get(mt + 1, Counter())[w] > 0:
                    continue
                tot = sum(by_ch[c][w] for c in later)
                if 1 <= tot <= 2:
                    score = n
                    if norm(w) in mt_heads:
                        score += 15
                    if re.search(r"(?:se (?:define|denomina|conoce|llama)|conocid[oa]s? como|llamad[oa]s?|es decir)[^.]{0,60}\b" + w, mt_text):
                        score += 10
                    cands.append((score, n, w))
            for _, n, w in sorted(cands, reverse=True)[:12]:
                for p in self.paras:
                    if p.chapter and p.chapter >= mt + 2 and p.kind in ("body", "list") and re.search(r"\b" + w + r"\b", p.plain):
                        if self.in_scope(p):
                            self.add("R02", "CONCEPTO-LEJANO", "INFO", p.loc(), excerpt(p.plain, p.plain.find(w)),
                                     f"«{w}» se explicó en el capítulo {mt} ({n} veces) y reaparece poco y lejos.",
                                     "Si es un concepto técnico: nota al final con definición de una línea.", p.idx)
                        break

    # ------------------------------------------------------------------ R03 / R04
    def r03_r04_intros(self):
        seq = [p for p in self.paras if p.kind in ("heading", "body", "list", "caption", "note")]
        for i, p in enumerate(seq):
            if p.kind != "heading" or not self.in_scope(p):
                continue
            nxt = seq[i + 1:]
            # capítulo: título nivel 1 que sigue a «Capítulo X»
            if (p.level == 1 and p.chapter and i > 0 and seq[i - 1].kind == "heading" and seq[i - 1].level == 1
                    and CHAPTER_RE.match(seq[i - 1].plain.strip()) and not CHAPTER_RE.match(p.plain.strip())):
                bodies = []
                for q in nxt:
                    if q.kind == "heading":
                        break
                    if q.kind in ("body", "list"):
                        bodies.append(q)
                if not bodies:
                    self.add("R03", "INTRO-CAPITULO", "ERROR", p.loc(), p.plain,
                             "El capítulo entra directo al primer subtítulo sin párrafo introductorio.",
                             "Insertar tras el título un párrafo breve: qué trata el capítulo, por qué importa y qué secciones recorre.",
                             p.idx)
            if p.level == 2 and p.chapter:
                bodies, first_child = [], None
                for q in nxt:
                    if q.kind == "heading":
                        if q.level and q.level > 2:
                            first_child = q
                        break
                    if q.kind in ("body", "list"):
                        bodies.append(q)
                if first_child is not None and not bodies:
                    self.add("R04", "INTRO-SECCION", "ERROR", p.loc(), f"{p.number} {p.plain} → {first_child.number} {first_child.plain}",
                             "La sección salta a su primera subsección sin explicar de qué trata.",
                             "Insertar 3–4 líneas (≈40–80 palabras) que anticipen el contenido de la sección.", p.idx)
                elif first_child is not None:
                    w = sum(word_count(b.plain) for b in bodies)
                    if w > 130:
                        self.add("R04", "INTRO-SECCION-LARGA", "AVISO", p.loc(), f"{p.number} {p.plain}",
                                 f"La introducción de la sección ocupa {w} palabras antes de {first_child.number}.",
                                 "Condensar a 3–4 líneas y mover el resto a una subsección.", p.idx)

    # ------------------------------------------------------------------ R05
    def r05_elaboracion(self):
        rx = re.compile(r"elaboraci[oó]n propia", re.I)
        for p in self.paras:
            if p.region not in ("chapter", "intro", "back") or not self.in_scope(p):
                continue
            m = rx.search(p.plain)
            if not m:
                continue
            rest = rx.sub("", p.plain)
            rest_clean = re.sub(r"^\s*nota\s*\.\s*", "", rest, flags=re.I).strip(" .;,")
            if not rest_clean:
                fix = "Eliminar la nota completa (solo decía «Elaboración propia»)."
            elif re.search(r"a partir de|con datos de|basad[oa] en", p.plain, re.I):
                fix = "Reemplazar «Elaboración propia a partir de X» por «Datos tomados de X» o «Adaptado de X»."
            else:
                fix = "Borrar «Elaboración propia» y conservar el resto de la nota."
            self.add("R05", "ELABORACION-PROPIA", "ERROR", p.loc(), excerpt(p.plain, m.start(), m.end()),
                     "Las figuras y tablas propias no llevan «Elaboración propia».", fix, p.idx)

    # ------------------------------------------------------------------ R06
    def r06_repositorio(self):
        autores = [a for a in self.cfg.get("autores", []) if a]
        repo = self.cfg.get("repositorio", {})
        rname = repo.get("nombre")
        cit_rx = re.compile(r"\(([^()]*?\b(?:19|20)\d{2}[a-z]?)\)|([A-ZÁÉÍÓÚÑ][\w’'\-]+(?:\s+(?:y|&)\s+[A-ZÁÉÍÓÚÑ][\w’'\-]+|\s+et al\.)?)\s+\(((?:19|20)\d{2}[a-z]?)\)")
        file_rx = re.compile(r"(?<![\w/])(?:[\w\-]+/)*[\w\-]+\.(?:ipynb|py|md|csv|json|gz|ya?ml|txt|R|r|m|sh|toml)(?![\w])")
        repo_ctx = re.compile(r"repositorio|github|cuaderno|notebook|script|research-log|results\.md", re.I)
        cell_files: dict = {}
        for p in self.prose:
            t = p.text
            for m in cit_rx.finditer(t):
                for item in m.group(0).strip("()").split(";"):
                    sev = self._self_cite(item, autores, repo, bool(repo_ctx.search(t)))
                    if sev:
                        fix = (f"Citar el repositorio: ({rname or 'nombre-del-repositorio'}, {repo.get('anio', 'año')}) y, "
                               "si se nombra un archivo concreto, nota al final con su URL.")
                        msg = ("Autocita de los autores de la tesis." if sev == "ERROR" else
                               "Posible autocita (coincide parte de los apellidos de los autores). Confirmar con el usuario.")
                        self.add("R06", "AUTOCITA" if sev == "ERROR" else "POSIBLE-AUTOCITA", sev, p.loc(),
                                 excerpt(t, m.start(), m.end()), msg, fix, p.idx)
                    elif not autores and repo_ctx.search(t) and re.search(r"(?:19|20)\d{2}", item):
                        self.add("R06", "POSIBLE-AUTOCITA", "INFO", p.loc(), excerpt(t, m.start(), m.end()),
                                 "Cita en un párrafo que habla del repositorio. Sin «autores» en la config no se puede confirmar si es autocita.",
                                 "Configurar autores y repositorio en tesis.config.json.", p.idx)
            files = [m for m in file_rx.finditer(p.plain) if not re.match(r"https?://", p.plain[max(0, m.start() - 8): m.start() + 8])]
            if p.kind == "cell":  # en tablas se agrupa por tabla: una nota en la leyenda o en la primera celda basta
                if files and not p.has_note_ref and not MARKER_RE.search(p.text):
                    tkey = p.where.split(",")[0]
                    cell_files.setdefault(tkey, [p, set()])[1].update(f.group(0) for f in files)
                continue
            if files and repo_ctx.search(p.plain) and not p.has_note_ref and not MARKER_RE.search(p.text):
                self.add("R06", "ARCHIVO-SIN-NOTA", "AVISO", p.loc(), excerpt(p.plain, files[0].start(), files[0].end()),
                         f"Se nombra(n) archivo(s) del repositorio ({', '.join(sorted({f.group(0) for f in files})[:4])}) sin nota al final con enlace.",
                         "Añadir [Insertar nota al final: URL directa al archivo en GitHub] tras la primera mención.", p.idx)
        for tkey, (p, names) in cell_files.items():
            self.add("R06", "ARCHIVO-SIN-NOTA", "AVISO", p.loc(), ", ".join(sorted(names)[:6]),
                     f"La {tkey} nombra {len(names)} archivo(s) del repositorio sin enlace.",
                     "Una nota al final en la leyenda o la nota de la tabla con la URL de la carpeta del repositorio.", p.idx)

    @staticmethod
    def _self_cite(item, autores, repo, repo_context):
        """ERROR si la cita es claramente de los autores de la tesis, AVISO si solo coincide en parte."""
        if not autores or not re.search(r"(?:19|20)\d{2}", item):
            return None
        hits = [a for a in autores if re.search(r"(?<![\w-])" + re.escape(a) + r"(?![\w-])", item)]
        if not hits:
            return None
        if len(autores) == 1:
            same_year = str(repo.get("anio", "")) in item
            return "ERROR" if (repo_context or same_year) else "AVISO"
        if len(hits) == len(autores) or (hits[0] == autores[0] and "et al" in item):
            return "ERROR"
        return "AVISO"

    # ------------------------------------------------------------------ R07
    def _check_title(self, title, p, label):
        masked = title
        for ph in self._prot:
            masked = re.sub(r"(?<![\w-])" + re.escape(ph) + r"(?![\w-])", lambda m: "§" * len(m.group(0)), masked)
        tokens = list(re.finditer(r"[\wÁÉÍÓÚÑáéíóúñü’'§\-–]+", masked))
        if not tokens:
            return
        first = tokens[0].group(0)
        if first[0].islower() and "§" not in first and not re.search(r"\d", first):
            self.add("R07", "TITULO-INICIAL", "ERROR", p.loc(), title, f"{label} que no empieza con mayúscula.",
                     "Capitalizar la primera palabra.", p.idx)

        def keep(part):  # siglas, Brian2, FlyWire, números romanos, letras sueltas
            return ((len(part) >= 2 and part.isupper()) or re.search(r"\d", part) or re.search(r"[a-z][A-Z]", part)
                    or re.fullmatch(r"[IVXLC]+", part) or len(part) <= 1)

        def lower_word(w):
            return "-".join(x if keep(x) or not x[:1].isupper() else x[0].lower() + x[1:] for x in w.split("-"))

        bad, unsure = [], []
        start = 1 if not re.fullmatch(r"[\d.]+", first) else 2  # «1.1 Título» numerado a mano
        for m in tokens[start:]:
            w = m.group(0).replace("–", "-")
            if "§" in w or not any(x[:1].isupper() and not keep(x) for x in w.split("-")):
                continue
            if masked[: m.start()].rstrip().endswith(":"):
                continue  # APA 7 admite mayúscula tras dos puntos
            (bad if self._body_lower[norm(w)] > 0 else unsure).append(w)
        if not bad and not unsure:
            return
        fixed = title
        for w in bad + unsure:
            fixed = re.sub(r"(?<![\w-])" + re.escape(w) + r"(?![\w-])", lower_word(w), fixed)
        msg = []
        if bad:
            msg.append(f"mayúscula indebida en: {', '.join(bad)} (aparecen en minúscula en el cuerpo)")
        if unsure:
            msg.append(f"por confirmar si son nombres propios: {', '.join(unsure)}")
        fix = f"«{fixed}»"
        if unsure:
            fix += " — si alguna palabra por confirmar es nombre propio, conservar su mayúscula y añadirla a nombres_propios."
        self.add("R07", "TITULO-MAYUSCULAS" if bad else "TITULO-NOMBRE-PROPIO", "ERROR" if bad else "AVISO",
                 p.loc(), title, f"{label} que no está en tipo oración: " + "; ".join(msg) + ".", fix, p.idx)

    def r07_titulos(self):
        body_lower = Counter()
        for p in self.paras:
            if p.kind in ("body", "list", "note", "caption"):
                for s in split_sentences(p.plain):
                    words = re.findall(r"[\wÁÉÍÓÚÑáéíóúñü’'\-]+", s)
                    for w in words[1:]:
                        if w[:1].islower():
                            body_lower[norm(w)] += 1
        self._prot = sorted({x for x in self.protected if x}, key=len, reverse=True)
        self._body_lower = body_lower
        skip_first = re.compile(r"^(cap[ií]tulo|ap[eé]ndice|anexo)\b", re.I)
        for p in self.headings:
            if not self.in_scope(p) or p.region == "front":
                continue
            title = p.plain.strip()
            if not skip_first.match(title):
                self._check_title(title, p, "Título")
        # títulos de tablas y figuras (línea siguiente a «Tabla N» o párrafo siguiente)
        for p in self.paras:
            if p.kind != "caption" or p.region not in ("chapter", "intro", "back") or not self.in_scope(p):
                continue
            title = caption_title(self.paras, p)
            if title:
                self._check_title(title, p, "Título de tabla/figura")
        # nomenclatura binomial
        species = SPECIES_DEFAULT + list(self.cfg.get("especies", []))
        for sp in species:
            g, e = sp.split()[0], sp.split()[1]
            bad_rx = re.compile(r"\b" + re.escape(g) + r"\s+" + re.escape(e[0].upper() + e[1:]) + r"\b")
            for p in self.paras:
                if p.kind in ("empty", "toc") or not self.in_scope(p):
                    continue
                m = bad_rx.search(p.plain)
                if m:
                    self.add("R07", "ESPECIE", "ERROR", p.loc(), excerpt(p.plain, m.start(), m.end()),
                             "Epíteto específico con mayúscula.", f"«{sp}» (género con mayúscula, epíteto en minúscula, en cursiva).",
                             p.idx)

    # ------------------------------------------------------------------ R12 formato
    def _defaults(self):
        st = self.doc.styles.element
        dd = st.find(qn("w:docDefaults"))
        out = {}
        if dd is None:
            return out
        rpr = dd.find(qn("w:rPrDefault") + "/" + qn("w:rPr"))
        if rpr is not None:
            f = rpr.find(qn("w:rFonts"))
            if f is not None and f.get(qn("w:ascii")):
                out["font"] = f.get(qn("w:ascii"))
            sz = rpr.find(qn("w:sz"))
            if sz is not None:
                out["size"] = int(sz.get(qn("w:val"))) / 2
        return out

    def _run_props(self, p_el, para):
        dflt = self._defaults()
        res = []
        for r in para.runs:
            txt = r.text
            if not txt.strip():
                continue

            def chain_val(attr):
                v = getattr(r.font, attr) if attr in ("name", "size") else getattr(r, attr)
                if v is not None:
                    return v
                if r.style is not None and r.style.name not in ("Default Paragraph Font", "Fuente de párrafo predeter."):
                    for s in style_chain(r.style):
                        v = getattr(s.font, attr)
                        if v is not None:
                            return v
                for s in style_chain(para.style):
                    v = getattr(s.font, attr)
                    if v is not None:
                        return v
                return None
            name = chain_val("name") or dflt.get("font")
            size = chain_val("size")
            size = size.pt if size is not None else dflt.get("size")
            res.append((txt, name, size, bool(chain_val("bold")), bool(chain_val("italic"))))
        return res

    def _pfmt(self, para, attr):
        v = getattr(para.paragraph_format, attr)
        if v is not None:
            return v
        for s in style_chain(para.style):
            v = getattr(s.paragraph_format, attr)
            if v is not None:
                return v
        return None

    def r12_formato(self):
        prof = self.prof
        dparas = self.doc.paragraphs
        agg = defaultdict(list)
        body_spec = prof.get("cuerpo", {})
        tf = prof.get("tablas_figuras", {})
        # página
        try:
            s = self.doc.sections[0]
            pg = prof.get("pagina", {})
            if pg and (abs(s.page_width.cm - pg["ancho_cm"]) > 0.2 or abs(s.page_height.cm - pg["alto_cm"]) > 0.2):
                agg["PAGINA"].append(("documento", f"{s.page_width.cm:.1f}×{s.page_height.cm:.1f} cm"))
            for side in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
                v = getattr(s, side)
                if pg and v is not None and abs(v.cm - pg["margen_cm"]) > 0.05:
                    agg["MARGENES"].append(("documento", f"{side}={v.cm:.2f} cm"))
        except Exception:
            pass
        for p in self.paras:
            if not self.in_scope(p) or p.region not in ("chapter", "intro"):
                continue
            para = dparas[p.idx]
            runs = self._run_props(p.el, para)
            if not runs:
                continue
            dom = max(runs, key=lambda x: len(x[0]))
            if p.kind == "body":
                if body_spec.get("fuente") and dom[1] and norm(dom[1]) != norm(body_spec["fuente"]):
                    agg["CUERPO-FUENTE"].append((p.loc(), dom[1]))
                if body_spec.get("tamano_pt") and dom[2] and abs(dom[2] - body_spec["tamano_pt"]) > 0.1:
                    agg["CUERPO-TAMANO"].append((p.loc(), f"{dom[2]} pt"))
                ls, rule = self._pfmt(para, "line_spacing"), self._pfmt(para, "line_spacing_rule")
                if body_spec.get("interlineado") == "doble" and not (
                        (isinstance(ls, float) and abs(ls - 2.0) < 0.05) or (rule is not None and "DOUBLE" in str(rule))):
                    agg["CUERPO-INTERLINEADO"].append((p.loc(), f"{ls} {rule}"))
                fi = self._pfmt(para, "first_line_indent")
                want = body_spec.get("sangria_primera_linea_cm")
                if want and (fi is None or abs(fi.cm - want) > 0.05):
                    agg["CUERPO-SANGRIA"].append((p.loc(), "sin sangría" if fi is None else f"{fi.cm:.2f} cm"))
                al = self._pfmt(para, "alignment")
                if body_spec.get("alineacion") == "justificado" and (al is None or not re.search("JUSTIFY|DISTRIBUTE", str(al))):
                    agg["CUERPO-ALINEACION"].append((p.loc(), str(al)))
                for k, key in (("space_before", "espacio_antes_pt"), ("space_after", "espacio_despues_pt")):
                    v = self._pfmt(para, k)
                    if key in body_spec and v is not None and abs(v.pt - body_spec[key]) > 0.5:
                        agg["CUERPO-ESPACIADO"].append((p.loc(), f"{k}={v.pt:.0f} pt"))
            elif p.kind == "caption":
                m = CAPTION_RE.match(p.plain)
                label_len = m.end() if m else 0
                acc, lab_runs, tit_runs = 0, [], []
                for r in runs:
                    (lab_runs if acc < label_len else tit_runs).append(r)
                    acc += len(r[0])
                if tf.get("tamano_pt") and dom[2] and abs(dom[2] - tf["tamano_pt"]) > 0.1:
                    agg["LEYENDA-TAMANO"].append((p.loc(), f"{dom[2]} pt"))
                et = tf.get("etiqueta", {})
                if lab_runs and et and (not all(r[3] for r in lab_runs) or any(r[4] for r in lab_runs)):
                    agg["LEYENDA-ETIQUETA"].append((p.loc(), p.plain[:30]))
                if tit_runs and tf.get("titulo", {}).get("cursiva") and not all(r[4] for r in tit_runs if r[0].strip()):
                    agg["LEYENDA-TITULO"].append((p.loc(), p.plain[:50]))
                cap_t = caption_title(self.paras, p)
                if re.search(r"\.\s*$", p.plain.split("\n")[0]) or (cap_t and re.search(r"[^.]\.\s*$", cap_t)):
                    agg["LEYENDA-PUNTO"].append((p.loc(), (cap_t or p.plain)[:60]))
            elif p.kind == "note":
                first = runs[0]
                if tf.get("nota", {}).get("cursiva") and not first[4]:
                    agg["NOTA-CURSIVA"].append((p.loc(), p.plain[:40]))
            elif p.kind == "heading" and p.level:
                spec = prof.get("titulos", {}).get(str(p.level))
                if not spec:
                    continue
                al = self._pfmt(para, "alignment")
                if spec.get("alineacion") == "centrado" and (al is None or "CENTER" not in str(al)):
                    agg[f"TITULO{p.level}-ALINEACION"].append((p.loc(), str(al)))
                if spec.get("negrita") and not dom[3]:
                    agg[f"TITULO{p.level}-NEGRITA"].append((p.loc(), p.plain[:50]))
                if "cursiva" in spec and bool(dom[4]) != spec["cursiva"]:
                    agg[f"TITULO{p.level}-CURSIVA"].append((p.loc(), p.plain[:50]))
                if p.level > 1 and re.search(r"\.\s*$", p.plain):
                    agg["TITULO-PUNTO"].append((p.loc(), p.plain[:50]))
        for code, items in agg.items():
            self.add("R12", f"FORMATO-{code}", "AVISO", f"{len(items)} caso(s)",
                     "; ".join(f"{a}: {b}" for a, b in items[:4]),
                     f"Formato distinto al perfil «{prof.get('nombre', '')}» (verificar en Word; la herencia de estilos puede ocultar el valor real).",
                     "Corregir con el estilo de Word correspondiente, no con formato directo.")

    # ------------------------------------------------------------------ R13 APA
    # ------------------------------------------------------------------ R15
    def r15_intro_tablas_figuras(self):
        lo, hi = self.prof.get("limites", {}).get("intro_tabla_figura_palabras", [15, 60])
        for p in self.paras:
            if p.kind != "caption" or p.region not in ("chapter", "intro", "back") or not self.in_scope(p):
                continue
            m = CAPTION_RE.match(p.plain)
            kind, num = m.group(1).lower(), m.group(2)
            label = f"{kind} {num}"
            prev = next((q for q in reversed(self.paras[:p.idx]) if q.kind not in ("empty", "template")), None)
            if prev is None or prev.kind not in ("body", "list"):
                what = {"heading": "un título", "caption": "otra leyenda", "note": "la nota de otro elemento"}.get(
                    prev.kind if prev else "", "otro elemento")
                self.add("R15", "INTRO-TABLA-FIGURA", "ERROR", p.loc(), p.plain.split("\n")[0][:60],
                         f"La {label} aparece justo después de {what}, sin párrafo que la presente.",
                         f"Insertar antes de la leyenda 2–3 líneas: «La {label} muestra/compara/resume… [qué se ve y para qué sirve]».",
                         p.idx)
                continue
            mentions = re.findall(r"\b" + kind + r"s?\s+((?:[A-Z]?\d+)(?:\s*(?:,|y|a)\s*[A-Z]?\d+)*)", prev.plain, re.I)
            nums = {n for grp in mentions for n in re.findall(r"[A-Z]?\d+", grp)}
            if num not in nums and re.search(r"\b(?:" + kind + r"\s+siguiente|siguiente\s+" + kind + r")\b", prev.plain, re.I):
                self.add("R15", "INTRO-TABLA-FIGURA-SIN-NUMERO", "AVISO", prev.loc(), excerpt(prev.plain, max(0, len(prev.plain) - 120)),
                         f"La {label} se presenta como «la {kind} siguiente», sin su número.",
                         f"Nombrarla por su número (APA): «La {label} …».", prev.idx)
                continue
            if num not in nums:
                self.add("R15", "INTRO-TABLA-FIGURA", "ERROR", prev.loc(), excerpt(prev.plain, max(0, len(prev.plain) - 120)),
                         f"El párrafo anterior a la {label} no la presenta.",
                         f"Añadir antes de la leyenda un párrafo breve (2–3 líneas) que nombre la {label} y diga qué muestra.",
                         prev.idx)
                continue
            w = word_count(prev.plain)
            if w > hi:
                self.add("R15", "INTRO-TABLA-FIGURA-LARGA", "AVISO", prev.loc(), f"{label}: {w} palabras",
                         f"La presentación de la {label} está dentro de un párrafo de {w} palabras (2–3 líneas ≈ {lo}–{hi}).",
                         f"Separar en un párrafo propio y breve justo antes de la leyenda.", prev.idx)
            elif w < lo:
                self.add("R15", "INTRO-TABLA-FIGURA-CORTA", "AVISO", prev.loc(), prev.plain[:120],
                         f"La presentación de la {label} tiene {w} palabras (menos de 2 líneas).",
                         "Ampliar a 2–3 líneas: qué muestra y qué debe mirar el lector.", prev.idx)

    PARTICLES = {"van", "von", "de", "del", "der", "den", "la", "le", "da", "das", "di", "dos", "du", "ten", "ter"}
    YEAR = r"(?:(?:19|20)\d{2}[a-z]?|s\. ?f\.|en prensa)"

    @classmethod
    def cite_key(cls, author, year):
        """(primer apellido normalizado, año) — robusto a iniciales, partículas, puntos y corchetes."""
        a = re.sub(r"\[[^\]]*\]", "", author)
        a = re.sub(r"(?<![\w-])(?:[A-ZÁÉÍÓÚÑ]\.\s*)+", "", a).strip()
        a = re.split(r"\s+(?:et al\.?|y|&)(?:\s|$)|,", a)[0].strip()
        words = [w for w in a.split() if w.lower() not in cls.PARTICLES] or a.split() or [a]
        return norm(words[0]).strip(".,;:"), year.replace(" ", "")[:5]

    @classmethod
    def parse_parenthetical(cls, inner):
        """Autores-año dentro de un paréntesis: (A, 2020; B y C, 2021), (Brian2, usado por Shiu et al., 2024),
        (Hebb, 1949, como se citó en Gerstner et al., 2014), (flywire-jo-snn, 2026)."""
        out = []
        prev = 0
        for ym in re.finditer(r",\s*(" + cls.YEAR + r")", inner):
            seg = inner[prev:ym.start()]
            prev = ym.end()
            seg = re.split(r";", seg)[-1]
            seg = re.split(r",\s+", seg.strip(" ,;"))[-1] if "," in seg else seg.strip(" ,;")
            words = seg.split()
            if any(w[:1].isupper() for w in words):  # quitar conectores iniciales en minúscula
                while words and not words[0][:1].isupper() and words[0].lower() not in cls.PARTICLES:
                    words.pop(0)
            seg = " ".join(words)
            if seg and not re.fullmatch(r"(?:p|pp|párr|cap)\.?.*", seg):
                out.append((seg, ym.group(1)))
        return out

    def r13_apa(self):
        refs = [p for p in self.paras if p.kind == "ref"]
        real_refs = [p for p in refs if re.search(r"\((?:19|20)\d{2}[a-z]?|s\. ?f\.", p.plain)]
        populated = len(real_refs) >= 5
        cit_par = re.compile(r"\(([^()]*?" + self.YEAR + r"[^()]*)\)")
        narr_rx = re.compile(r"((?:(?:van|von|de|del|der|la|le|da|di|dos)\s+)*[A-ZÁÉÍÓÚÑ][\w’'\-]+"
                             r"(?:\s+(?:y|&)\s+[A-ZÁÉÍÓÚÑ][\w’'\-]+|\s+et al\.)?)\s+\((" + self.YEAR + r")(?:[,;][^)]*)?\)")
        conector = self.prof.get("citas", {}).get("conector_dos_autores", "y")
        wrong_rx = re.compile(r"&") if conector == "y" else re.compile(r"[A-Za-zÀ-ÿ’'\-]+ y [A-ZÁÉÍÓÚÑ]")
        abbrev = {}  # [OMS] → clave del nombre completo
        cites = []
        for p in self.prose_all:  # las citas se recogen en todo el documento aunque se audite un capítulo
            t = p.plain
            for m in cit_par.finditer(t):
                inner = m.group(1)
                if wrong_rx.search(inner) and self.in_scope(p):
                    other = "&" if conector == "y" else "y"
                    self.add("R13", "CONECTOR-AUTORES", "AVISO", p.loc(), excerpt(t, m.start(), m.end()),
                             f"El perfil usa «{conector}» entre autores y aquí aparece «{other}».",
                             f"Cambiar «{other}» por «{conector}» (una sola convención en todo el documento).", p.idx)
                for auth, yr in self.parse_parenthetical(inner):
                    for ab in re.findall(r"\[([^\]]+)\]", auth):
                        abbrev[norm(ab)] = self.cite_key(auth, yr)[0]
                    cites.append((self.cite_key(auth, yr), p, f"{auth}, {yr}"))
            for m in narr_rx.finditer(t):
                if m.group(1).split()[0] in ("En", "Desde", "Hasta", "Entre", "Para", "Tabla", "Figura", "Capítulo", "Sección"):
                    continue
                cites.append((self.cite_key(m.group(1), m.group(2)), p, m.group(0)))
        cites = [((abbrev.get(k[0], k[0]), k[1]), p, raw) for k, p, raw in cites]
        ref_keys = {}
        for r in real_refs:
            m = re.match(r"\s*(.+?)\s*\(((?:19|20)\d{2}[a-z]?|s\. ?f\.)", r.plain)
            if m:
                ref_keys[self.cite_key(m.group(1), m.group(2))] = r
            if "http://dx.doi.org" in r.plain or re.search(r"\bdoi:\s*10\.", r.plain, re.I):
                self.add("R13", "DOI-FORMATO", "AVISO", r.loc(), r.plain[:120],
                         "DOI con formato antiguo.", "Usar https://doi.org/10.xxxx/yyyy", r.idx)

        def match(k, keys):
            return k in keys or any(k[0] == x[0] and k[1][:4] == x[1][:4] for x in keys)

        if populated:
            cited = {k for k, _, _ in cites}
            for k, p, raw in cites:
                if self.in_scope(p) and not match(k, ref_keys):
                    self.add("R13", "CITA-SIN-REFERENCIA", "ERROR", p.loc(), raw,
                             "Cita sin entrada correspondiente en Referencias.",
                             "Añadir la referencia verificada (verify_refs.py) o corregir autor/año.", p.idx)
            if self.chapter is None:
                for k, r in ref_keys.items():
                    if not match(k, cited):
                        self.add("R13", "REFERENCIA-SIN-CITA", "AVISO", r.loc(), r.plain[:120],
                                 "Referencia que no se cita en el texto.", "Citarla o eliminarla.", r.idx)
                names = [strip_accents(r.plain).lower() for r in real_refs]
                for a, b, r in zip(names, names[1:], real_refs[1:]):
                    if b < a and not b.startswith(a[:3]):
                        self.add("R13", "ORDEN-ALFABETICO", "AVISO", r.loc(), r.plain[:80],
                                 "Referencias fuera de orden alfabético.", "Ordenar por apellido del primer autor.", r.idx)
                        break
        else:
            self.add("R13", "REFERENCIAS-VACIAS", "INFO", "Referencias",
                     f"{len(real_refs)} entrada(s) con año", "La lista de referencias está vacía o es de plantilla; no se cruzaron citas.",
                     "Completar la lista y volver a auditar. Verificar cada DOI con verify_refs.py.")
        self.metrics["citas_en_texto"] = len(cites)
        self.metrics["referencias"] = len(real_refs)

    # ------------------------------------------------------------------ H humanización
    def h_humanizacion(self):
        sents, colons, dashes = [], 0, []
        words_total = 0
        hits = Counter()
        conn = Counter()
        for p in self.body:
            t = re.sub(r"https?://\S+", "", p.plain)
            words_total += word_count(t)
            for s in split_sentences(t):
                n = word_count(s)
                if n:
                    sents.append((n, p, s))
            c = len(re.findall(r":(?!\d)(?!//)", t))
            colons += c
            for m in re.finditer("—", t):
                dashes.append((p, m.start()))
            for rx, label in AI_PATTERNS:
                for m in re.finditer(rx, t, re.I | re.M):
                    hits[label] += 1
                    if hits[label] <= 3:
                        self.add("H", "VOCAB-IA", "AVISO", p.loc(), excerpt(t, m.start(), m.end()),
                                 f"Patrón típico de texto generado: {label}.",
                                 "Reformular de forma directa y concreta (ver references/humanizacion.md).", p.idx)
            for c_ in CONNECTORS:
                conn[c_] += len(re.findall(r"\b" + re.escape(c_) + r"\b", t, re.I))
        if not sents:
            return
        lens = [n for n, _, _ in sents]
        mean = statistics.mean(lens)
        sd = statistics.pstdev(lens)
        long_ = [(n, p, s) for n, p, s in sents if n > 45]
        per_k = 1000 / max(words_total, 1)
        self.metrics.update({
            "palabras_cuerpo": words_total, "oraciones": len(sents),
            "longitud_media_oracion": round(mean, 1), "desviacion_longitud": round(sd, 1),
            "oraciones_>45_palabras": len(long_), "dos_puntos_por_1000_palabras": round(colons * per_k, 2),
            "rayas_em": len(dashes),
            "conectores_por_1000_palabras": {k: round(v * per_k, 2) for k, v in conn.items() if v},
            "patrones_ia": dict(hits),
        })
        if mean > 22:
            self.add("H", "ORACIONES-LARGAS", "AVISO", "cuerpo", f"media {mean:.1f} palabras",
                     "Longitud media de oración alta (cadencia uniforme típica de IA).",
                     "Objetivo 14–20 palabras de media con oraciones muy cortas intercaladas.")
        if sd < 0.45 * mean:
            self.add("H", "BAJA-VARIACION", "AVISO", "cuerpo", f"desv. {sd:.1f} / media {mean:.1f}",
                     "Poca variación en la longitud de las oraciones (baja «burstiness»).",
                     "Mezclar oraciones de 4–8 palabras con otras de 30+.")
        if colons * per_k > 1.0:
            self.add("H", "DOS-PUNTOS", "AVISO", "cuerpo", f"{colons} dos puntos ({colons * per_k:.1f} por 1000 palabras)",
                     "Exceso del patrón «afirmación: explicación».",
                     "Partir en dos oraciones o integrar la explicación. Meta ≤ 1 por cada 1000 palabras.")
        if len(dashes) * per_k > 0.5:  # la raya de inciso es legítima en español; solo se avisa si abunda
            self.add("H", "RAYAS", "AVISO", "cuerpo", "; ".join(excerpt(p.plain, pos, pos + 1)[:80] for p, pos in dashes[:3]),
                     f"{len(dashes)} rayas (—) en el cuerpo ({len(dashes) * per_k:.1f} por 1000 palabras).",
                     "Dejar solo las imprescindibles; el resto, comas o paréntesis.")
        for n, p, s in sorted(long_, key=lambda x: -x[0])[:8]:
            self.add("H", "ORACION-LARGA", "INFO", p.loc(), s[:160] + ("…" if len(s) > 160 else ""),
                     f"Oración de {n} palabras.", "Dividir en dos o tres oraciones de longitud desigual.", p.idx)
        for c_, v in conn.items():
            if v * per_k > 2.5:
                self.add("H", "CONECTOR-REPETIDO", "AVISO", "cuerpo", f"«{c_}»: {v} veces",
                         "Conector sobreusado.", "Eliminar la mayoría; la secuencia lógica suele bastar.")

    # ------------------------------------------------------------------ X referencias cruzadas
    def x_crossrefs(self):
        numbers = {p.number for p in self.headings if p.number}
        nchap = max([p.chapter or 0 for p in self.paras] + [0])
        sec_rx = re.compile(r"\b(?:secci[oó]n|secciones|apartado|apartados|subsecci[oó]n|ep[ií]grafe)\s+((?:\d+(?:\.\d+)+)(?:\s*(?:,|y|a|e|o)\s*\d+(?:\.\d+)+)*)", re.I)
        cap_rx = re.compile(r"\bcap[ií]tulo\s+(\d+)\b", re.I)
        for p in self.prose:
            for m in (sec_rx.finditer(p.plain) if numbers else []):  # sin numeración detectada no se puede comprobar
                for num in re.findall(r"\d+(?:\.\d+)+", m.group(1)):
                    if num not in numbers:
                        self.add("X", "SECCION-INEXISTENTE", "ERROR", p.loc(), excerpt(p.plain, m.start(), m.end()),
                                 f"Remite a la sección {num}, que no existe.", "Corregir el número de sección.", p.idx)
            for m in cap_rx.finditer(p.plain):
                if int(m.group(1)) > nchap and nchap:
                    self.add("X", "CAPITULO-INEXISTENTE", "ERROR", p.loc(), excerpt(p.plain, m.start(), m.end()),
                             f"Remite al capítulo {m.group(1)}, que no existe.", "Corregir.", p.idx)
        # tablas y figuras
        caps = defaultdict(list)
        for p in self.paras:
            if p.kind == "caption" and p.region in ("chapter", "intro"):
                m = CAPTION_RE.match(p.plain)
                caps[m.group(1).lower()].append((m.group(2), p))
        mentions = defaultdict(set)
        for p in self.paras:
            if p.kind in ("body", "list", "note") and p.region in ("chapter", "intro", "back"):
                for m in re.finditer(r"\b(tabla|figura)s?\s+(\d+)((?:\s*(?:,|y|a)\s*\d+)*)", p.plain, re.I):
                    for n in [m.group(2)] + re.findall(r"\d+", m.group(3)):
                        mentions[m.group(1).lower()].add(n)
                        if n not in {c[0] for c in caps[m.group(1).lower()]} and caps[m.group(1).lower()]:
                            if self.in_scope(p):
                                self.add("X", "TABLA-FIGURA-INEXISTENTE", "ERROR", p.loc(), excerpt(p.plain, m.start(), m.end()),
                                         f"Se menciona {m.group(1).lower()} {n}, que no existe.", "Corregir la numeración.", p.idx)
        for kind, lst in caps.items():
            prev = None
            for num, p in lst:
                if not self.in_scope(p):
                    prev = num
                    continue
                if num not in mentions[kind]:
                    self.add("X", "SIN-MENCION", "AVISO", p.loc(), p.plain.split("\n")[0][:80],
                             f"{kind.capitalize()} {num} no se menciona en el texto.",
                             f"Anunciarla en el párrafo previo («La {kind} {num} muestra…»).", p.idx)
                if prev and num.isdigit() and prev.isdigit() and int(num) != int(prev) + 1:
                    self.add("X", "NUMERACION", "AVISO", p.loc(), p.plain.split("\n")[0][:80],
                             f"{kind.capitalize()} {num} tras {prev}: numeración no consecutiva.", "Renumerar.", p.idx)
                prev = num
        # siglas
        seen = set()
        for p in self.body:
            for m in re.finditer(r"(?<![\w-])([A-ZÁÉÍÓÚÑ]{2,6})s?(?![\w-])", p.plain):
                s = m.group(1)
                if s in seen or s in ACRONYM_WHITELIST:
                    continue
                seen.add(s)
                ctx = p.plain[max(0, m.start() - 120): m.end() + 120]
                if re.search(r"\(\s*" + s, ctx) or re.search(s + r"s?\s*\(", ctx) or re.search(r"por sus siglas", ctx, re.I):
                    continue
                self.add("X", "SIGLA-SIN-DEFINIR", "INFO", p.loc(), excerpt(p.plain, m.start(), m.end()),
                         f"Primera aparición de «{s}» sin desarrollo visible.",
                         "Desarrollar la sigla en su primera aparición: «nombre completo (SIGLA)».", p.idx)

    # ------------------------------------------------------------------ T plantilla
    def t_plantilla(self):
        tp = [p for p in self.paras if p.kind == "template" and self.in_scope(p)]
        if tp:
            self.add("T", "PLANTILLA", "AVISO", f"{len(tp)} párrafo(s)",
                     "; ".join(f"{p.idx}: {p.plain[:50]}" for p in tp[:5]),
                     "Quedan instrucciones o relleno de la plantilla institucional.",
                     "Borrarlos o sustituirlos antes de entregar.")

    def run(self):
        steps = [("R01", self.r01_preguntas), ("R02", self.r02_notas), ("R03", self.r03_r04_intros),
                 ("R05", self.r05_elaboracion), ("R06", self.r06_repositorio), ("R07", self.r07_titulos),
                 ("R12", self.r12_formato), ("R13", self.r13_apa), ("R15", self.r15_intro_tablas_figuras),
                 ("H", self.h_humanizacion),
                 ("X", self.x_crossrefs), ("T", self.t_plantilla)]
        for rule, fn in steps:
            if self.on(rule) or (rule == "R03" and self.on("R04")):
                fn()
        if self.only:
            self.f = [x for x in self.f if x.rule in self.only]
        self.f.sort(key=lambda x: (SEV_ORDER[x.sev], x.rule, x.idx if x.idx is not None else -1))
        return self.f


def render_md(aud: Auditor, path: str) -> str:
    f = aud.f
    cnt = Counter(x.sev for x in f)
    by_rule = defaultdict(list)
    for x in f:
        by_rule[x.rule].append(x)
    out = [f"# Informe de auditoría — {Path(path).name}", ""]
    if aud.chapter:
        out.append(f"Alcance: capítulo {aud.chapter}")
    out.append(f"Config: {aud.cfg.get('_path', 'no encontrada (comprobaciones de R02/R06 limitadas)')}")
    out.append(f"Perfil: {aud.prof.get('nombre')}")
    out += ["", f"**{cnt['ERROR']} ERROR · {cnt['AVISO']} AVISO · {cnt['INFO']} INFO**", "",
            "| Regla | Descripción | ERROR | AVISO | INFO |", "|---|---|---|---|---|"]
    for r, desc in RULES.items():
        c = Counter(x.sev for x in by_rule.get(r, []))
        out.append(f"| {r} | {desc} | {c['ERROR']} | {c['AVISO']} | {c['INFO']} |")
    if aud.metrics:
        out += ["", "## Métricas", ""]
        for k, v in aud.metrics.items():
            out.append(f"- {k}: {v}")
    for r, desc in RULES.items():
        items = by_rule.get(r)
        if not items:
            continue
        out += ["", f"## {r} — {desc}", ""]
        for x in items:
            out.append(f"- **{x.sev}** `{x.code}` · {x.loc}")
            out.append(f"  - Texto: {x.excerpt}")
            out.append(f"  - Problema: {x.msg}")
            if x.fix:
                out.append(f"  - Corrección: {x.fix}")
    return "\n".join(out) + "\n"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("docx")
    ap.add_argument("--config")
    ap.add_argument("--chapter", type=int)
    ap.add_argument("--only", help="lista de reglas separadas por coma (R01,R02,…,H,X,T)")
    ap.add_argument("--out", help="guardar informe Markdown")
    ap.add_argument("--json", help="guardar hallazgos en JSON")
    ap.add_argument("--strict", action="store_true", help="exit 1 si hay algún ERROR")
    a = ap.parse_args()

    cfg = load_config(a.docx, a.config)
    prof = load_profile(cfg)
    aud = Auditor(open_docx(a.docx), cfg, prof, a.chapter, a.only.split(",") if a.only else None)
    aud.run()
    md = render_md(aud, a.docx)
    if a.out:
        Path(a.out).write_text(md, encoding="utf-8")
        print(f"Informe: {a.out}")
        c = Counter(x.sev for x in aud.f)
        print(f"{c['ERROR']} ERROR · {c['AVISO']} AVISO · {c['INFO']} INFO")
    else:
        sys.stdout.write(md)
    if a.json:
        Path(a.json).write_text(json.dumps({"metricas": aud.metrics, "hallazgos": [x.as_dict() for x in aud.f]},
                                           ensure_ascii=False, indent=1), encoding="utf-8")
    if a.strict and any(x.sev == "ERROR" for x in aud.f):
        sys.exit(1)


if __name__ == "__main__":
    main()
