# Estructura de capítulos

Esqueletos por tipo de capítulo para un trabajo de titulación de ingeniería o ciencias (con
variantes para ciencias sociales). Adaptar a la plantilla institucional y al índice que ya tenga
el usuario: si el documento existe, su estructura manda y aquí solo se toman las buenas prácticas.

Cada capítulo empieza así (UTPL):
```
Capítulo dos                                 ← título nivel 1
Marco teórico y revisión de literatura       ← título nivel 1, tipo oración
[Párrafo introductorio del capítulo — R03]
2.1 Marco teórico                            ← nivel 2
[3–4 líneas que anticipan la sección — R04]
2.1.1 Fundamentos de la neurociencia computacional   ← nivel 3
…
```

## Introducción (sin numerar, ≤ 2 páginas en UTPL)

Modelo CARS en prosa, sin preguntas:
1. **Territorio:** por qué el tema importa, con citas (no «desde tiempos remotos»).
2. **Nicho:** la brecha, autorizada por la revisión de literatura y acotada («en las búsquedas
   realizadas no se identificó…»). El paso «plantear una pregunta» se redacta como afirmación:
   «Aún no se ha comprobado si…».
3. **Ocupar el nicho:** propósito en una frase activa («Este trabajo compara…»), aporte y
   estructura del documento (un párrafo que recorre los capítulos).

## Capítulo 1. Planteamiento de la investigación

1. Contextualización (problema en su contexto, datos concretos con cita)
2. Retos existentes / problema de investigación
3. Justificación (teórica, práctica, metodológica)
4. Objetivos (general y específicos, verbos en infinitivo medibles)
5. Pregunta de investigación e hipótesis — **único lugar donde va una pregunta (R01)**
6. Alcance y limitaciones
7. Metodología de investigación (resumen; el detalle va en su capítulo)

## Capítulo 2. Marco teórico y estado del arte

1. Marco teórico: conceptos de lo general a lo particular, cada concepto definido una vez y con
   cita de obra fundacional o manual reconocido. Aquí se explican los conceptos que más tarde
   llevarán nota al final si reaparecen lejos (R02).
2. Estado del arte: síntesis por temas, no resumen fuente a fuente («A halló X. B halló Y.» es
   volcado de literatura). Cada tema termina diciendo qué falta.
3. Trabajos relacionados: tabla comparativa (método, datos, resultado, diferencia con este trabajo).
4. Síntesis y brecha: la brecha que justifica el trabajo, acotada a la búsqueda documentada.

## Capítulo 3. Metodología

1. Enfoque y diseño (tipo de investigación, metodología de proceso como CRISP-DM, KDD, Scrum,
   Design Science), justificado con cita.
2. Solución propuesta / arquitectura.
3. Fases o etapas con actividades, entradas y salidas (tabla).
4. Variables, métricas y criterios de evaluación (definición operacional de cada una).
5. Herramientas (librerías clave con nota al final, R02), datos y su licencia.
6. Consideraciones éticas y de reproducibilidad (repositorio citado como repositorio, R06).
7. Riesgos y mitigación (si aplica).

## Capítulos de desarrollo (datos, implementación, experimentación)

- Narrar decisiones con su evidencia: qué se probó, qué salió, por qué se eligió una opción.
- Cada cifra con su origen (archivo del repositorio con nota al final, R06).
- Tablas de parámetros finales y de configuraciones experimentales.
- Lecciones o errores corregidos (útiles para la defensa), sin dramatizar.
- Cerrar con una síntesis breve de lo que queda fijado para el capítulo siguiente.

## Resultados y discusión

1. Cómo leer los resultados (métricas, línea base, azar, tamaño de muestra).
2. Resultados principales en el orden de los objetivos/hipótesis, hallazgo antes que la prueba
   estadística («La red del conectoma superó al control ER por 0,12; *p* = .003»).
3. Pruebas estadísticas con tamaño del efecto e IC; corrección por comparaciones múltiples.
4. Controles de robustez.
5. Discusión: interpretación → comparación con la literatura → explicaciones alternativas →
   implicaciones. Sin repetir los números de la sección de resultados.
6. Limitaciones (diseño, datos, generalización), honestas y específicas.

## Conclusiones (sin numerar)

Una conclusión por objetivo específico, en el mismo orden, respondiendo la pregunta de
investigación y diciendo si cada hipótesis se sostiene. Sin datos nuevos ni citas nuevas.

## Recomendaciones (sin numerar)

Trabajo futuro concreto y accionable, derivado de las limitaciones.

## Resumen y Abstract

Un párrafo, ≤ 180 palabras (UTPL), ≤ 3 palabras clave. Antecedente (1 oración) · objetivo (1) ·
método (1–2) · resultados con cifras (2–3) · conclusión (1). Sin citas ni siglas sin desarrollar.
El Abstract se redacta en inglés con las mismas ideas y cifras, no como traducción literal.

## Plantillas de párrafo introductorio

**Capítulo (R03), 4–8 líneas:**
> Este capítulo [qué hace: describe / compara / presenta] [objeto], que corresponde a [objetivo
> específico o fase]. [Por qué viene aquí: qué resolvió el capítulo anterior y qué falta.]
> [Recorrido en prosa: primero…, después…, y al final…]. [Qué deja listo para el siguiente.]

**Sección x.x (R04), 3–4 líneas:**
> [Idea central de la sección en una oración.] [Qué contiene y en qué orden, sin numerar
> subsecciones.] [Para qué sirve dentro del capítulo, opcional.]

Evitar: repetir el título, «En esta sección se abordará…» sin contenido, enumerar «4.2.1…, 4.2.2…».

**Tabla o figura (R15), 2–3 líneas, justo antes de la leyenda:**
> La [tabla/figura N] [muestra / resume / compara / sitúa] [qué contiene]. [Qué debe mirar el
> lector o para qué sirve en el argumento, opcional.]
