"""Pruebas de humo: un .docx sintético con una violación de cada regla.

Ejecutar:  python3 -m unittest discover -s tests -v
No requiere red (verify_refs.py se prueba solo en su parte offline).
"""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import docx
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm, Pt

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))


def body(doc, text):
    p = doc.add_paragraph(text)
    pf = p.paragraph_format
    pf.first_line_indent = Cm(1.27)
    pf.line_spacing = 2.0
    pf.space_after = Pt(0)
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    for r in p.runs:
        r.font.name = "Arial"
        r.font.size = Pt(11)
    return p


def make_sample(path):
    d = docx.Document()
    d.add_heading("Introducción", 1)
    body(d, "Este trabajo estudia redes de pulsos sobre un conectoma.")
    d.add_heading("Capítulo uno", 1)
    d.add_heading("Planteamiento de la Investigación", 1)          # R07 + R03 (sin intro)
    d.add_heading("Contextualización", 2)                         # R04 (salta a 1.1.1)
    d.add_heading("El Agotamiento del Paradigma Actual", 3)       # R07
    body(d, "¿Por qué importa la energía? Porque el cómputo crece sin pausa en la inteligencia "
            "artificial y en el agotamiento del paradigma actual.")  # R01
    body(d, "La simulación usa Brian2 con neuronas LIF (Shiu et al., 2024).")  # R02 sin nota
    body(d, "El código está en el repositorio público, en results.md (Mora y Alvarez, 2026).")  # R06
    body(d, "La especie Drosophila Melanogaster tiene un conectoma completo.")  # R07 especie
    body(d, "Como se vio en la sección 1.9, la tabla 1 resume los datos.")  # X sección inexistente
    p = d.add_paragraph("Tabla 1\nDatos del subgrafo")
    p.runs[0].bold = True
    d.add_paragraph("Nota. Elaboración propia.")                  # R05
    d.add_paragraph("Figura 1\nEsquema del pipeline")              # R15 (sin presentación)
    d.add_heading("Objetivos", 2)
    body(d, "Pregunta de investigación. ¿La topología biológica supera a la artificial?")  # permitido
    d.save(path)


def run(*args):
    r = subprocess.run([sys.executable, *map(str, args)], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


class TestScripts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp())
        cls.docx = cls.tmp / "muestra.docx"
        make_sample(cls.docx)
        (cls.tmp / "tesis.config.json").write_text(json.dumps({
            "autores": ["Mora", "Alvarez"],
            "repositorio": {"nombre": "repo-demo", "url": "https://github.com/u/repo-demo", "anio": 2026},
            "terminos_nota": {"Brian2": "https://brian2.readthedocs.io/"},
        }), encoding="utf-8")

    def audit(self):
        out = self.tmp / "h.json"
        code, log = run(SCRIPTS / "audit_tesis.py", self.docx, "--json", out, "--out", self.tmp / "i.md")
        self.assertEqual(code, 0, log)
        return {h["code"] for h in json.loads(out.read_text())["hallazgos"]}, json.loads(out.read_text())

    def test_dump_numbering(self):
        code, out = run(SCRIPTS / "dump_docx.py", self.docx, "--outline")
        self.assertEqual(code, 0, out)
        self.assertIn("1.1 Contextualización", out)
        self.assertIn("1.1.1 El Agotamiento", out)

    def test_audit_detects_each_rule(self):
        codes, data = self.audit()
        for c in ["PREGUNTA", "NOTA-TERMINO", "INTRO-CAPITULO", "INTRO-SECCION", "ELABORACION-PROPIA",
                  "AUTOCITA", "ARCHIVO-SIN-NOTA", "TITULO-MAYUSCULAS", "ESPECIE", "SECCION-INEXISTENTE",
                  "INTRO-TABLA-FIGURA", "INTRO-TABLA-FIGURA-CORTA"]:
            self.assertIn(c, codes, c)
        preguntas = [h for h in data["hallazgos"] if h["code"] == "PREGUNTA"]
        self.assertEqual(len(preguntas), 1, "la pregunta de investigación no debe marcarse")

    def test_edit_and_endnotes(self):
        from _common import build_model
        paras = build_model(docx.Document(self.docx))
        idx = {p.plain.strip()[:20]: p.idx for p in paras if p.plain.strip()}
        q = idx["¿Por qué importa la "]
        lib = idx["La simulación usa Br"]
        h = idx["Planteamiento de la "]
        ops = [
            {"op": "replace_in", "p": q, "find": "¿Por qué importa la energía? Porque el",
             "repl": "La energía importa porque el"},
            {"op": "replace_in", "p": lib, "find": "Brian2", "repl": "Brian2[Insertar nota al final: https://brian2.readthedocs.io/]"},
            {"op": "heading", "p": h, "text": "Planteamiento de la investigación"},
            {"op": "insert_after", "p": h, "text": "Este capítulo plantea el problema y sus límites."},
        ]
        ej = self.tmp / "ops.json"
        ej.write_text(json.dumps(ops, ensure_ascii=False), encoding="utf-8")
        v2, v3 = self.tmp / "v2.docx", self.tmp / "v3.docx"
        code, log = run(SCRIPTS / "edit_docx.py", self.docx, ej, "-o", v2)
        self.assertEqual(code, 0, log)
        code, log = run(SCRIPTS / "insert_endnotes.py", v2, "-o", v3)
        self.assertEqual(code, 0, log)
        self.assertIn("1 nota(s) al final", log)
        d = docx.Document(v3)
        text = "\n".join(p.text for p in d.paragraphs)
        self.assertNotIn("¿Por qué", text)
        self.assertNotIn("[Insertar nota", text)
        self.assertIn("Planteamiento de la investigación", text)
        out = self.tmp / "h3.json"
        run(SCRIPTS / "audit_tesis.py", v3, "--json", out, "--out", self.tmp / "i3.md")
        codes3 = {x["code"] for x in json.loads(out.read_text())["hallazgos"]}
        for c in ["PREGUNTA", "NOTA-TERMINO", "INTRO-CAPITULO"]:
            self.assertNotIn(c, codes3, c)

    def test_edit_refuses_overwrite(self):
        ej = self.tmp / "noop.json"
        ej.write_text("[]", encoding="utf-8")
        code, log = run(SCRIPTS / "edit_docx.py", self.docx, ej, "-o", self.docx)
        self.assertNotEqual(code, 0)

    def test_r15_intro_variants(self):
        from audit_tesis import Auditor
        from _common import load_profile
        d = docx.Document()
        d.add_heading("Introducción", 1)
        d.add_heading("Capítulo uno", 1)
        d.add_heading("Resultados", 1)
        body(d, "Intro del capítulo con suficientes palabras para no ser corta en absoluto.")
        body(d, "La tabla 1 compara la exactitud de los seis brazos experimentales y el número de "
                "presentaciones que necesitó cada uno para estabilizarse.")
        d.add_paragraph("Tabla 1\nExactitud por brazo")
        body(d, "La siguiente tabla resume los parámetros finales del modelo neuronal usados en todas las redes.")
        d.add_paragraph("Tabla 2\nParámetros finales")
        aud = Auditor(d, {}, load_profile({}), only=["R15"])
        codes = [f.code for f in aud.run()]
        self.assertEqual(codes, ["INTRO-TABLA-FIGURA-SIN-NUMERO"])

    def test_replace_in_all_no_infinite_loop(self):
        d = docx.Document()
        body(d, "IA y más IA.")
        src = self.tmp / "ia.docx"
        d.save(src)
        ej = self.tmp / "ia.json"
        ej.write_text(json.dumps([{"op": "replace_in", "p": 0, "find": "IA", "repl": "IA generativa", "all": True}]))
        out = self.tmp / "ia2.docx"
        r = subprocess.run([sys.executable, str(SCRIPTS / "edit_docx.py"), str(src), str(ej), "-o", str(out)],
                           capture_output=True, text=True, timeout=20)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertEqual(docx.Document(out).paragraphs[0].text, "IA generativa y más IA generativa.")

    def test_note_marker_with_line_break_and_tab(self):
        from docx.enum.text import WD_BREAK
        d = docx.Document()
        p = d.add_paragraph()
        r = p.add_run("Usa Brian2[Insertar nota al final: https://brian2.readthedocs.io/]")
        r.add_break(WD_BREAK.LINE)
        r.add_text("Siguiente")
        p2 = d.add_paragraph()
        r2 = p2.add_run("A")
        r2.add_tab()
        r2.add_text("usa NEST[Insertar nota al final: https://nest-simulator.org/] aquí")
        src, out = self.tmp / "br.docx", self.tmp / "br2.docx"
        d.save(src)
        code, log = run(SCRIPTS / "insert_endnotes.py", src, "-o", out)
        self.assertEqual(code, 0, log)
        from _common import NOTE_MARK, para_text_with_notes
        texts = [para_text_with_notes(p._p)[0] for p in docx.Document(out).paragraphs]
        self.assertEqual(texts[0], "Usa Brian2" + NOTE_MARK + "\nSiguiente")
        self.assertEqual(texts[1], "A\tusa NEST" + NOTE_MARK + " aquí")

    def test_replace_in_refuses_to_cross_note(self):
        from _common import build_model
        v3 = self.tmp / "v3.docx"
        if not v3.exists():
            self.test_edit_and_endnotes()
        paras = build_model(docx.Document(v3))
        p = next(x for x in paras if "Brian2" in x.plain and x.has_note_ref)
        ej = self.tmp / "cross.json"
        ej.write_text(json.dumps([{"op": "replace_in", "p": p.idx, "find": "Brian2 con", "repl": "Brian 2 con"}]))
        code, log = run(SCRIPTS / "edit_docx.py", v3, ej, "-o", self.tmp / "cross.docx")
        self.assertNotEqual(code, 0)
        self.assertIn("cruza una nota", log)

    def test_unsafe_ops_reported(self):
        ops = [{"op": "delete", "p": 3}, {"op": "replace", "p": 3, "text": "x"}, {"op": "delete", "p": 3},
               {"op": "insert_after", "p": 2, "text": "y", "like": 9999}]
        ej = self.tmp / "unsafe.json"
        ej.write_text(json.dumps(ops))
        code, log = run(SCRIPTS / "edit_docx.py", self.docx, ej, "-o", self.tmp / "unsafe.docx")
        self.assertEqual(code, 2, log)
        self.assertEqual(log.count("ya se borró"), 2, log)
        self.assertIn("«like» fuera de rango", log)

    def test_inline_chapter_titles_and_h1_mode(self):
        from _common import build_model
        d = docx.Document()
        d.add_heading("Introducción", 1)
        body(d, "Texto.")
        d.add_heading("Capítulo 1. Marco teórico", 1)
        body(d, "Intro del capítulo.")
        d.add_heading("Conceptos", 2)
        d.add_heading("Referencias", 1)
        d.add_paragraph("Pérez, A. (2020). Título. Revista, 1(1), 1–2.")
        m = build_model(d)
        self.assertEqual([p.number for p in m if p.number], ["1.1"])
        self.assertEqual(m[-1].kind, "ref")
        d2 = docx.Document()
        d2.add_heading("Introducción", 1)
        d2.add_heading("Estado del arte", 1)
        d2.add_heading("Trabajos previos", 2)
        d2.add_heading("Conclusiones", 1)
        m2 = build_model(d2)
        self.assertEqual([p.number for p in m2 if p.number], ["1.1"])
        self.assertIsNone(m2[-1].chapter)

    def test_citation_parsing(self):
        from audit_tesis import Auditor
        got = [Auditor.cite_key(a, y) for a, y in Auditor.parse_parenthetical(
            "Brian2, usado por Shiu et al., 2024; flywire-jo-snn, 2026; Hebb, 1949, como se citó en Gerstner et al., 2014")]
        self.assertEqual(got, [("shiu", "2024"), ("flywire-jo-snn", "2026"), ("hebb", "1949"), ("gerstner", "2014")])
        self.assertEqual(Auditor.cite_key("flywire-jo-snn.", "2026"), ("flywire-jo-snn", "2026"))
        self.assertEqual(Auditor._self_cite("López et al., 2019", ["Mora", "López"], {}, False), "AVISO")
        self.assertEqual(Auditor._self_cite("Mora y López, 2026", ["Mora", "López"], {}, False), "ERROR")

    def test_verify_refs_doi_only(self):
        import verify_refs as vr
        r = vr.parse_ref("10.7554/eLife.47314")
        self.assertNotIn("first_author", r)
        self.assertNotIn("title", r)
        self.assertLess(vr.sim("Deep learning", "Deep learning for spiking neural networks on neuromorphic chips"), 0.85)

    def test_verify_refs_parsing(self):
        import verify_refs as vr
        r = vr.parse_ref("Bi, G., y Poo, M. (1998). Synaptic modifications in cultured hippocampal neurons: "
                         "Dependence on spike timing. Journal of Neuroscience, 18(24), 10464–10472. "
                         "https://doi.org/10.1523/JNEUROSCI.18-24-10464.1998")
        self.assertEqual(r["doi"], "10.1523/JNEUROSCI.18-24-10464.1998")
        self.assertEqual(r["year"], "1998")
        self.assertEqual(r["first_author"], "Bi")
        self.assertTrue(r["title"].startswith("Synaptic modifications"))
        self.assertGreater(vr.sim("Neuronal wiring diagram of an adult brain",
                                  "Neuronal wiring diagram of an adult brain"), 0.99)


if __name__ == "__main__":
    unittest.main()
