# tesis-writer-es

Skill para **Claude Code** (y Claude Desktop) que redacta, revisa y corrige capítulos de tesis y
trabajos de titulación en español con reglas de estilo estrictas, formato institucional, APA 7,
escritura humanizada e investigación con **doble verificación de DOI**.

Trae scripts que auditan el `.docx` real de la tesis y lo corrigen **sin romper su formato**
(estilos, numeración automática, notas), e insertan **notas al final reales de Word**.

## Qué hace

| Modo | Qué obtienes |
|---|---|
| Redactar un capítulo | ficha + esquema para aprobar, plano argumental, borrador sección a sección con todas las reglas aplicadas |
| Revisar un documento | informe con hallazgos anclados (párrafo, sección), severidad y corrección propuesta |
| Corregir | ediciones quirúrgicas sobre el `.docx` en una versión nueva (`_v2`, `_v3`…) y re-auditoría |
| Investigar fuentes | búsqueda en cuatro capas, criterios de relevancia y renombre, matriz de evidencia |
| Verificar referencias | DOI comprobado en doi.org + Crossref/DataCite + OpenAlex, retractaciones, DOI sugeridos |
| Humanizar | reescritura con métricas de ritmo y sin patrones de texto generado |

## Reglas que aplica siempre

1. **Sin preguntas en el texto** (salvo la pregunta de investigación formal).
2. **Notas al final** en la primera aparición de librerías clave (enlace a su documentación) y de
   conceptos complejos lejanos del marco teórico (definición de una línea).
3. **Párrafo introductorio** tras el título de cada capítulo.
4. **3–4 líneas de introducción** al entrar en cada sección x.x.
5. **Sin «Elaboración propia»** en figuras y tablas propias; lo ajeno con su cita APA.
6. **El repositorio propio se cita como repositorio**, no como autocita de los autores.
7. **Títulos en tipo oración** (solo primera palabra y nombres propios; *Drosophila melanogaster*).
8. **2–3 líneas de presentación antes de cada tabla y figura**, nombrándola por su número.
9. Metodología de **revisión** de documentos con contenido.
10. **Ante cualquier duda, pregunta con opciones**; nunca inventa datos.
11. **Escritura humanizada** (fundamentos de `my-humanizer-es-en`).
12. Metodología de redacción, revisión y búsqueda de **academic-research-skills**.
13. **Formato institucional** (UTPL TIC por defecto; perfiles para otras universidades).
14. **APA 7 en español**.
15. **Investigación exhaustiva** con artículos relevantes y de renombre, DOI probado en dos fuentes.

Extras: auditoría automática con informe Markdown/JSON, comprobación de remisiones («véase la
sección 4.4.1»), tablas y figuras sin mención, siglas sin desarrollar, texto de plantilla
olvidado, numeración de títulos calculada, métricas de humanización, perfiles de formato en
JSON, plantillas (ficha de capítulo, informe de revisión, matriz de evidencia) y pruebas con CI.

## Instalación

### Opción A — `skills` CLI (recomendada)

```bash
npx skills add ljmor/tesis-writer-es -g -a claude-code     # global: todos tus proyectos
npx skills add ljmor/tesis-writer-es -a claude-code        # solo el proyecto actual (./.claude/skills)
```

Sin `-g` el CLI instala en el proyecto actual; con `-g`, en tu usuario. Sin `-a` te pregunta
para qué agentes instalar.

### Opción B — manual

```bash
git clone https://github.com/ljmor/tesis-writer-es.git
cd tesis-writer-es && ./install.sh             # en ~/.claude/skills
# o, solo para un proyecto:  ./install.sh --project
```

### Dependencias de Python (para los scripts)

```bash
python3 -m pip install -r requirements.txt     # python-docx (+ certifi, opcional)
```

`certifi` evita errores SSL de `verify_refs.py` con el Python de python.org en macOS; si falta,
el script usa `curl` del sistema.

## Actualización

```bash
npx skills update tesis-writer-es -g        # o -p si la instalaste en el proyecto
# reinstalación limpia:
npx skills remove tesis-writer-es && npx skills add ljmor/tesis-writer-es -g -a claude-code
```

Manual: `git -C tesis-writer-es pull && ./tesis-writer-es/install.sh` (si clonaste directamente
en `~/.claude/skills/tesis-writer-es`, basta con `git pull`).
Reinicia Claude Code (o recarga las skills) para que tome la nueva versión.

## Uso

Pide en lenguaje natural o invoca `/tesis-writer-es`:

- «Redacta el capítulo 3 de metodología a partir de mi repositorio»
- «Revisa mi tesis BorradorV5.docx y dime qué incumple»
- «Aplica las correcciones de las reglas de oro al documento»
- «Busca artículos de renombre sobre STDP en redes de pulsos y verifícalos»
- «Verifica todas las referencias de la tesis»

La primera vez crea `tesis.config.json` junto a tu `.docx` (autores, repositorio, librerías
clave, nombres propios). Ejemplo en `templates/tesis.config.example.json`.

### Scripts a mano

```bash
python3 scripts/dump_docx.py tesis.docx --outline
python3 scripts/audit_tesis.py tesis.docx --out informe.md
python3 scripts/edit_docx.py tesis.docx ediciones.json -o tesis_v2.docx
python3 scripts/insert_endnotes.py tesis_v2.docx -o tesis_v3.docx
python3 scripts/verify_refs.py --docx tesis.docx --mailto tu@correo --out verificacion.md
```

## Estructura

```
tesis-writer-es/
├── SKILL.md                      # instrucciones que sigue el agente
├── references/                   # reglas de oro, metodologías, APA 7, humanización, formato
├── profiles/                     # perfiles de formato institucional (JSON)
├── templates/                    # config, ficha de capítulo, informe de revisión, matriz de evidencia
├── scripts/                      # auditoría, edición .docx, notas al final, verificación de DOI
├── tests/                        # pruebas de humo (python -m unittest discover -s tests)
└── install.sh                    # instalación manual
```

## Otra universidad

Copia `profiles/_plantilla.json` a `profiles/<siglas>-<tipo>.json`, ajusta los valores de su guía
y pon `"perfil": "<siglas>-<tipo>"` en `tesis.config.json`. Ver `references/formato-utpl.md`.

## Límites honestos

- La auditoría de formato lee la herencia de estilos de Word, pero algunos casos (temas,
  estilos vinculados) pueden requerir comprobación visual en Word.
- `verify_refs.py` necesita internet. Un fallo de red se reporta como SIN-CONEXION, nunca como
  referencia falsa.
- Comprobar que una fuente dice lo que se le atribuye sigue requiriendo leerla: la skill lo exige,
  el script no lo sustituye.
- Ningún detector de IA da garantías; la skill no promete porcentajes.

## Licencia

MIT
