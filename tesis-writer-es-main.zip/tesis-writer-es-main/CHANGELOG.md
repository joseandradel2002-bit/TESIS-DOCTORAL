# Changelog

## 1.0.0 — 2026-10-21

Primera versión.

- SKILL.md con jerarquía de reglas, 15 reglas de oro, protocolo de preguntas con opciones y seis
  modos de trabajo (redactar, revisar, corregir, investigar, verificar, humanizar).
- Referencias: reglas de oro con ejemplos, metodología de redacción y de revisión (basadas en
  academic-research-skills), investigación y doble verificación de fuentes, APA 7 en español,
  escritura humanizada (fundamentos de my-humanizer-es-en), estructura de capítulos, formato UTPL.
- Scripts: `dump_docx.py`, `audit_tesis.py`, `edit_docx.py`, `insert_endnotes.py`, `verify_refs.py`.
- Perfil `utpl-tic` y plantilla para otras instituciones.
- Plantillas: configuración del proyecto, ficha de capítulo, informe de revisión, matriz de evidencia.
- Regla R15: párrafo de presentación de 2–3 líneas antes de cada tabla y figura (auditoría incluida).
- Pruebas de humo y CI en GitHub Actions.
