#!/usr/bin/env python3
"""Vuelca un .docx de tesis con índice de párrafo estable, tipo y numeración.

Uso:
  python3 dump_docx.py tesis.docx                  # todo el documento
  python3 dump_docx.py tesis.docx --outline        # solo títulos con numeración
  python3 dump_docx.py tesis.docx --chapter 4      # un capítulo
  python3 dump_docx.py tesis.docx --from 680 --to 720
  python3 dump_docx.py tesis.docx --json > modelo.json

Los índices son los mismos que usan audit_tesis.py y edit_docx.py.
El símbolo ⁽ⁿ⁾ marca una referencia a nota (al pie o al final) ya insertada.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import NOTE_MARK, build_model, load_config, load_profile, mark_template_paras, open_docx  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("docx")
    ap.add_argument("--outline", action="store_true", help="solo títulos")
    ap.add_argument("--chapter", type=int)
    ap.add_argument("--from", dest="start", type=int, default=0)
    ap.add_argument("--to", dest="end", type=int, default=10**9)
    ap.add_argument("--width", type=int, default=220, help="recorte de cada línea (0 = sin recorte)")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--config")
    a = ap.parse_args()

    doc = open_docx(a.docx)
    paras = build_model(doc)
    mark_template_paras(paras, load_profile(load_config(a.docx, a.config)))

    sel = [p for p in paras if a.start <= p.idx <= a.end and p.kind not in ("empty",)]
    if a.chapter is not None:
        sel = [p for p in sel if p.chapter == a.chapter]
    if a.outline:
        sel = [p for p in sel if p.kind == "heading"]

    if a.json:
        json.dump([{"idx": p.idx, "kind": p.kind, "level": p.level, "number": p.number,
                    "chapter": p.chapter, "section": p.section, "style": p.style,
                    "text": p.text.replace(NOTE_MARK, "⁽ⁿ⁾")} for p in sel],
                  sys.stdout, ensure_ascii=False, indent=1)
        return

    for p in sel:
        t = p.text.replace(NOTE_MARK, "⁽ⁿ⁾").replace("\n", " / ").strip()
        if a.width and len(t) > a.width:
            t = t[: a.width] + "…"
        if p.kind == "heading":
            indent = "  " * ((p.level or 1) - 1)
            num = f"{p.number} " if p.number else ""
            print(f"{p.idx:>5} H{p.level} {indent}{num}{t}")
        elif not a.outline:
            print(f"{p.idx:>5} {p.kind[:4]:<4}   {t}")


if __name__ == "__main__":
    main()
