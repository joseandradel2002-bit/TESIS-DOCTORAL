# Ficha del capítulo

Rellenar antes de redactar (fase F1). Mostrar al usuario junto con el esquema para su aprobación.

| Campo | Valor |
|---|---|
| Capítulo | N — Título en tipo oración |
| Tipo | planteamiento / marco teórico / metodología / desarrollo / resultados / conclusiones |
| Objetivo(s) específico(s) que cubre | (copiar textualmente del capítulo 1) |
| Pregunta de investigación | (copiar textualmente) |
| Viene de | qué dejó resuelto el capítulo anterior |
| Deja listo | qué necesita el capítulo siguiente |
| Extensión objetivo | N páginas / N palabras (±15 %) |
| Persona gramatical | impersonal / primera del plural |
| Materiales | borrador, repositorio (rutas), datos, bibliografía verificada |
| Términos con nota al final | librerías clave: … · conceptos lejanos: … |
| Figuras y tablas previstas | Figura N: … (propia / adaptada de …) · Tabla N: … |
| Datos faltantes | [FALTA DATO: …] — preguntar al usuario |

## Esquema

| Sección | Propósito (1 frase) | Contenido (2–3 frases) | Fuentes / datos | Transición |
|---|---|---|---|---|
| N.1 … | | | | |
| N.1.1 … | | | | |
| N.2 … | | | | |

## Tesis del capítulo

Este capítulo sostiene que … porque …, con base en …

## Sub-argumentos

| # | Afirmación | Evidencia (fuente + dato) | Razonamiento | Contraargumento y respuesta |
|---|---|---|---|---|
| 1 | | | | |
