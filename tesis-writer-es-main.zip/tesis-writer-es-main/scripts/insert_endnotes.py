#!/usr/bin/env python3
"""Convierte marcas [Insertar nota al final: …] en notas al final reales de Word.

Uso:
  python3 insert_endnotes.py tesis.docx -o tesis_notas.docx
  python3 insert_endnotes.py tesis.docx -o tesis_notas.docx --from-footnotes --rewrite notas.json
      # además pasa las notas al pie a notas al final; notas.json = {"1": "Conectoma: mapa completo…", "2": "https://…"}
      # (ids de las notas al pie: ver el hallazgo NOTA-AL-PIE de audit_tesis.py)
  python3 insert_endnotes.py tesis.docx -o tesis_notas.docx --numfmt keep       # no tocar el formato de numeración

- La marca se escribe pegada a la palabra: «Brian2[Insertar nota al final: https://brian2.readthedocs.io/]».
  Si hay un espacio antes de «[», se elimina para que el número quede junto a la palabra.
- Las URL de la nota quedan como hipervínculo en color de texto normal (negro), como pide APA/UTPL.
- Crea las partes y estilos que falten (endnotes.xml, «endnote text», «endnote reference»).
- Por defecto fuerza numeración arábiga (1, 2, 3); Word usa romanos (i, ii) si no se indica.
"""
import argparse
import copy
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import MARKER_RE, load_config, load_profile, open_docx  # noqa: E402
from _docx_ops import char_map, insert_element_at, run_of, splice  # noqa: E402
from docx.opc.constants import CONTENT_TYPE as CT, RELATIONSHIP_TYPE as RT  # noqa: E402
from docx.opc.packuri import PackURI  # noqa: E402
from docx.opc.part import Part  # noqa: E402
from docx.oxml import OxmlElement  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402
from lxml import etree  # noqa: E402

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
EMPTY_ENDNOTES = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    f'<w:endnotes xmlns:w="{W}" xmlns:r="{R}">'
    '<w:endnote w:type="separator" w:id="-1"><w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr>'
    '<w:r><w:separator/></w:r></w:p></w:endnote>'
    '<w:endnote w:type="continuationSeparator" w:id="0"><w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr>'
    '<w:r><w:continuationSeparator/></w:r></w:p></w:endnote>'
    '</w:endnotes>'
).encode("utf-8")
INSTRUCTION_RE = re.compile(r"^(explicar|enlace|enlazar|poner|añadir|agregar|insertar|definir|colocar|citar|"
                            r"incluir|completar|revisar|pendiente|todo)\b", re.I)
URL_RE = re.compile(r"https?://[^\s<>\"]+[^\s<>\".,;:)]")


def E(tag, **attrs):
    el = OxmlElement(tag)  # conserva el prefijo w: en lugar de ns0:
    for k, v in attrs.items():
        el.set(qn(k if ":" in k else f"w:{k}"), str(v))
    return el


def sub(parent, tag, **attrs):
    el = E(tag, **attrs)
    parent.append(el)
    return el


def get_part(doc, reltype_suffix):
    for rel in doc.part.rels.values():
        if rel.reltype.endswith(reltype_suffix):
            return rel.target_part
    return None


def ensure_endnotes_part(doc):
    part = get_part(doc, "/endnotes")
    created = False
    if part is None:
        part = Part(PackURI("/word/endnotes.xml"), CT.WML_ENDNOTES, EMPTY_ENDNOTES, doc.part.package)
        doc.part.relate_to(part, RT.ENDNOTES)
        created = True
    return part, etree.fromstring(part.blob), created


def style_id_by_name(doc, name, stype):
    for s in doc.styles.element.findall(qn("w:style")):
        n = s.find(qn("w:name"))
        if n is not None and n.get(qn("w:val")).lower() == name and s.get(qn("w:type")) == stype:
            return s.get(qn("w:styleId"))
    return None


def default_style_id(doc, stype):
    for s in doc.styles.element.findall(qn("w:style")):
        if s.get(qn("w:type")) == stype and s.get(qn("w:default")) in ("1", "true", "on"):
            return s.get(qn("w:styleId"))
    return None


def ensure_styles(doc, font, size_pt):
    st = doc.styles.element
    text_id = style_id_by_name(doc, "endnote text", "paragraph")
    if text_id is None:
        text_id = "Textonotaalfinal"
        s = E("w:style", type="paragraph", styleId=text_id)
        sub(s, "w:name", val="endnote text")
        base = default_style_id(doc, "paragraph")
        if base:
            sub(s, "w:basedOn", val=base)
        sub(s, "w:uiPriority", val="99")
        sub(s, "w:unhideWhenUsed")
        ppr = sub(s, "w:pPr")
        sub(ppr, "w:spacing", before="0", after="0", line="240", lineRule="auto")
        sub(ppr, "w:ind", firstLine="0")
        sub(ppr, "w:jc", val="left")
        rpr = sub(s, "w:rPr")
        sub(rpr, "w:rFonts", ascii=font, hAnsi=font, cs=font)
        sub(rpr, "w:sz", val=str(int(size_pt * 2)))
        sub(rpr, "w:szCs", val=str(int(size_pt * 2)))
        st.append(s)
    ref_id = style_id_by_name(doc, "endnote reference", "character")
    if ref_id is None:
        ref_id = "Refdenotaalfinal"
        s = E("w:style", type="character", styleId=ref_id)
        sub(s, "w:name", val="endnote reference")
        base = default_style_id(doc, "character")
        if base:
            sub(s, "w:basedOn", val=base)
        sub(s, "w:uiPriority", val="99")
        sub(s, "w:unhideWhenUsed")
        rpr = sub(s, "w:rPr")
        sub(rpr, "w:vertAlign", val="superscript")
        st.append(s)
    return text_id, ref_id


SETTINGS_ORDER_AFTER = ["w:footnotePr"]
SETTINGS_ORDER_BEFORE = ["w:compat", "w:docVars", "w:rsids", "m:mathPr", "w:attachedSchema", "w:themeFontLang",
                         "w:clrSchemeMapping", "w:doNotIncludeSubdocsInStats", "w:shapeDefaults", "w:decimalSymbol",
                         "w:listSeparator"]


def set_numfmt(doc, fmt, created):
    settings = doc.settings.element
    enp = settings.find(qn("w:endnotePr"))
    if enp is None:
        enp = E("w:endnotePr")
        anchor = settings.find(qn("w:footnotePr"))
        if anchor is not None:
            anchor.addnext(enp)
        else:
            for tag in SETTINGS_ORDER_BEFORE:
                if ":" in tag and tag.startswith("m:"):
                    continue
                b = settings.find(qn(tag))
                if b is not None:
                    b.addprevious(enp)
                    break
            else:
                settings.append(enp)
        if created:
            sub(enp, "w:endnote", id="-1")
            sub(enp, "w:endnote", id="0")
    targets = [enp] + [s.find(qn("w:endnotePr")) for s in doc.element.body.iter(qn("w:sectPr"))]
    for t in targets:
        if t is None:
            continue
        nf = t.find(qn("w:numFmt"))
        if nf is None:
            nf = E("w:numFmt")
            pos = t.find(qn("w:pos"))
            if pos is not None:
                pos.addnext(nf)
            else:
                t.insert(0, nf)
        nf.set(qn("w:val"), fmt)


def build_note_paragraph(part, text, text_id, ref_id, links):
    p = E("w:p")
    ppr = sub(p, "w:pPr")
    sub(ppr, "w:pStyle", val=text_id)
    r = sub(p, "w:r")
    rpr = sub(r, "w:rPr")
    sub(rpr, "w:rStyle", val=ref_id)
    sub(r, "w:endnoteRef")
    pos = 0
    chunks = []
    for m in URL_RE.finditer(text):
        chunks.append(("t", text[pos:m.start()]))
        chunks.append(("u", m.group(0)))
        pos = m.end()
    chunks.append(("t", text[pos:]))
    first = True
    for kind, s in chunks:
        if not s:
            continue
        if first:
            s = " " + s.lstrip()
            first = False
        if kind == "u" and links:
            rid = part.relate_to(s.strip(), RT.HYPERLINK, is_external=True)
            if s.startswith(" "):
                rr = sub(p, "w:r")
                t = sub(rr, "w:t")
                t.text = " "
                t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            h = sub(p, "w:hyperlink")
            h.set(qn("r:id"), rid)
            rr = sub(h, "w:r")
            t = sub(rr, "w:t")
            t.text = s.strip()
        else:
            rr = sub(p, "w:r")
            t = sub(rr, "w:t")
            t.text = s
            t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    return p


def ref_run(nid, ref_id, model_rpr=None):
    """Run con la llamada a la nota; copia fuente y tamaño del texto vecino para no desentonar."""
    r = E("w:r")
    if model_rpr is not None:
        rpr = copy.deepcopy(model_rpr)
        for tag in ("w:rStyle", "w:vertAlign", "w:b", "w:i", "w:u", "w:color", "w:highlight"):
            for x in rpr.findall(qn(tag)):
                rpr.remove(x)
        r.append(rpr)
    else:
        rpr = sub(r, "w:rPr")
    rpr.insert(0, E("w:rStyle", val=ref_id))
    sub(r, "w:endnoteReference", id=str(nid))
    return r


def rpr_before(p_el, pos):
    _, m = char_map(p_el)
    if not m or pos <= 0:
        return None
    run = run_of(m[min(pos, len(m)) - 1][0])
    return run.find(qn("w:rPr")) if run is not None else None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("docx")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--numfmt", default="decimal", help="decimal | lowerRoman | upperRoman | keep")
    ap.add_argument("--from-footnotes", action="store_true", help="convertir también las notas al pie en notas al final")
    ap.add_argument("--rewrite", help="JSON {id_nota_al_pie: texto final} para reescribir las notas al pie al convertirlas")
    ap.add_argument("--no-links", action="store_true", help="no convertir URL en hipervínculos")
    ap.add_argument("--config")
    a = ap.parse_args()
    if Path(a.out).resolve() == Path(a.docx).resolve():
        sys.exit("El archivo de salida debe ser distinto del original.")

    prof = load_profile(load_config(a.docx, a.config))
    tf = prof.get("tablas_figuras", {})
    maxc = prof.get("limites", {}).get("nota_al_final_caracteres_max", 100)
    doc = open_docx(a.docx)
    part, root, created = ensure_endnotes_part(doc)
    text_id, ref_id = ensure_styles(doc, tf.get("fuente", "Arial"), tf.get("tamano_pt", 10))
    ids = [int(n.get(qn("w:id"))) for n in root.findall(qn("w:endnote"))]
    next_id = max(ids + [0]) + 1
    report, warns = [], []

    # 1) marcas en el cuerpo (incluye tablas, cuadros de texto, encabezados no)
    for p_el in doc.element.body.iter(qn("w:p")):
        text, _ = char_map(p_el)
        if "[" not in text:
            continue
        matches = list(MARKER_RE.finditer(text))
        base_id = next_id
        for k, m in reversed(list(enumerate(matches))):
            next_id = base_id + k  # ids en orden de lectura aunque se procese de atrás hacia delante
            content = re.sub(r"\s+", " ", m.group(1)).strip()
            start = m.start()
            if start > 0 and text[start - 1] == " ":
                start -= 1
            splice(p_el, start, m.end(), "")
            note = E("w:endnote", id=str(next_id))
            note.append(build_note_paragraph(part, content, text_id, ref_id, not a.no_links))
            root.append(note)
            insert_element_at(p_el, start, ref_run(next_id, ref_id, rpr_before(p_el, start)))
            anchor = MARKER_RE.sub("", text[:start])[-40:].strip()
            report.append((next_id, anchor, content))
            if len(content) > maxc and not URL_RE.fullmatch(content.strip()):
                warns.append(f"nota {next_id}: {len(content)} caracteres (> {maxc}); debería caber en una línea")
            text, _ = char_map(p_el)
        next_id = base_id + len(matches)

    # 2) notas al pie → notas al final
    converted = 0
    rewrite = json.loads(Path(a.rewrite).read_text(encoding="utf-8")) if a.rewrite else {}
    if a.from_footnotes:
        fpart = get_part(doc, "/footnotes")
        if fpart is not None:
            froot = etree.fromstring(fpart.blob)
            fnotes = {n.get(qn("w:id")): n for n in froot.findall(qn("w:footnote"))}
            for fref in list(doc.element.body.iter(qn("w:footnoteReference"))):
                fid = fref.get(qn("w:id"))
                fn = fnotes.get(fid)
                content = "".join(t.text or "" for t in fn.iter(qn("w:t"))).strip() if fn is not None else ""
                if str(fid) in rewrite:
                    content = rewrite[str(fid)].strip()
                elif INSTRUCTION_RE.match(content):
                    warns.append(f"la nota al pie {fid} parece una instrucción del autor («{content[:50]}»); "
                                 "pásala reescrita con --rewrite en vez de copiarla tal cual")
                note = E("w:endnote", id=str(next_id))
                note.append(build_note_paragraph(part, content, text_id, ref_id, not a.no_links))
                root.append(note)
                run = fref.getparent()
                rpr = run.find(qn("w:rPr"))
                if rpr is not None:
                    for rs in rpr.findall(qn("w:rStyle")):
                        rpr.remove(rs)
                    rpr.insert(0, E("w:rStyle", val=ref_id))
                fref.addnext(E("w:endnoteReference", id=str(next_id)))
                run.remove(fref)
                if fn is not None:
                    froot.remove(fn)
                report.append((next_id, "(nota al pie convertida)", content))
                next_id += 1
                converted += 1
            fpart._blob = etree.tostring(froot, xml_declaration=True, encoding="UTF-8", standalone=True)

    part._blob = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    if report and a.numfmt != "keep":
        set_numfmt(doc, a.numfmt, created)
    doc.save(a.out)

    for nid, anchor, content in sorted(report):
        print(f"[{nid}] …{anchor} → {content}")
    print(f"\n{len(report)} nota(s) al final insertada(s) ({converted} desde notas al pie). Guardado: {a.out}")
    if not report:
        print("No se encontraron marcas [Insertar nota al final: …].")
    for w in warns:
        print("AVISO:", w)


if __name__ == "__main__":
    main()
