# Reglas de oro: detalle, ejemplos y casos límite

Estas reglas son del usuario y están por encima de cualquier otra guía (APA, humanizador, ARS).
Cada una tiene su código de auditoría entre corchetes.

---

## R01. Sin preguntas en el texto [R01]

El texto afirma. No pregunta. Las preguntas retóricas («¿Por qué ocupa esto un capítulo
entero? Porque…») delatan texto generado y debilitan el registro académico.

**Única excepción:** la pregunta de investigación formal, en su apartado (p. ej. «1.8 Objetivos
de la investigación», línea «Pregunta de investigación. ¿…?») y sus reformulaciones literales
cuando se la nombra explícitamente («la pregunta de investigación, ¿supera…?»). También
preguntas de una cita textual imprescindible (mejor parafrasear).

Cómo convertir: la respuesta implícita se vuelve la afirmación.

| Antes | Después |
|---|---|
| ¿Por qué ocupa esa preparación un capítulo entero? Porque el conectoma no llega en forma de vectores. | La preparación ocupa un capítulo entero porque el conectoma no llega en forma de vectores. |
| El análisis persigue una pregunta sencilla. ¿Qué forma tiene el circuito antes de tocarlo? | El análisis exploratorio describe la forma del circuito antes de cualquier filtrado. |
| ¿Cuánto importa ese reparto? En la fase de modelado se repitió… | El reparto importa poco. En la fase de modelado se repitió… |
| Si la red clasifica mejor, ¿es por su topología o por algo más trivial? | Una ventaja de la red podría deberse a su topología o a algo más trivial, como su tamaño. |

Prohibido también: preguntas en títulos («¿Qué es una SNN?» → «Definición de red neuronal de
pulsos»), preguntas en leyendas de figura y la fórmula «cabe preguntarse si…» (pregunta
indirecta encubierta; sustituir por la afirmación o la hipótesis).

---

## R02. Notas al final [R02]

Dos casos, nada más:

1. **Librerías y herramientas realmente clave del proyecto** (en el caso de referencia, Brian2).
   Nota al final en la **primera aparición** del término en el cuerpo con el **enlace a la
   documentación oficial**. Solo el enlace (o «Documentación oficial: URL»).
   - Clave = sin ella el proyecto no existe o es el eje de la metodología (simulador, framework
     principal, dataset central). NumPy o Matplotlib usados de apoyo no son clave.
   - Si dudas si una librería es clave, pregunta al usuario con opciones (ver SKILL.md, protocolo de
     preguntas) y guarda la respuesta en `terminos_nota` de `tesis.config.json`.
2. **Conceptos complejos poco repetidos y lejos de su explicación**: el término se explicó en el
   marco teórico y reaparece capítulos después, pocas veces (p. ej. «colinérgicas» en el capítulo 5).
   Nota con definición **de una sola línea** (≤ 100 caracteres aprox.; nunca más de una línea).

Formato:
- Texto plano / Markdown: la marca va pegada a la palabra, sin espacio:
  `…simulado en Brian2[Insertar nota al final: https://brian2.readthedocs.io/] con neuronas LIF…`
  `…las neuronas colinérgicas[Insertar nota al final: Neuronas que liberan acetilcolina.] proyectan…`
- `.docx`: escribir la marca y ejecutar `scripts/insert_endnotes.py` → nota al final real de Word,
  numeración arábiga, URL como hipervínculo en negro.
- Librerías: una nota en su **primera aparición en el documento**.
- Conceptos: la nota va en la **primera aparición lejana**, no donde se define (allí ya está la
  explicación). Por defecto, desde el capítulo siguiente al que sigue al marco teórico
  (`capitulo_marco_teorico` + 2 en la config); se configuran en `conceptos_nota`.
- No usar notas al pie para esto. Las notas al pie existentes se convierten con
  `insert_endnotes.py --from-footnotes --rewrite notas.json` (solo con permiso del usuario). Si la
  nota al pie es un recordatorio del autor («Explicar en una línea el conectoma»), se redacta su
  contenido final en `notas.json` (`{"1": "Conectoma: mapa completo de las conexiones sinápticas."}`);
  nunca se copia la instrucción.

Definiciones de una línea, ejemplos válidos:
- «Conectoma: mapa completo de las conexiones sinápticas de un sistema nervioso.»
- «STDP: regla que ajusta el peso sináptico según el orden temporal de los pulsos pre y postsinápticos.»

Inválido: dos oraciones, citas dentro de la nota, «Para más información véase…».

---

## R03. Párrafo introductorio de capítulo [R03]

Después del título del capítulo («Capítulo cuatro» + «Comprensión y preparación de los datos»)
y antes del primer subtítulo x.1 va un párrafo breve (4–8 líneas) que diga:
- de qué trata el capítulo y qué fase/objetivo cubre,
- por qué viene en este punto del trabajo (enlace con el capítulo anterior),
- qué recorre, mencionando las secciones principales en prosa (no como lista de números).

Ejemplo:
> Este capítulo cubre las fases dos y tres de CRISP-DM, la comprensión y la preparación de los
> datos. El conectoma no llega listo para simularse, así que aquí se describe cómo se extrajo el
> subgrafo auditivo, cómo se exploró y qué decisiones lo convirtieron en una red ejecutable. Al
> final queda fijada la configuración que usa el diseño experimental del capítulo 5.

---

## R04. Introducción de cada sección de primer nivel (x.x) [R04]

Al entrar en cada sección x.x, antes de su primer subtítulo x.x.x (o antes de su contenido si no
tiene subsecciones), 3–4 líneas (≈ 40–80 palabras) que expliquen de qué trata la sección.
- No repetir el título. No listar «En 4.2.1 se…, en 4.2.2 se…». Anticipar el contenido en prosa.
- Si ya hay un bloque largo antes de la primera subsección (> 130 palabras), condensar a 3–4
  líneas y mover el resto a una subsección.

Ejemplo (sección «4.2 Fuente de datos: el conectoma FlyWire de Drosophila»):
> Esta sección presenta el conjunto de datos de partida. Describe el conectoma publicado por
> FlyWire, las tablas que se descargaron de su portal y el circuito auditivo que se eligió como
> objeto de estudio.

---

## R05. Sin «Elaboración propia» [R05]

Toda figura, tabla o elemento creado por los autores **no** lleva «Elaboración propia»: se
sobreentiende. Lo que no es propio sí lleva su fuente APA.

| Caso | Nota correcta |
|---|---|
| Figura propia sin más | (sin nota) — o una nota explicativa si aporta algo («Nota. Exactitud media de 15 semillas.») |
| «Elaboración propia a partir de FlyWire (Dorkenwald et al., 2024)» | «Nota. Datos tomados de FlyWire (Dorkenwald et al., 2024).» |
| Figura adaptada de un artículo | «Nota. Adaptado de *Título* (p. 5), por A. Autor, 2023, *Revista*, 12(3) (https://doi.org/…).» |
| Figura reproducida tal cual | «Nota. Tomado de *Título*, por A. Autor, 2020, Editorial.» (y comprobar licencia) |
| Datos del repositorio propio | «Nota. Datos de results.md del repositorio del proyecto (nombre-repo, 2026).» + nota al final con URL del archivo |

Si no sabes si un elemento es propio, pregunta al usuario (opciones: propio / adaptado de… /
tomado de…).

---

## R06. El repositorio propio se cita como repositorio [R06]

Nunca autocitar a los autores de la tesis para algo que vive en su repositorio.

- En el texto: `(nombre-repo, año)`. Ej.: `(flywire-jo-snn, 2026)`.
- Si se nombra un archivo concreto (cuaderno, script, results.md, research-log.md, CSV), además
  **nota al final** con la URL directa al archivo:
  `…según el registro de la fase 4[Insertar nota al final: https://github.com/usuario/repo/blob/main/04-modeling/research-log.md] (flywire-jo-snn, 2026).`
  Una nota por archivo (primera mención).
- En Referencias (APA 7, software/repositorio):
  `flywire-jo-snn. (2026). *Bio-inspired SNN on the FlyWire Johnston's organ connectome* [Repositorio de GitHub]. GitHub. https://github.com/usuario/flywire-jo-snn`
  - El nombre del repositorio ocupa la posición de autor; título descriptivo en cursiva; descriptor
    entre corchetes en español; versión si existe: `(Versión 1.0.0)` antes del corchete.
- Los datos de terceros alojados en el repo (p. ej. tablas de FlyWire) se citan a su fuente original.

Datos que necesitas en `tesis.config.json`: `autores` (apellidos), `repositorio.nombre`,
`repositorio.url`, `repositorio.anio`, `repositorio.rama` (para construir URL de archivos).

---

## R07. Títulos en tipo oración [R07]

Mayúscula solo en la primera palabra y en nombres propios. Aplica a títulos de capítulo, de
todos los niveles, de tablas y de figuras.

| Antes | Después |
|---|---|
| Planteamiento de la Investigación | Planteamiento de la investigación |
| El Agotamiento del Paradigma Actual de la Inteligencia Artificial | El agotamiento del paradigma actual de la inteligencia artificial |
| Simulación de la SNN con Brian2 | (correcto: SNN es sigla, Brian2 es nombre propio) |
| Conectómica de la Drosophila Melanogaster | Conectómica de *Drosophila melanogaster* |
| Modelo Leaky Integrate-and-Fire (LIF) | Modelo leaky integrate-and-fire (LIF) |

Se conserva la mayúscula en: nombres propios de personas, instituciones, proyectos, datasets,
librerías y productos (FlyWire, Brian2, CRISP-DM, Intel Loihi), siglas (SNN, STDP), topónimos,
nombres de leyes/teoremas con nombre de persona (ley de Ohm, modelo de Erdős–Rényi), géneros
biológicos.

**Nomenclatura binomial:** género con mayúscula, epíteto específico **siempre en minúscula**, ambos
en cursiva: *Drosophila melanogaster*, *Caenorhabditis elegans*. Nunca «Drosophila Melanogaster».

**Tras dos puntos:** APA 7 admite mayúscula en la primera palabra después de los dos puntos de un
título; la RAE prefiere minúscula. Seguir la convención que ya use el documento y mantenerla.

Casos dudosos (¿«Codex» es nombre propio? ¿«Marco» en «Marco CRISP-DM»?): preguntar al usuario
y registrar la respuesta en `nombres_propios`.

---

## R15. Presentar cada tabla y figura antes de que aparezca [R15]

Justo antes de la leyenda («Tabla 3» / «Figura 10») va un párrafo **propio y breve, de 2–3 líneas**
(≈ 15–60 palabras en Arial 11), nunca más, que:
- nombra el elemento **por su número** («La figura 10…», «En la tabla 8…»);
- dice qué muestra y, si hace falta, qué debe mirar el lector o para qué sirve en el argumento;
- no repite todos los datos del elemento (eso es la tabla) ni la interpretación completa (va después).

| Antes | Después |
|---|---|
| (título 4.1) → Figura 10 | (título 4.1) → «La figura 10 resume el recorrido de los datos, desde el conectoma FlyWire hasta la configuración que usa la fase de modelado.» → Figura 10 |
| «…La siguiente tabla resume las aplicaciones prácticas.» → Tabla 1 | «La tabla 1 resume las aplicaciones prácticas del trabajo, con la restricción energética y la ventaja de las SNN en cada dominio.» → Tabla 1 |
| Párrafo de 180 palabras que termina en «…como muestra la figura 11.» → Figura 11 | El párrafo largo se queda; se añade uno breve: «La figura 11 sitúa el órgano de Johnston dentro de la composición del conectoma por superclase.» |
| Figura 14 seguida directamente de Figura 15 | Entre la nota de la figura 14 y la leyenda de la figura 15, un párrafo de 2–3 líneas que presente la figura 15 |

Variar el verbo para no repetir la misma fórmula: muestra, resume, compara, recoge, sitúa,
detalla, ilustra, reúne. Sin preguntas (R01) ni «Elaboración propia» (R05).

---

## R09. Ante cualquier duda, preguntar con opciones

Ver «Protocolo de preguntas» en SKILL.md. Nunca suponer en: autoría de figuras, si una librería es
clave, si una palabra es nombre propio, si una fuente es aceptable, a qué capítulo pertenece un
contenido, y cualquier dato del proyecto (cifras, fechas, URL). Nunca inventar datos.
