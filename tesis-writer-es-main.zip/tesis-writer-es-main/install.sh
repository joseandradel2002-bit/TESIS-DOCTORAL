#!/usr/bin/env bash
# Instalación / actualización manual de tesis-writer-es para Claude Code.
# Uso: ./install.sh            (copia a ~/.claude/skills/tesis-writer-es)
#      ./install.sh --project  (copia a ./.claude/skills/tesis-writer-es del proyecto actual)
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ "${1:-}" == "--project" ]]; then
  DEST="$PWD/.claude/skills/tesis-writer-es"
else
  DEST="${CLAUDE_SKILLS_DIR:-$HOME/.claude/skills}/tesis-writer-es"
fi
mkdir -p "$(dirname "$DEST")"
if [[ -e "$DEST" && "$SRC" -ef "$DEST" ]]; then
  echo "Este clon ya está en el destino ($DEST): para actualizar usa 'git pull' aquí mismo."
  python3 -c "import docx" 2>/dev/null || python3 -m pip install --user -r "$SRC/requirements.txt"
  exit 0
fi
case "$DEST/" in "$SRC"/*) echo "El destino está dentro del repo; aborto."; exit 1;; esac
rm -rf "$DEST"
mkdir -p "$DEST"
for item in SKILL.md README.md LICENSE CHANGELOG.md requirements.txt references scripts profiles templates; do
  cp -R "$SRC/$item" "$DEST/"
done
find "$DEST" -name '__pycache__' -type d -prune -exec rm -rf {} +
echo "Instalada en $DEST"
if python3 -c "import docx" 2>/dev/null; then
  echo "python-docx: ok"
else
  echo "Instalando dependencias de Python…"
  python3 -m pip install --user -r "$SRC/requirements.txt" || echo "Instala a mano: python3 -m pip install python-docx certifi"
fi
echo "Reinicia Claude Code (o recarga las skills) para que tome los cambios."
